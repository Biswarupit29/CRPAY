# Databricks notebook source
# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;

# COMMAND ----------


#Read Input Data Files
cp_df_samp_ppa = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPA.json")
cp_df_samp_ppb = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPB.json")

# COMMAND ----------

#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0


#Checks Files Emptiness and both has equal records
count_check=0
cnt1=cp_df_samp_ppa.count()
cnt2=cp_df_samp_ppb.count()

if(cnt1==cnt2 & cnt1!=0):
  count_check=1# RESULT OF COUNT CHECK

#Checks has all required columns
columns_checkv1=1
expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER']
for cols in cp_df_samp_ppa.columns:
  if(cols not in expected_cols):
    columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1

columns_checkv2=1
for cols in cp_df_samp_ppb.columns:
  if(cols not in expected_cols):
    columns_checkv2=0 #RESULT OF COLUMNS VALIDATION for DF2

    
#Checks "Month Starting" is present in PPABCD_RECORD[0].DATA columns
val_check=0  
cp_df_samp_ppa.createOrReplaceTempView("ppaTempView")
cp_df_samp_ppb.createOrReplaceTempView("ppbTempView")
#spark.sql("SELECT COUNT(*) FROM ppaTempView WHERE array_contains(PPABCD_RECORD['DATA'],'MONTH STARTING%')").show()

ppa_val=spark.sql("SELECT COUNT(*) as cnt  FROM ppaTempView WHERE PPABCD_RECORD[0].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[1].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[2].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[3].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[4].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[5].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[6].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[7].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[8].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[9].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[10].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[11].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[12].DATA like '%MONTH STARTING%'").collect()

ppb_val=spark.sql("SELECT COUNT(*) as cnt  FROM ppbTempView").collect()
print(ppb_val[0].cnt)
if(ppa_val[0].cnt>0 and ppb_val[0].cnt>0):
  #print("OOPS")
  val_check=1
print(val_check)
if(count_check==1 & columns_checkv1==1 & columns_checkv2==1 & val_check==1):
  print("Success")
else:
  print("Failure")
  dbutils.notebook.exit("Failure")


# COMMAND ----------

#PPA

from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

DataSchema = StructType([StructField("NFZ_OUT_DATA", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType())])

RepSchema = StructType([StructField("RPT_DATA", StringType()),StructField("RPT_PART", StringType()),StructField("RPT_IND", StringType()),StructField("RPT_STA", StringType()),StructField("RPT_NBR", StringType()),StructField("RPT_CTR", StringType()),StructField("RPT_NAME", StringType())])

def fs(str,len,val):
  return str.rjust(len,val)[:len]

# COMMAND ----------

###################### PPA PARSING #######################
PPA_NFZ_FILE_OUT_TMP_APPEND_LIST = []
PPA_NFZ_RPT_OUT_TMP_APPEND_LIST = []

CNTL_PARTITION_ID = 'AA'
LINE_NUMBER = 1
MONTH_STARTING = 'N'
EMP_IND = 'N'
space = ''
try:
  for row in cp_df_samp_ppa.rdd.collect():
    for A in range(1,14):
      HDR_REC_CHK = row.PPABCD_RECORD[A-1].DATA
    #print(HDR_REC_CHK,'                                        ',CNTL_PARTITION_ID)
    #print(len(HDR_REC_CHK))
    if(len(HDR_REC_CHK) != 80):
      pad = ' ' * (80-len(HDR_REC_CHK))
      if (("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'N')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
        #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','')
        PPA_NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','')
        PPA_NFZ_FILE_OUT_TMP_APPEND_LIST.append(PPA_NFZ_FILE_OUT_TMP.split(','))
        PPA_NFZ_RPT_OUT_TMP_APPEND_LIST.append(PPA_NFZ_FILE_OUT_TMP.split(','))
      elif(("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'Y')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
      else:
        EMPLOYEE_STATION = row.PPABCD_RECORD[A-1].EmployeeStation
        EMPLOYEE_NUMBER = row.PPABCD_RECORD[A-1].EmployeeNumber
        EMPLOYEE_NAME = row.PPABCD_RECORD[A-1].EmployeeName
        LINE_NUMBER = LINE_NUMBER + 1
        if(len(str(LINE_NUMBER)) != 7):
          LINE_NUMBER_ZERO = fs(str(LINE_NUMBER),7, '0')
        if(EMP_IND == 'Y'):
          INDICATOR = HDR_REC_CHK[64:65]
          #print(INDICATOR)
          #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
          PPA_NFZ_RPT_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
          PPA_NFZ_RPT_OUT_TMP_APPEND_LIST.append(PPA_NFZ_RPT_OUT_TMP.split(','))
          EMP_IND = 'N'
        PPA_NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
        PPA_NFZ_FILE_OUT_TMP_APPEND_LIST.append(PPA_NFZ_FILE_OUT_TMP.split(','))
    
except:
   dbutils.notebook.exit("Failure")
        

  

# COMMAND ----------

PPA_NFZ_FILE_OUT_TMP_APPEND_DF = spark.createDataFrame(PPA_NFZ_FILE_OUT_TMP_APPEND_LIST,schema=DataSchema)
PPA_NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(PPA_NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

PPA_NFZ_FILE_OUT_TMP_APPEND_DF.write.mode('overwrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPA_Data_json")
PPA_NFZ_RPT_OUT_TMP_APPEND_DF.write.mode('overwrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPA_Report_json")
PPA_NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").mode('overwrite').save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPA_Report_delta")#CHECK

# COMMAND ----------

###################### PPB PARSING #######################
PPB_NFZ_FILE_OUT_TMP_APPEND_LIST = []
PPB_NFZ_RPT_OUT_TMP_APPEND_LIST = []

CNTL_PARTITION_ID = 'AA'
LINE_NUMBER = 1
MONTH_STARTING = 'N'
EMP_IND = 'N'
space = ''
try:
  for row in cp_df_samp_ppb.rdd.collect():
    for A in range(1,14):
      HDR_REC_CHK = row.PPABCD_RECORD[A-1].DATA
      if(len(HDR_REC_CHK) != 80):
        pad = ' ' * (80-len(HDR_REC_CHK))
        if (("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'N')):
          MONTH_STARTING = 'Y'
          EMP_IND = 'Y'
          #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','')
          PPB_NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','')
          PPB_NFZ_FILE_OUT_TMP_APPEND_LIST.append(PPB_NFZ_FILE_OUT_TMP.split(','))
          PPB_NFZ_RPT_OUT_TMP_APPEND_LIST.append(PPB_NFZ_FILE_OUT_TMP.split(','))
        elif(("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'Y')):
          MONTH_STARTING = 'Y'
          EMP_IND = 'Y'
        else:
          EMPLOYEE_STATION = row.PPABCD_RECORD[A-1].EmployeeStation
          EMPLOYEE_NUMBER = row.PPABCD_RECORD[A-1].EmployeeNumber
          EMPLOYEE_NAME = row.PPABCD_RECORD[A-1].EmployeeName
          LINE_NUMBER = LINE_NUMBER + 1
          if(len(str(LINE_NUMBER)) != 7):
            LINE_NUMBER_ZERO = fs(str(LINE_NUMBER),7, '0')
          if(EMP_IND == 'Y'):
            INDICATOR = HDR_REC_CHK[64:65]
            #print(INDICATOR)
            #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
            PPB_NFZ_RPT_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
            PPB_NFZ_RPT_OUT_TMP_APPEND_LIST.append(PPB_NFZ_RPT_OUT_TMP.split(','))
            EMP_IND = 'N'
          #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
          PPB_NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
          PPB_NFZ_FILE_OUT_TMP_APPEND_LIST.append(PPB_NFZ_FILE_OUT_TMP.split(','))
except:
  dbutils.notebook.exit("Failure")

# COMMAND ----------

PPB_NFZ_FILE_OUT_TMP_APPEND_DF = spark.createDataFrame(PPB_NFZ_FILE_OUT_TMP_APPEND_LIST,schema=DataSchema)
PPB_NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(PPB_NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

PPB_NFZ_FILE_OUT_TMP_APPEND_DF.write.mode('overWrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPB_Data_json")
PPB_NFZ_RPT_OUT_TMP_APPEND_DF.write.mode('overWrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPB_Report_json")
PPB_NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").mode('overwrite').save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPB_Report_delta")

# COMMAND ----------

dbutils.notebook.exit("Success")