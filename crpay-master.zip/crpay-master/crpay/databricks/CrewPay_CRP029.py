# Databricks notebook source
# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;

# COMMAND ----------

#Read Input Data Files
cp_df_samp_proc_ppa_post = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPA_Data_json")
cp_df_samp_proc_ppb_pre  = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPB_Data_json")

#cp_df_samp_proc_ppa_post = spark.read.parquet("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/struct/CREWPAY/PROG28_PPA_Data.parquet")
#cp_df_samp_proc_ppb_pre = spark.read.parquet("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/struct/CREWPAY/PROG28_PPB_Data.parquet")
#cp_df_samp_proc_ppb_pre = spark.read.parquet("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/struct/CREWPAY/PROG28_PPB_Data.parquet")

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *

DataSchema = StructType([StructField("CREW_TKG_RPT", StringType()),StructField("CREW_POST_TKG_RPT", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType())])

def fs(str,len,val):
  return str.rjust(len,val)[:len]
  
CREW_TKG_RPT_DATA_APPEND_LIST = []

# Merging the Two Input Files

from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

cp_df_samp_proc_ppb_pre = cp_df_samp_proc_ppb_pre.sort("NFZ_OUT_NBR",ascending=True)
cp_df_samp_proc_ppa_post = cp_df_samp_proc_ppa_post.sort("NFZ_OUT_NBR",ascending=True)

cp_df_samp_proc_ppb_pre = cp_df_samp_proc_ppb_pre.withColumn("id", F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))
cp_df_samp_proc_ppa_post = cp_df_samp_proc_ppa_post.withColumn("id",F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))

cp_df_samp_proc_ppb_pre1 = cp_df_samp_proc_ppb_pre.selectExpr("NFZ_OUT_STA as PRE_NFZ_OUT_STA","NFZ_OUT_DATA as PRE_NFZ_OUT_DATA","NFZ_OUT_CTR as PRE_NFZ_OUT_CTR","NFZ_OUT_NAME as PRE_NFZ_OUT_NAME","NFZ_OUT_NBR as PRE_NFZ_OUT_NBR","NFZ_OUT_IND as PRE_NFZ_OUT_IND","NFZ_OUT_PART as PRE_NFZ_OUT_PART","id as pre_id")
cp_df_samp_proc_ppa_post1 = cp_df_samp_proc_ppa_post.selectExpr("NFZ_OUT_STA as POST_NFZ_OUT_STA","NFZ_OUT_DATA as POST_NFZ_OUT_DATA","NFZ_OUT_CTR as POST_NFZ_OUT_CTR","NFZ_OUT_NAME as POST_NFZ_OUT_NAME","NFZ_OUT_NBR as POST_NFZ_OUT_NBR","NFZ_OUT_IND as POST_NFZ_OUT_IND","NFZ_OUT_PART as POST_NFZ_OUT_PART","id as post_id")

PPA_PPB_Merge_DF = cp_df_samp_proc_ppb_pre1.join(cp_df_samp_proc_ppa_post1, ((cp_df_samp_proc_ppb_pre1.PRE_NFZ_OUT_NBR == cp_df_samp_proc_ppa_post1.POST_NFZ_OUT_NBR) & ( cp_df_samp_proc_ppb_pre1.pre_id == cp_df_samp_proc_ppa_post1.post_id)), how = 'full')

PPA_PPB_Merge_DF.createOrReplaceTempView("Merge_PPA_PPB")
PPA_PPB_Merge_DF2 = spark.sql("SELECT coalesce(PRE_NFZ_OUT_STA,POST_NFZ_OUT_STA) as PRE_NFZ_OUT_STA,coalesce(PRE_NFZ_OUT_DATA,' ') as PRE_NFZ_OUT_DATA, PRE_NFZ_OUT_CTR, coalesce(PRE_NFZ_OUT_NAME,POST_NFZ_OUT_NAME) as PRE_NFZ_OUT_NAME, coalesce(cast(PRE_NFZ_OUT_NBR as BIGINT),cast(POST_NFZ_OUT_NBR as BIGINT)) as PRE_NFZ_OUT_NBR1, coalesce(PRE_NFZ_OUT_IND,POST_NFZ_OUT_IND) as PRE_NFZ_OUT_IND, coalesce(PRE_NFZ_OUT_PART,POST_NFZ_OUT_PART) as PRE_NFZ_OUT_PART, coalesce(POST_NFZ_OUT_STA,' ') as POST_NFZ_OUT_STA, coalesce(POST_NFZ_OUT_DATA, ' ') as POST_NFZ_OUT_DATA, POST_NFZ_OUT_CTR, coalesce(POST_NFZ_OUT_NAME,PRE_NFZ_OUT_NAME) as POST_NFZ_OUT_NAME, coalesce(cast(POST_NFZ_OUT_NBR as BIGINT),cast(PRE_NFZ_OUT_NBR as BIGINT)) as POST_NFZ_OUT_NBR1, coalesce(POST_NFZ_OUT_IND, PRE_NFZ_OUT_IND) as POST_NFZ_OUT_IND, coalesce(POST_NFZ_OUT_PART,PRE_NFZ_OUT_PART) as POST_NFZ_OUT_PART FROM Merge_PPA_PPB  order by coalesce(coalesce(POST_NFZ_OUT_NBR,999999),coalesce(PRE_NFZ_OUT_NBR,999999)), coalesce(POST_NFZ_OUT_CTR,PRE_NFZ_OUT_CTR) ")

# COMMAND ----------

#Transformation

from functools import reduce
from pyspark.sql import DataFrame

CREW_TKG_RPT_DATA_APPEND_DF=[]

REC_CTR = 0
SAVE_PART = ''
SAVE_STA = ''
SAVE_NBR = ''
HOLD_IND = ''
HOLD_NBR = ''

for row in PPA_PPB_Merge_DF2.rdd.collect(): 
  #print(row)
  if ((row.PRE_NFZ_OUT_NBR1 == row.POST_NFZ_OUT_NBR1)  & (row.PRE_NFZ_OUT_PART == row.POST_NFZ_OUT_PART)) :
    CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
    CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
    NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
    NFZ_OUT_IND = row.POST_NFZ_OUT_IND
    HOLD_IND = row.POST_NFZ_OUT_IND
    if row.PRE_NFZ_OUT_STA == '   ' :
      NFZ_OUT_STA = row.POST_NFZ_OUT_STA
      SAVE_STA = row.POST_NFZ_OUT_STA
    else:
      NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
      SAVE_STA = row.PRE_NFZ_OUT_STA
    NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
    SAVE_NBR = row.PRE_NFZ_OUT_NBR1
    HOLD_NBR = row.PRE_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME
    CREW_TKG_RPT_DATA_TMP1 = "{0},{1},{2},{3},{4},{5},{6},{7}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), fs(str(NFZ_OUT_NAME),17,' '))
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP1.split(','))
    
    
  elif ((row.PRE_NFZ_OUT_NBR1 > row.POST_NFZ_OUT_NBR1)) :
    CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
    CREW_POST_TKG_RPT = ' '
    NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
    if (HOLD_NBR == row.PRE_NFZ_OUT_NBR1) :
      NFZ_OUT_IND = HOLD_IND
    else:
      NFZ_OUT_IND = row.PRE_NFZ_OUT_IND
    NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
    NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME
    
    CREW_TKG_RPT_DATA_TMP2 = "{0},{1},{2},{3},{4},{5},{6},{7}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), fs(str(NFZ_OUT_NAME),17,' '))
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))
  
  elif ((row.PRE_NFZ_OUT_NBR1 < row.POST_NFZ_OUT_NBR1)) :
    print(3)
    CREW_TKG_RPT = ' '
    CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
    NFZ_OUT_PART = row.POST_NFZ_OUT_PART
    NFZ_OUT_IND = row.POST_NFZ_OUT_IND
    if (SAVE_NBR == row.POST_NFZ_OUT_NBR1) :
      NFZ_OUT_STA = SAVE_STA
    else:
      NFZ_OUT_STA = row.POST_NFZ_OUT_STA
    NFZ_OUT_NBR = row.POST_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1    
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.POST_NFZ_OUT_NAME
    
    CREW_TKG_RPT_DATA_TMP3 = "{0},{1},{2},{3},{4},{5},{6},{7}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), fs(str(NFZ_OUT_NAME),17,' '))
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(',')) 

      


# COMMAND ----------

CREW_TKG_RPT_DATA_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_APPEND_LIST,schema=DataSchema)

# COMMAND ----------

display(CREW_TKG_RPT_DATA_APPEND_DF)

# COMMAND ----------

CREW_TKG_RPT_DATA_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_APPEND_LIST,schema=DataSchema)
CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR,CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_CTR).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME").write.mode('overwrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP029_Data_json")

# COMMAND ----------

CREW_TKG_RPT_DATA_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_APPEND_LIST,schema=DataSchema)
CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR,CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_CTR).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME").write.format("delta").mode('overwrite').save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP029_Data_delta")

# COMMAND ----------

#Download the PARQUET format data in Single file
CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR,CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_CTR).coalesce(1).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME").coalesce(1).write.mode('overwrite').parquet("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/struct/CREWPAY/PROG29_Data.parquet")