# CRPAY <br>Data Runbook Document
## Table of contents
=================

<!--ts-->
   * [Modification history](#modification-history)
   * [Document Purpose](#Document-Purpose)
   * [1. Document Overview](#1-document-overview)
   * [2. Introduction](#2-introduction)
   * [3. crpay Infrastructure Overview](#3-OSN-Infrastructure-Overview)
     * [3.1 Platform Details](#31-Platform-Details)
     * [3.2 Databricks Details](#32-Databricks-Details)
     * [3.3 Database/Schema](#33-DatabaseSchema)
     * [3.4 Databricks Workspace Folder](#34-Databricks-Workspace-Folder)
     * [3.5 Key Vault Details](#35-Key-Vault-Details)
     * [3.6 Local Storage account Details](#36-Local-Storage-account-Details)
     * [3.7 Control DB/ABC framework](#37-Control-DBABC-framework)
     * [3.8 ADF dependency framework Details](#38-ADF-dependency-framework-Details)
       * [3.8.1 Execution of crpay](#381-Execution-of-crpay)
       * [3.8.2 Manual Run](#382-Manual-Run)
       * [3.8.3 Disaster Recovery Run](#383-Disaster-Recovery-Run)
   * [4. CICD Details](#4-CICD-Details)
   * [5. Application Details](#5-Application-Details)
     * [5.1 Daily pipelines](#51-Daily-pipelines)
       * [5.1.1 pl_oaoom_optimus_adbde_pbi](#511-pl_oaoom_optimus_adbde_pbi)
     * [5.2 Weekly pipelines](#52-Weekly-pipelines)
       * [5.2.1 Table_Optimization](#521-Table_Optimization)
       * [5.2.2 pl_oaoom_log_tbl_optimize](#522-pl_oaoom_log_tbl_optimize)  
     * [5.3 Monthly workflows](#53-Monthly-workflows)
       * [5.3.1 pl_crewpay_master](#531-pl_crewpay_master)
       * [5.3.2 pl_crewpay_LDCPA_master](#532-pl_crewpay_LDCPA_master)
       * [5.3.3 Table_Optimization](#533-Table_Optimization)
   * [6. Production Support](#6-Production-Support)
   * [7.Contact Information](#7-Contact-Information)
     * [7.1 Upstream Contacts](#71-Upstream-Contacts)
     * [7.2 Downstream Contacts](#72-DownStream-Contacts)
     * [7.3 Platform/Infra Contacts](#73-PlatformInfra-Contacts)
   * [8. Glossary](#8-Glossary)
     * [8.1 Keywords/abbreviations](#81-Keywordsabbreviations)
     * [8.2 Links](#82-Links)
<!--te-->

## **Modification History**
 |**Date**|**Author**|**Version**|**Description**|
 |-------|---------------|---------------|---------------|
 |2025-04-30 |Ramesh Kumar Anand<br>|1.0|Initial Document Creation<br>!! Some sections will be completed at a future date!!|

## **Document Purpose**
  Provides the necesssary details which will help to understand and support the application
## 1. Document Overview
- **Document Title**: CRPAY Runbook Document
- **Template Version**: 1.0
- **Document Version**: 1.0
- **Date**: 04/24/2025
- **Author(s)**:  Ramesh Kumar Anand
- **Audience**: Data Architects, Engineers, Product Technical Leaders, Managers 
- **Last Reviewed Date:** 
    
- **Next Review Date:** <code style="color : red">TBD</code>

## 2. Introduction
- **Archer Application** (App Short Name): crpay
 - crpay wiki: (https://wiki.aa.com/bin/view/Ops%20Data%20Lake/Crew%20Domain/)
- **Overall ASN Criticality**: 
   - Criticality: Important
   - RPO: <24 hours
   - RTO: <1 Hour
- **Application Overview**:
  CRPAY is a critical enterprise-grade solution developed on Azure that automates the end-to-end crew pay file processing lifecycle. It ingests, validates, transforms, and delivers pay-related files from FOS mainframes and other systems to payroll consumers, enabling timely and accurate crew compensation.<br>
- **Business Overview**:
  CRPAY ensures that pre- and post-flying compensation data is accurately processed and matched according to business rules. By comparing operational stats and applying validations like month checks, record counts, and format compliance, it prevents pay anomalies and supports contractual integrity in payroll processing.<br>
- **Product Overview**:
  CRPAY leverages components like eMFT, Megatron, Optimus, ADF (legacy), and now Databricks (Spark ADDBE) for data transformation. Files are validated and archived across zones (Raw, Archive, History Archive), and outputs are used to generate reports in Power BI (dashboard + paginated reports). Azure Alerts, email notifications, and integrations with Cherwell and xMatters support incident tracking and visibility.<br>
- **Scope**:
  The CRPAY project scope includes secure file ingestion from FOS via Z/Linux, HIS binary-to-ASCII conversion, rule-driven data transformation, compensation metadata generation, and downstream delivery to ePays and reporting systems. It supports both scheduled and manual executions, disaster recovery via West region, and real-time monitoring and alerting for business continuity.<br><br>

## 3.1 **Platform Details**: 
| Name                  |     NonProd                               |     Prod                                |
|-----------------------|-------------------------------------------|-----------------------------------------|
| Azure Primary Region  | `EAST US`                                 | `EAST US`                               |
| Azure DR Region       | `WEST US`                                 | `WEST US`                               |
| Subscription Name     | `aa-ba-nonprod-spoke`                     | `aa-ba-prod-spoke`                      |
| Resource Group Name   | `ba-n-zeaus-crwdtaprtl-rg`                | `ba-p-zeaus-crwdtaprtl-rg`              |
| ASN Resource Group    | `ba-n-zeaus-crwdtaprtl-rg`                | `ba-p-zeaus-crwdtaprtl-rg`              |
| ASN storage Name      | `baneausstgcrwdtaprtl`                    | `bapeausstgcrwdtaprtl`                  |
| ASN container Name    | `crpay`                                   | `crpay`                                  |            
| Local storage Name    | `baneausstgcrwdtaprtl`                | `bapeausstgcrwdtaprtl`   |
| ADLS Name             | `aabaoriondlsnp`                          | `aabaoriondlsprod`                      |
| ADLS Container Name   | `crpay`, `crpay-pii`                      | `crpay`, `crpay-pii`|
| ADB Workspace Name    | `ba-n-zeaus-orion-adbde-dbws-007`         | `ba-p-zeaus-orion-adbde-dbws-007`,`ba-p-zweus-orion-adbde-dbws-007`       |
| ADB Workspace Link    | [NonProd](https://adb-3089640846425798.18.azuredatabricks.net) | [Prod East](https://adb-8498854267871066.6.azuredatabricks.net/), [Prod West](https://adb-12293667324264.4.azuredatabricks.net/?o=12293667324264) |
| ADF Name              | `n-zeaus-crpay-adf-004`            | `p-zeaus-crpay-adf-004` ,  `p-zweus-crpay-adf-004`                  |
| ADF Link              | [NonProd](https://adf.azure.com/en/home?factory=%2Fsubscriptions%2Fae0b13d9-e09c-4e54-b1e6-8e777d8fbe14%2FresourceGroups%2Fba-n-zeaus-crwdtaprtl-rg%2Fproviders%2FMicrosoft.DataFactory%2Ffactories%2Fn-zeaus-crpay-adf-004)            | [ProdEast](https://adf.azure.com/en/home?factory=%2Fsubscriptions%2Fc450f3d1-583c-495f-b5d3-0b38b99e70c0%2FresourceGroups%2Fba-p-zeaus-crwdtaprtl-rg%2Fproviders%2FMicrosoft.DataFactory%2Ffactories%2Fp-zeaus-crpay-adf-004),[ProdWest](https://adf.azure.com/en/home?factory=%2Fsubscriptions%2Fc450f3d1-583c-495f-b5d3-0b38b99e70c0%2FresourceGroups%2Fba-p-zweus-crwdtaprtl-rg%2Fproviders%2FMicrosoft.DataFactory%2Ffactories%2Fp-zweus-crpay-adf-004)                   |
| EventHub Name         | `NA`                                      | `NA`                                    |
| ASN App Service Principal Name | `ba-n-crpay-sp`                  | `ba-p-crpay-sp`                         |
| ASN CICD Service Principal Name| `ba-n-cicd-crpay-sp`             | `ba-p-cicd-crpay-sp`                    |
| App Service Principal Name     | `ba-n-crpay-sp`                  | `ba-p-crpay-sp`                         |
| CICD Service Principal Name    | `ba-n-cicd-crpay-sp`             | `ba-p-cicd-crpay-sp`                    |
| Key Vault Name    | `ba-n-zeaus-crwdtaprtl-kv`             | `ba-p-zeaus-crwdtaprtl-kv`                    |
| Logic app for email notification    | `NA`             | `NA` |
| Logic app for adf orchestration    | `NA` | `NA`  |
 

### 3.2 **Databricks Details**: 

| Name                  | NonProd                                      | Prod                                    |
|-----------------------|-------------------------------------------|-----------------------------------------|
| Cluster Name          | `n-crpay-adbde-cl-101`      | `p-crpay-adbde-cl-101`       |
| Required libraries    |`teradatasql,O365==2.0.28` | `teradatasql,O365==2.0.28` |
| Databricks Workspace  | `ba-n-zeaus-orion-adbde-dbws-007`         |  `ba-p-zeaus-orion-adbde-dbws-007`      |
| Job Cluster           |  `NA`                                 |`NA` |

### 3.3 **Database/Schema**: 

|Schema Name                   |    Description                                                      |
|------------------------------|---------------------------------------------------------------------|
| crpay_struct            | ADLS  database for struct layer tables                       |
| crpay_prep            | ADLS  database for prep layer tables                       |

### 3.4 **Databricks Workspace Folder**: 
| Path                               | Description                               | 
|------------------------------------|-------------------------------------------|
| crpay/crpay_pii/    | Contains notebooks needed for incremental, archival,trans load & Table Optimization|

### 3.5 **Key Vault Details**: 
| Key Name                                        | Description                                                                            | 
|-------------------------------------------------|----------------------------------------------------------------------------------------|
| ba-p-crpay-001-cicd-sp-secret                | cicd service principal secret                                                       |
| ba-p-crpay-001-sp-secret  | application service principal secret                                      |
| ba-crpay-blob-key                    | blob key                                                |
| ba-crpay-fsweb-pbi-sp-secret                    | fsweb-power bi service principal secret                                                |
| ba-p-crpay-adbde-secret                    | databricks bearer token secret                                                |
| ba-p-crpay-epays-blob-key                    | epays blob key                                                |
| ba-p-crpay-mosaic-functionalId-secret                    |       mosaic functionalId secret                                          |
| ba-p-cicd-crwdtaprtl-001-sp-client-id  | crwdtaprtl cicd service principal client id                                       |
| ba-p-cicd-crwdtaprtl-001-sp-secret  | crwdtaprtl cicd service principal secret                                       |
| ba-p-crwdtaprtl-001-sp-client-id  | crwdtaprtl application service principal client id                                       |
| ba-p-crwdtaprtl-001-sp-secret  | crwdtaprtl application service principal secret                                       |




### 3.6 **Local Storage account Details**: 
| Container/Folder                  | Description                               | 
|-----------------------------------|-------------------------------------------|
| crpay/optimize_tables_monthly.txt                           | Contains monthly tables details for optimization |
| crpay/parameter_Crpay_Optimize.json                            | Contains table optimization parameters |
| crpay/parameter_Crpay_Optimize_west.json                           | Contains table optimization parameters for west region |
| crpay/optimize_tables_daily_weekly.txt                           | Contains daily/weekly table details for optimization |
| crpay/PBIParameters.json                           | Contains PBI parameters |
| crpay/Parameters.json                           | Contains crpay parameters |
| crpay/Parameters_West.json                          | Contains west crpay parameters |
| crpay/crpayJobCluster.json                           | Contains job cluster details |
| crpay/ls_crewpay_adb_temp.json                          | Contains adb linked service details  |
| crpay/ls_crewpay_adb_temp.west.json                          | Contains adb linked service details for west adb |

### 3.7 **Control DB/ABC framework**: 
NA

### 3.8 **ADF dependency framework Details**: 

**High Level Architecture Diagram** ![architecture_crpay](image/CRPAY_ARCHITECTURE.png)

### 3.8.1 **Execution of crpay**
**Scheduled Run**:  The scheduled run is an automated process, requiring no manual intervention. Below are the steps describing how the scheduled run is executed:<br>
1. **Application Development:-**
The Crpay application is developed in Azure cloud using Azure services such as ADF, ADLS Gen 2, ADB, Blob Storage, Power BI Paginated reports, Power BI report builder and Power BI dashboard are being used respectively. <br>

2. Pre and post files are landed post HIS conversion (which converts Binary into ASCII) into landing zone which is raw-pii folder.<br>
3. Once Files start arriving into landing zone, based on individual event triggers, process is started by ADF. Below diagram depicts four event triggers are designed for individual pre and post files. ![triggers_crpay](image/crpay_file_event-triggers.png)
4. In ADF, Master pipeline is kicked off first where lookup activity gets configuration details from Configuration file named Parameters.json stored in blob storage and call child pipelines based on module name like PPA or PPB, here PPA and PPC to be processed in post run child pipeline while pre like PPB and PPD to be processed in precapture child pipeline.<br>
![master_crpay](image/CRPAY_MASTER_PIPELINE.png)
5. As per business, pre file like PPB or/and PPD are executed first:
  -  If either or both pre files don’t arrive at end of the day of 27th of every month then mail would be triggered to notify targeted recipients that no pre file /files are not received on the same day. Below screen shot illustrates of Subject and body of mail
  ![email_crpay](image/FILE_CHECK_EMAIL_NOTIFICATION.png)
            
  -  When pre files processing gets started, there is a notebook named “Count_Validation” which ensures validating counts of raw and converted pre files. <br> 
     Below is type of mail would be sent when count mismatches.
  ![email_count_mismatch](image/COUNT_MISMATCH_ALERT_EMAIL.png)
            
  -  Another check to be performed before pre files processed which is to make sure that correct month file to be processed      
     e.g. for Jan 2021 month, Feb month data to be processed in pre files so check would ensure that only Feb month data would be allowed and for rest process would get 
     terminated with below mail.
    ![email_post_month_validation](image/POST_MONTH_VALIDATION_EMAIL.png)
            
  - While, pre files are processed well, notification will be sent to targeted recipients in below format.  
    ![email_month_end_process_sucessful](image/MONTH_END_PROCESS_SUCCESSFUL_NOTIFICATION.png)
  - Once pre files are completely processed, pre files are immediately archived in archived zone. 

6. In case of post files first three sub steps from point ‘5’ to be carried out along with few additional steps as follow:
   - Post child pipeline in ADF makes sure that right combination of pre and post files to be executed.  
     e.g. PPA and PPB
          PPC and PPD 
   - Together pre and post data are processed and stored into Prep zone for further reporting purpose. 
   - Corresponding Epays files are stored into Blob storage for further downstream use.
     
7. Post Files are present in raw zone are archived into archived zone. 

8. Immediate after Archive zone, same files are moved into his-converted-archive zone. 

9. At last Power BI report is refreshed. 


### 3.8.2 **Manual Run**: 
Step to follow to run crpay process manually. 
1. First disable/deactivate four triggers by navigating into Data Factory à Manageà Triggersà
  Trigger names are as below to be deactivated. Same is also shown into below diagram. 
  crewpay_ppa
  crewpay_ppb
  crewpay_ppc
  crewpay_ppd
  ![triggers_crpay](image/crpay_file_event-triggers.png)
2. After triggers are deactivated, publish it by clicking on Publish button in ADF.
  ![adf_publish_crpay](image/CRPAY_ADF_PUBLISH.png)
3. Go back to Master pipeline window by clicking on Author option. Click on the master pipeline pl_crepay_master within Folder Crewpay. Diagram should be look as below. 
  ![pl_master_crpay](image/PL_CRPAY_MASTER.png)
4. Click on debug mode and pass Four pipeline parameters in order to run process manually. 
 Crewpay_Run:  This accepts module name for instance PPB or PPB.  
 Year:  Year which you are running process. 
 Month: Month which you are running process. 
 LOAD_TYPE : Type only ‘M’
  ![pipeline_parameters](image/PIPELINE_PARAMETER.png)
 Parameter sample Values:  
 PPA 
 2020 
 12 (1,2,3,4,5,6,7,8,9,10,11,12)
 M 

** if the month is single digit like august please pass the value 8 instead of 08  

Note:  Manual run does work only for one-month history data load, it does not support any range in terms of Month or/and Year. Hence, be careful while processing data. 

         
 ### 3.8.3 **Disaster Recovery Run**:  
 Because of critical applications we have designed west region with same as east region. If east region down with any unexpected incidents, then we can manually run in the 
 west region. 

 West ADF Name : p-zweus-crpay-adf-004 

 West Databricks URL : https://adb-12293667324264.4.azuredatabricks.net/ 



# 4. CICD Details
We are using ADO Actions for the deployment of azure data factory, azure databricks.<br>
## Workflow/ADO Description:
| Workflow/ADO | Description |
|--------------|-------------|
| crpay_adb_build_np | Build for non prodution ADB notebook deployment.|
| crpay_adbde_np_notebook_deployment |ADO pipeline for  ADB notebook deployment in non production environment.|
| crpay_adb_notebooks| Build for prodution ADB notebook deployment.|
| crpay_adbde_notebooks_deploy|ADO pipeline for ADB notebook deployment in production environment.|
| crpay_adf| Build for ADF pipeline deployment in production environment.|
| crpay_adf_parameter| Build for ADF pipeline parameters deployment in production environment.|
| crpay_adf_pipeline|ADO pipeline for ADF Pipeline deployment in production environment.|
| crpay_adf_parameter|ADO pipeline for ADF Pipeline Parameter deployment in production environment.|
| crpay_adbde_token_app_id|  token generation for non production / production environment.|
| crpay_west_adbde_cicd_token| cicd token generation for west non production / production environment.|



# 5. Application Details 

| Pipeline Name              | Trigger Name      | Frequency               | Schedule Time          |
|----------------------------|-------------------|-------------------------|------------------------|
| pl_crewpay_master| crewpay_ppd,crewpay_ppb,crewpay_ppc,crewpay_ppa| Monthly   | On file arrival|
| pl_crewpay_LDCPA_master | crewpay_lda,crewpay_ldc,crewpay_ldp|Monthly| On file arrival | 
| pl_oaoom_optimus_adbde_pbi| crewpay_oaoom|Daily   | at 8,12,16,1 hours|
| Table_Optimization| ceewpay_Table_optimize| Weekly   | at 15:00 hours central time zone|
| pl_oaoom_log_tbl_optimize| oaoom_optimize| Weekly   | at 02:00 hours central time zone|



## 5.1 Daily pipelines
### 5.1.1 pl_oaoom_optimus_adbde_pbi

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | Pipeline for oaoom optimus adbde power bi dataset refersh              | 
| File Dependency       | NA                                                                            |  
| Upstream Dependency   | Power BI   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `NA`                                                          | 
| Target Tables         | `NA`                                                                                 | 
| Target Load Type      | NA                                                                                 |
| File Frequency        | NA                                                                                              |  
| Download File Format  | NA                                                                                      |  
| Landing File Directory| NA                                                                                                | 
| ADLS File Directory   | abfss://crpay@aabaoriondlsprod.dfs.core.windows.net/delta-prep/Reports/                                                                  | 
| Archive Directory     | NA                                                                                                |  
| Source Provider Contact| DL_eMFT_Admins@aa.com                                                                                   |  
| Job SLA Time (CST)     | < 1 hour


## 5.2 Weekly pipelines

### 5.2.1 Table_Optimization

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | weekly/Monthly Optimize and Vaccum of crpay tables               | 
| File Dependency       | NA                                                                            |  
| Upstream Dependency   | NA   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `crpay_prep `                                                         | 
| Target Tables         | `optimuslog`,`oaoom_optimus`,`oaoomlog`                                                                                 | 
| Target Load Type      | NA                                                                                 |
| File Frequency        | NA                                                                                              |  
| Download File Format  | NA                                                                                      |  
| Landing File Directory| NA                                                                                                | 
| ADLS File Directory   | abfss://crpay@aabaoriondlsprod.dfs.core.windows.net/delta-prep/                                                                  | 
| Archive Directory     | NA                                                                                                |  
| Source Provider Contact| DL_eMFT_Admins@aa.com                                                                                   |  
| Job SLA Time (CST)     | < 1 hour  

### 5.2.2 pl_oaoom_log_tbl_optimize

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | weekly/ Optimize and Vaccum of oaoom log table                | 
| File Dependency       | NA                                                                            |  
| Upstream Dependency   | NA   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `NA`                                                          | 
| Target Tables         | `NA`                                                                                 | 
| Target Load Type      | NA                                                                                 |
| File Frequency        | NA                                                                                              |  
| Download File Format  | NA                                                                                      |  
| Landing File Directory| NA                                                                                                | 
| ADLS File Directory   | abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/                                                                  | 
| Archive Directory     | NA                                                                                                |  
| Source Provider Contact| DL_eMFT_Admins@aa.com                                                                                    |  
| Job SLA Time (CST)     | < 1 hour  


## 5.3 Monthly pipelines
### 5.3.1 pl_crewpay_master

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | Crewpay Master Pipeline               | 
| File Dependency       | `gets triggerd on file arrival`                                                                           |  
| Upstream Dependency   | NA   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `crpay_struct`,`crpay_prep`            | 
| Target Tables         | `crpay_struct.crp028_ppa`,	`crpay_struct.crp029_ppa_ppb`,	`crpay_prep.crp030_ppa_ppb_report`,	`crpay_struct.crp028_ppb`,	`crpay_struct.crp028_ppc`,	`crpay_struct.crp029_ppc_ppd`,	`crpay_prep.crp030_ppc_ppd_report`,	`crpay_struct.crp028_ppd` | 
| Target Load Type      | Incremental |
| File Frequency        |  monthly   |  
| Download File Format  | Parquet file        |  
| Landing File Directory| `raw-pii/PPA/conversionReport.AAPPA`,`raw-pii/PPB/conversionReport.AAPPB`,`raw-pii/PPC/conversionReport.AAPPC`,`raw-pii/PPD/conversionReport.AAPPD`      | 
| ADLS File Directory   | abfss://crpay-pii@aabaoriondlsprod.dfs.core.windows.net/prod/  | 
| Archive Directory     | NA   |  
| Source Provider Contact| DL_eMFT_Admins@aa.com |  
| Job SLA Time (CST)     | < 1 hour       |                                                                                    

### 5.3.2 pl_crewpay_LDCPA_master

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | Master pipeline for crew pay LDCPA               | 
| File Dependency       | `gets triggerd on file arrival`                                                                            |  
| Upstream Dependency   | NA   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `crpay_struct`,`crpay_prep` | 
| Target Tables         |  `crpay_struct.lda_data`,	`crpay_prep.lda_report`,	`crpay_struct.ldc_data`,	`crpay_prep.ldc_report`,	`crpay_prep.ldc_fa_web_report`,	`crpay_struct.ldp_data`,	`crpay_prep.ldp_report`,	`crpay_prep.ldp_pilot_web_report`                             | 
| Target Load Type      | Incremental                                                                                 |
| File Frequency        | Monthly                                            |  
| Download File Format  | Parquet file         |  
| Landing File Directory| `raw-pii/LDA/conversionReport.AALDA`,`raw-pii/LDC/conversionReport.AALDC`,`raw-pii/LDP/conversionReport.AALDP` | 
| ADLS File Directory   | abfss://crpay-pii@aabaoriondlsprod.dfs.core.windows.net/prod/         | 
| Archive Directory     | NA    |  
| Source Provider Contact| DL_eMFT_Admins@aa.com    |  
| Job SLA Time (CST)     | < 1 hour  | 

### 5.3.3 Table_Optimization

| Name                  | Details                                                                                            |
|-----------------------|----------------------------------------------------------------------------------------------------|
| Function              | Monthly Optimize and Vaccum of crpay tables               | 
| File Dependency       | NA                                                                            |  
| Upstream Dependency   | NA   | 
| Downstream Dependency | NA                                                                                                 | 
| Input Source Name     | NA                                                                             | 
| Target Schema         | `crpay_struct`, `crpay_prep`                                                          | 
| Target Tables         | `lda_data`,	`lda_report`,	`ldc_data`,	`ldc_report`,	`ldc_fa_web_report`,	`ldp_data`,	`ldp_report`,	`ldp_pilot_web_report`,	`crp028_ppa`,	`crp029_ppa_ppb`,	`crp030_ppa_ppb_report`,	`crp028_ppb`,	`crp028_ppc`,	`crp029_ppc_ppd`,	`crp030_ppc_ppd_report`,	`crp028_ppd`                                                                                 | 
| Target Load Type      | NA                                                                                 |
| File Frequency        | NA                                                                                              |  
| Download File Format  | NA                                                                                      |  
| Landing File Directory| NA                                                                                                | 
| ADLS File Directory   | abfss://crpay-pii@aabaoriondlsprod.dfs.core.windows.net/prod/                                                                  | 
| Archive Directory     | NA                                                                                                |  
| Source Provider Contact| DL_eMFT_Admins@aa.com                                                                                   |  
| Job SLA Time (CST)     | < 1 hour  

# 6. Production Support
We work in a DevOps model where we need to maintain and support the operations for all the jobs that we develop. Team follows the roster model where one person will be doing the oncall support for 7 days from Monday to Sunday.

[Prod support reference](https://spteam.aa.com/:x:/r/sites/FOSComplexAModernization/_layouts/15/Doc.aspx?sourcedoc=%7BEED19759-EEFC-4555-B448-C72FF22FAD5A%7D&file=TeamContacts.xlsx&action=default&mobileredirect=true&DefaultItemOpen=1) has all the vital details of the project and the support person name.

[Prod Incident Tracker](https://spteam.aa.com/:x:/r/sites/BA-Crew/_layouts/15/Doc.aspx?sourcedoc=%7BB7762009-661C-4080-9F5B-1A7EFB56249D%7D&file=Incidents%20for%20Crew%20Data%20Portal.xlsx&action=default&mobileredirect=true&DefaultItemOpen=1) maintains track for the prod support incidents to keep a check and improve on MOI metrics and the applications resiliency.

# 7  Contact Information

### 7.1 Upstream Contacts

 |**Name**|**Team Name**|**Team Email**|**Description**|**XMatter**|
 |------------|-------|-------|---------------|---------------|
 | Jason Gammage  | HIS Conversion Team |  Jason.Gammage@aa.com | If any issues with Data file conversion (Binary To ASCII)  | NA   |
 | DEA Airline Operations team       | Megatron Dev Team  | DL_BA_AirlineOperations@aa.com | If data file not arrived from common landing zone to raw-pii  | NA   |
 | Contact FOS, eMFT | FOS prod Team  | `DL_eMFT_Admins@aa.com`,`DL_BA_AirlineOperations@aa.com`,`realtime.coverage@dxc.com`,`rtcleads@dxc.com` | File not present in common landing zone or files didn’t arrive on time  | NA   |
 | eMFT       | eMFT team |1. Call helpdesk at 1-866-523-5333. Ask the person to raise high priority Incident for eMFT team. Also ask Help Desk to create  | Files didn’t arrive  | NA   |
 
 
    

### 7.2 DownStream Contacts

 |**Name**|**Team Name**|**Team Email**|**Description**|**XMatter**|
 |------------|-------|-------|---------------|---------------|
 |   CrewComp         | CrewComp       |   DL_CC_Application_Team@aa.com     |     Crew Compensation Team will use the end reports           |      NA          |
 |           |       |       |               |                |
 |           |       |       |               |                |
 |           |       |       |               |                |

 ### 7.3 Platform/Infra Contacts

 |**Team Name**|**Team Email**|**Description**|**XMatter**|
 |-----------|-------|-------|---------------|
 | Rigel     | DL_Bus_Analytics_Rigel@aa.com       | One platform squad for Orion and Mosaic issues        |    bus_analytics_orion@team.aa.xmatters.com             |                             
 | Mosaic    | support.mosaic@aa.com      | Teradata DBA team      | Mosaic_Team@team.aa.xmatters.com              |                
 | EMFT      | DL_eMFT_Admins@aa.com      | EMFT admin team      | NA             |                
 | DataOps      | DL_DEA_DataOps@aa.com     | DataOps admin team for any github, adf framework related issues      | NA             |   
  
 

## 8. Glossary
### 8.1 Keywords/abbreviations
 |**Key word/abbreviation**|**Meaning**|
 |-----------|-------|
 | ASN     | Archer Short Name       |
| OSN     | Orion Short Name or app code       |
| DR     | Disastor Recovery       |
### 8.2 Links
  Provide Links to Archer, OneTrust, Runbook, etc.

