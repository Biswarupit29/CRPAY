# Databricks notebook source
# DBTITLE 1,LDA raw_to_prep
"Version History of LDA raw_to_prep"

"Changes:"

"Developer: Nitin"
"Date Created: 12/05/2020"
"Date Updated : 02/23/2021"
"Purpose: Read LDA data from Raw zone and Load into Delta-prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Rejected_Records_path", "")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
receiver_emails = receiver_emails.split()

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# log report function param's 
import datetime

SYS_NM = "crpay"
SRC_FILE_NM = get_drain_file_name(Input_File)
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"



# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time
# The log will be written in the success folder 

SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Read LDA Records from Raw Zone
#Read Input Data Files for LDA and get Source_File name and LOAD time appended into DF
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
try:
  #Input_File_Path = Input_File 
  Input_File_Path = Input_File + 'AALD*.json'

  if((LOAD_TYPE == 'M') or (LOAD_TYPE == 'm')):
    if('LDA' in Input_File_Path):
      cr098_pli_df = spark.read.json(Input_File_Path)
      cr098_count_df= cr098_pli_df.count()
      #send_email(sender_email, receiver_emails, 'CREWPAY-LDA Manual Load', 'Successful Manual Load for CREWPAY-LDA is Started.', bcc=None, attachments = None)
      send_email(receiver_emails, 'CREWPAY-LDA Manual Load', 'Successful Manual Load for CREWPAY-LDA is Started.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    else:
      print("LDP or LDC")
  else:
    if('LDA' in Input_File_Path):
      cr098_pli_df = spark.read.json(Input_File_Path)
      cr098_count_df= cr098_pli_df.count()

    else: 
       print("LDP or LDC")
  MSG_DESC = "LDA data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read LDA records from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,validate count of src input file before and after bad records 
#to identify bad records , load them into specified reject path thn remove those bad records for further use
try:
  cp_pii_df = spark.read.format("json").option("badRecordsPath",Rejected_Records_path ).load(Input_File_Path)
  # adding audit columns as an input file name and LOAD TIME in Data frame
  cp_pii_df = cp_pii_df.withColumn("sourcefile",col("_metadata.file_path"))
  regex_str = "[\/]([^\/]+)$"
  cp_pii_df = cp_pii_df.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))
  cp_pii_df_count =cp_pii_df.count()

  if(cr098_count_df==cp_pii_df_count):
    print("no bad records in inpout file")
  else:
    bad_records_count = (int(cr098_count_df)-int(cp_pii_df_count))
    print("bad records count: "+str(bad_records_count))
    #send_email(sender_email, receiver_emails, "Crewpay-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: Crewpay-"+ Crewpay_Run + "\r\r\nBad Records Count : {0} \r\nBad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), bcc=None, attachments = None)
    send_email(receiver_emails, "Crewpay-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: Crewpay-"+ Crewpay_Run + "<br>Bad Records Count : {0} <br>Bad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    
  MSG_DESC = "performed Count valdaition successfully of src input file before and after bad records"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to validate count of src input file before and after bad records. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

# DBTITLE 1,File_Format_Validation
#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0
try:
  #Checks Files Emptiness and both has equal records
  count_check=0
  cnt1=cp_pii_df.count()

  if(cnt1!=0):
    count_check=1# RESULT OF COUNT CHECK

  #Checks has all required columns
  columns_checkv1=1
  expected_cols=['IAB','IBAS','IBCK','IDAT','IEMP','IFILL1','IFILL2','ILIN','IMON','IMSG','INBR','IRPTHDR','ISEA','ISEQ','ISLOT','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
  for cols in cp_pii_df.columns:
    if(cols not in expected_cols):
      columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1
  if(count_check==1 & columns_checkv1==1):
    print("Success")
    #send_email(sender_email , receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for Crewpay-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for Crewpay-' +Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    MSG_DESC = "File_Format_Validation looks fine"
    END_TMS = str(datetime.datetime.now())
    STATUS_CD = "S"
    SAVE_PATH = SUCCESS_PATH
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    print("Failure")
    #send_email(sender_email , receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and Format of file is not as expected for Crewpay-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(sender_email , receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and Format of file is not as expected for Crewpay-' +Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    dbutils.notebook.exit("Failure")
except Exception as e:
      MSG_DESC = "Failed to validate File_Format_Validation. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cr098_pl=cp_pii_df.sort(cp_pii_df.REC_NUMBER.asc())


# COMMAND ----------

# defined Schema for output Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

RepSchema = StructType([StructField("IBAS", StringType()),StructField("IDAT", StringType()),StructField("IEMP", StringType()),StructField("ILIN", StringType()),StructField("IMON", StringType()),StructField("IRPTHDR", StringType()),StructField("ISEQ", StringType()),StructField("ISEA", StringType()),StructField("ISLOT", StringType()),StructField("INBR", StringType()),StructField("IAB", StringType()),StructField("FIXED_DATE", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])


# COMMAND ----------

# DBTITLE 1,Data Processing for LDA files
#data processing for LDA files
import re
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import current_date
import datetime
try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  NFZ_RPT_OUT_TMP_APPEND_LIST = []
  NFZ_RPT_OUT_TMP_APPEND_LIST_AB = []
  NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB = []
  REC_NUM_AB = 0
  REC_NUM_NAB = 0
  FIXED_DATE = "1966-01-02" 

  for row in cr098_pl.collect():
    OCCU_NUMBER_PER_RECORD = row.IBCK 
    AB = row.IAB
    EMP_NBR = row.IEMP
    IBAS = row.IBAS
    IMON = row.IMON
    DATE_NUMBER = row.IDAT
    ISEA = row.ISEA
    SEQ_NUMBER= row.ISEQ
    I_NUMBER = row.INBR
    m_RPTHDR = re.search(r'(.\/.*?(?P<DM>.*))', row.IRPTHDR)
    RPTHDR = m_RPTHDR['DM'] if m_RPTHDR else ''
    SLOT = row.ISLOT
    LOAD_TIME= row.LOADTIME
    SOURCE_FILENAME = row.SOURCE_FILE
    for A in range(0,OCCU_NUMBER_PER_RECORD):
         if(AB=='AB'):

                  ILIN = row.ILIN[A]
                  pad = ' ' * (64-len(ILIN))
                  REC_NUM_AB = REC_NUM_AB+1
                  REC_NUM_ZERO = fs(str(REC_NUM_AB),7,'0')

                  if(ILIN==''):
                    FLAG =1 
                  else:
                    NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}".format(IBAS,DATE_NUMBER,EMP_NBR,ILIN,pad,IMON,RPTHDR,SEQ_NUMBER,ISEA,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                    NFZ_RPT_OUT_TMP_APPEND_LIST_AB.append(NFZ_RPT_OUT_TMP.split(','))

         else:

                    ILIN = row.ILIN[A]
                    pad = ' ' * (64-len(ILIN))
                    REC_NUM_NAB = REC_NUM_NAB + 1
                    REC_NUM_ZERO = fs(str(REC_NUM_NAB),7,'0')

                    if(ILIN==''):
                          FLAG =1 
                    else:
                      NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}".format(IBAS,DATE_NUMBER,EMP_NBR,ILIN,pad,IMON,RPTHDR,SEQ_NUMBER,ISEA,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                      NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB.append(NFZ_RPT_OUT_TMP.split(','))

  MSG_DESC = "LDA Files are sucessfully processed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process LDA Files. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e


# COMMAND ----------

#create unique ID to intact Absolute and Actual Base data based upon EMP_NBR , DATE and SLOT
from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

NFZ_RPT_OUT_TMP_APPEND_DF_AB = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST_AB,schema=RepSchema)
NFZ_RPT_OUT_TMP_APPEND_DF_AB = NFZ_RPT_OUT_TMP_APPEND_DF_AB.withColumn("id", F.rank().over(Window.partitionBy("IEMP","IDAT","ISLOT").orderBy("REC_NUM")))

NFZ_RPT_OUT_TMP_APPEND_DF_NONAB = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB,schema=RepSchema)
NFZ_RPT_OUT_TMP_APPEND_DF_NONAB = NFZ_RPT_OUT_TMP_APPEND_DF_NONAB.withColumn("id", F.rank().over(Window.partitionBy("IEMP","IDAT","ISLOT").orderBy("REC_NUM")))  


# COMMAND ----------

#Merge two data based upon business criteria so that Absoulte and Actual data can be kept togehter as needed 
NFZ_RPT_OUT_TMP_APPEND_DF_AB.createOrReplaceTempView("ABS_TABLE")
NFZ_RPT_OUT_TMP_APPEND_DF_NONAB.createOrReplaceTempView("ACT_TABLE")

LDA_MERGE_DF = spark.sql("select abs.IBAS as ABS_IBAS,abs.IDAT as ABS_IDAT,abs.IEMP as ABS_IEMP,abs.ILIN as ABS_DATA,abs.IMON as ABS_MON,abs.IRPTHDR as ABS_DATE,abs.ISEQ as ABS_ISEQ,abs.ISEA as ABS_ISEA,abs.ISLOT as ABS_SLOT,abs.INBR as ABS_INBR,abs.REC_NUM as ABS_REC_NUM,coalesce(abs.id,act.id)as ABS_ID, act.IBAS as ACT_IBAS,act.IDAT as ACT_IDAT,act.IEMP as ACT_IEMP,act.ILIN as ACT_DATA,act.IMON as ACT_MON,act.IRPTHDR as ACT_DATE,act.ISEQ as ACT_ISEQ,act.ISEA as ACT_ISEA,act.ISLOT as ACT_SLOT,act.INBR as ACT_INBR,act.REC_NUM as ACT_REC_NUM,coalesce(abs.FIXED_DATE,act.FIXED_DATE)as FIXED_DATE,coalesce(abs.LOAD_TIME,act.LOAD_TIME)as LOAD_TIME,coalesce(abs.SOURCE_FILENAME,act.SOURCE_FILENAME)as SOURCE_FILENAME,coalesce(act.id,abs.id)as ACT_ID from ABS_TABLE abs FULL OUTER JOIN ACT_TABLE act ON abs.IEMP=act.IEMP and abs.IDAT=act.IDAT and abs.ISEQ=act.ISEQ and abs.ISEA=act.ISEA and abs.ISLOT=act.ISLOT and abs.INBR=act.INBR and abs.id=act.id order by  coalesce(ABS_IDAT,ACT_IDAT),coalesce(ABS_REC_NUM,ACT_REC_NUM)")


# COMMAND ----------

#Select required column for further processing.
LDA_MERGE_DF.createOrReplaceTempView("LDAVIEW")

LDAP_DATA_DF = spark.sql("SELECT coalesce(ABS_IBAS,ACT_IBAS) as IBAS,coalesce(ABS_IDAT,ACT_IDAT) as IDAT, coalesce(ABS_IEMP,ACT_IEMP) as IEMP, coalesce(ABS_DATA,' ') as ABSOLUTE_BASE_DATA, coalesce(ACT_DATA,' ') as ACTUAL_BASE_DATA,coalesce(ABS_MON,ACT_MON) as MONTH,coalesce(ABS_DATE,ACT_DATE) as DATE_MONTH, coalesce(ABS_ISEQ, ACT_ISEQ) as SEQ_NUM,coalesce(ABS_ISEA, ACT_ISEA) as ISEA,coalesce(ABS_SLOT, ACT_SLOT) as SLOT,coalesce(ABS_INBR, ACT_INBR) as INBR,coalesce(ABS_REC_NUM,ACT_REC_NUM) as ABS_REC_NUM,coalesce(ACT_REC_NUM,ABS_REC_NUM) as ACT_REC_NUM,FIXED_DATE,LOAD_TIME,SOURCE_FILENAME,coalesce(ABS_ID,ACT_ID) as ID FROM LDAVIEW  order by coalesce(ACT_REC_NUM,ABS_REC_NUM) ")

# COMMAND ----------

from pyspark.sql.functions import *
LDAP_DATA_DF2 = LDAP_DATA_DF.orderBy("IDAT","IEMP","SEQ_NUM","SLOT","INBR","ID",'ABS_REC_NUM',"ACT_REC_NUM")
LDAP_DATA_DF_REC1 = LDAP_DATA_DF2.withColumn("PARTITION",lit('*')).withColumn("END_PARTITION",lit('*'))
LDAP_DATA_DF_REC2=LDAP_DATA_DF_REC1.select("IBAS","IDAT","IEMP","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","SLOT","INBR","LOAD_TIME","SOURCE_FILENAME","END_PARTITION","ID")

# COMMAND ----------

# DBTITLE 1,Data Processing for LDA files in Report Format
# process LDA data to form in Report format
from functools import reduce
from pyspark.sql import DataFrame
import datetime
from pyspark.sql import functions
try:
  DataSchema = StructType([StructField("BASE", StringType()),StructField("IDAT", StringType()),StructField("EMP_NBR", StringType()),StructField("ABSOLUTE_BASE_DATA", StringType()),StructField("PARTITION", StringType()),StructField("ACTUAL_BASE_DATA", StringType()),StructField("MONTH", StringType()),StructField("DATE_MONTH", StringType()),StructField("SEQ_NUM", StringType()),StructField("ISEA", StringType()),StructField("ISLOT", StringType()),StructField("INBR", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType()),StructField("END_PARTITION", StringType())])

  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  CRPAY_LDA_LIST=[]
  REC_NUM =0
  for row in LDAP_DATA_DF_REC2.collect(): 
        BASE = row.IBAS
        DATE = row.IDAT
        EMP_NBR = row.IEMP
        ABSOLUTE_BASE_DATA = row.ABSOLUTE_BASE_DATA
        ACTUAL_BASE_DATA = row.ACTUAL_BASE_DATA
        MONTH = row.MONTH
        DATE_MONTH = row.DATE_MONTH
        SEQ_NUM = row.SEQ_NUM
        SEA = row.ISEA
        SLOT = row.SLOT
        NBR = row.INBR
        LOAD_TIME = row.LOAD_TIME
        INPUT_FILENAME = row.SOURCE_FILENAME

        if(row.ID==1):
          REC_NUM = REC_NUM+1
          REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
          Partition = '*'
          pad1 = ' ' * (64-len(ABSOLUTE_BASE_DATA))
          pad2 = ' ' * (64-len(ACTUAL_BASE_DATA))
          NFZ_TMP3 =  "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}".format(BASE,DATE,EMP_NBR,fs(' ',64,'*'),Partition,fs(' ',64,'*'),MONTH,DATE_MONTH,SEQ_NUM,SEA,SLOT,NBR,REC_NUM_ZERO,LOAD_TIME,INPUT_FILENAME,Partition)
          CRPAY_LDA_LIST.append(NFZ_TMP3.split(','))
          REC_NUM = REC_NUM+1
          REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
          NFZ_TMP4 =  "{0},{1},{2},{3}{4},{5},{6}{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17}".format(BASE,DATE,EMP_NBR,ABSOLUTE_BASE_DATA,pad1,Partition,ACTUAL_BASE_DATA,pad2,MONTH,DATE_MONTH,SEQ_NUM,SEA,SLOT,NBR,REC_NUM_ZERO,LOAD_TIME,INPUT_FILENAME,Partition)
          CRPAY_LDA_LIST.append(NFZ_TMP4.split(','))
        else:
          REC_NUM = REC_NUM+1
          REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
          Partition = '*'
          pad1 = ' ' * (64-len(ABSOLUTE_BASE_DATA))
          pad2 = ' ' * (64-len(ACTUAL_BASE_DATA))

          NFZ_TMP5 =  "{0},{1},{2},{3}{4},{5},{6}{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17}".format(BASE,DATE,EMP_NBR,ABSOLUTE_BASE_DATA,pad1,Partition,ACTUAL_BASE_DATA,pad2,MONTH,DATE_MONTH,SEQ_NUM,SEA,SLOT,NBR,REC_NUM_ZERO,LOAD_TIME,INPUT_FILENAME,Partition)
          CRPAY_LDA_LIST.append(NFZ_TMP5.split(','))

  MSG_DESC = "LDA Files are sucessfully processed in Report Format"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process LDA Files in Report Format. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e

# COMMAND ----------

# defined Schema for output Report 
CRPAY_LDA_DF = spark.createDataFrame(CRPAY_LDA_LIST,schema=DataSchema)

# COMMAND ----------

#convert IDAT value which is in integer format into Dateformat and append static date like 1966-01-02 into converted date format.
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import year, month
import pyspark.sql.functions as sf

CRPAY_LDA_DF1= CRPAY_LDA_DF.withColumn("INTDATE",CRPAY_LDA_DF['IDAT'].cast(IntegerType()))
CRPAY_LDA_DF1 = CRPAY_LDA_DF1.withColumn("FIXED_DATE",sf.lit("1966-01-02"))
CRPAY_LDA_DF1=  CRPAY_LDA_DF1.selectExpr("BASE","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","FIXED_DATE","IDAT","date_add(to_date(FIXED_DATE),INTDATE) as CONVERTED_IDATE","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION")
CRPAY_LDA_DF1 = CRPAY_LDA_DF1.selectExpr("BASE","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","CONVERTED_IDATE","year(CONVERTED_IDATE) as YEAR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION")


# COMMAND ----------

import re

m_struct_zone = re.search(r'(.*?(?P<struct>.*.net\/))', Rejected_Records_path)
struct_zone = m_struct_zone['struct'] if m_struct_zone else ''
struct_zone = struct_zone + "delta-struct-pii/"
if('LDA' in SRC_FILE_NM):
  struct_zone = struct_zone + "AALDA/"
  TARGET_NM = "crpay_struct.lda_data"
else:
  print(struct_zone)


# COMMAND ----------


def write():
  CRPAY_LDA_DF1.orderBy("REC_NUM").select("BASE","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","YEAR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION").write.format("delta").mode('append').partitionBy("YEAR","MONTH").save(struct_zone)
  
  


# COMMAND ----------

# DBTITLE 1,Save LDA records into Struct zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDA records has been successfully written in Struct zone"
  
  
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STRUCT")
  

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "LDA records has been skipped without saving due to rerun of same file in Struct zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDA records in struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

# this intermittent step is added to make sure report should be generated proper as expected when reprocessing data or/and restart the program
def write():
  CRPAY_LDA_DF1.orderBy("REC_NUM").select("BASE","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","YEAR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION").write.format("delta").mode('append').partitionBy("YEAR","MONTH").save(STG_Output_File_Report)
  
  


# COMMAND ----------

TARGET_NM = ""

# COMMAND ----------

# DBTITLE 1,Save LDA records into Intermittent area i.e. work-pii
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDA records has been successfully written in Work zone"
  
  
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STG")
  

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent LDA records has been skipped without saving due to rerun of same file in Work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDA records in intermittent zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

#read intermediate data 
STG_REPORT_DATA = spark.read.format("delta").load(STG_Output_File_Report)

# COMMAND ----------

YEAR = STG_REPORT_DATA.select("YEAR").collect()[0][0]
MONTH = STG_REPORT_DATA.select("MONTH").collect()[0][0]



# COMMAND ----------

#deduplicating report data using SQL solution
STG_REPORT_DATA.createOrReplaceTempView("crp98_report_table")
REPORT_DATA_NON_DUP_DF = spark.sql("select BASE,EMP_NBR,ABSOLUTE_BASE_DATA,PARTITION,ACTUAL_BASE_DATA,MONTH,DATE_MONTH,SEQ_NUM,ISEA,ISLOT,INBR,YEAR,MONTH,CAST(REC_NUM as INT),max(LOAD_TIME) as LOAD_TIME,max(SOURCE_FILENAME) as SOURCE_FILENAME,END_PARTITION from crp98_report_table GROUP BY BASE,EMP_NBR,ABSOLUTE_BASE_DATA,PARTITION,ACTUAL_BASE_DATA,MONTH,DATE_MONTH,SEQ_NUM,ISEA,ISLOT,INBR,YEAR,MONTH,REC_NUM,END_PARTITION order by REC_NUM")

# COMMAND ----------

def write():
  REPORT_DATA_NON_DUP_DF.orderBy("REC_NUM").select("BASE","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","YEAR","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION").write.format("delta").mode('overwrite').partitionBy("YEAR","MONTH").option("mergeSchema", "true").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}' ".format(YEAR,MONTH)).save(Output_File_Report)

# COMMAND ----------

# defining Target_name table based on src file name
if('LDA' in SRC_FILE_NM):
  TARGET_NM = "crpay_prep.lda_report"
else:
  TARGET_NM = ""

# COMMAND ----------

# DBTITLE 1,Save LDA records into prep
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDA records has been successfully written in Prep zone"
  
  
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"PREP")
  

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "LDA records has been skipped without saving due to rerun of same file in Prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDA records in Prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e



# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing all LDA records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------


