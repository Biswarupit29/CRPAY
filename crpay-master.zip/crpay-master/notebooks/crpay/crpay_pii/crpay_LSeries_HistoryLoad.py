# Databricks notebook source
# DBTITLE 1,VD History Files for LDC/LDP series from raw_to_prep
"Version History of VD History Files for LDC/LDP series from raw to prep"

"Changes:"

"Developer: Nitin, Amareswara Reddy"
"Date Created: 03/17/2021"
"Date Updated : 06/03/2021"
"Purpose: Read VD History Files for LDC/LDP series from Raw zone and Load into prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Rejected_Records_path", "")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("Output_File_Data", "")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

# COMMAND ----------

#dbutils.widgets.remove("Data_Output_File_Data")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
receiver_emails = receiver_emails.split()

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# log report function param's 
import datetime
from pyspark.sql.functions import *

SYS_NM = "crpay"
SRC_FILE_NM = "VD_HISTORY_FILES_LDC_LDP"
#SRC_FILE_NM = Input_File_Name
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"


# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time
# The log will be written in the success folder 

SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Read VD P series History Records from Raw Zone
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
try:
  
  cp_pii_df = spark.read.format("json").load(Input_File)
  cp_pii_df = cp_pii_df.withColumn("sourcefile",input_file_name())
  regex_str = "[\/]([^\/]+)$"
  cp_pii_df = cp_pii_df.withColumn("INPUT_FILE_NAME", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))
  MSG_DESC = "VD LDC/LDP series History data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  print("Raw count: "+str(cp_pii_df.count()))
  
except Exception as e:
  MSG_DESC = "Failed to read VD LDC/LDP series History data from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# Extracting Month from file name
IMONTH_NUM = int(cp_pii_df.select("INPUT_FILE_NAME").distinct().collect()[0][0][20:22])
IYEAR_NUM = int(cp_pii_df.select("INPUT_FILE_NAME").distinct().collect()[0][0][14:18])
int(cp_pii_df.select("INPUT_FILE_NAME").distinct().collect()[0][0][14:18])
if(IMONTH_NUM == 1):
  IMONTH_NUM = 12
  IYEAR_NUM = IYEAR_NUM -1
else:
  IMONTH_NUM = IMONTH_NUM - 1
print("Year: "+str(IYEAR_NUM))
print("Month: "+str(IMONTH_NUM))

# COMMAND ----------

cp_pii_df.write.mode("overwrite").format("delta").option("mergeSchema", "true").save(Output_File_Report+'_VD')

# COMMAND ----------

spark.sql("""CREATE TABLE IF NOT EXISTS crpay_prep.{0}_report_vd
USING DELTA 
OPTIONS ( path  '{1}'  )""".format(Crewpay_Run.lower(),Output_File_Report+'_VD'))

# COMMAND ----------

# DBTITLE 1,Processing of History data from Base to Base
## processing of History data 

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime,re
from pyspark.sql.functions import substring

try:
  # defined Schema for history report as it should looks like the same as LDC/LDP series report
  
  DataSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()), StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("CONVERTED_IDATE", StringType()),StructField("REC_NUMBER", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("SOURCE_FILENAME", StringType()),StructField("LOAD_TIME", StringType())])
  
  SkippedDataSchema = StructType([StructField("REC_NUM", StringType()),StructField("VALUE", StringType())])                    
  
  CREW_TKG_RPT_DATA_FINAL_LIST=[]
  SKIP_DATA_LIST =[]
  REC_NUM = 0 
  def fs(str,len,val):
     return str.rjust(len,val)[:len]
  BASE= ''
  SEQ =''
  MSG = ''
  YEAR = ''
  MONTH = ''
  CONVERTED_DATE = ''
  SUB_ILIN = ''
  IBASE= ''
  ISEQ =''
  IMSG = ''
  IYEAR = ''
  IMONTH = ''
  ICONVERTED_DATE = ''
  ISUB_ILIN = ''
  DATE = ''
  for row in cp_pii_df.rdd.collect(): 
        value = row.Data.strip(' ')
        INPUT_FILE_NAME = row.INPUT_FILE_NAME
        LOAD_TIME = row.LOADTIME
        #print(row.value)
        if('REPORT CRP052' in value):
            #IBASE = str(value)[41:45]
            #ISEQ = str(value)[48:52]
            #ISEQ = ISEQ.lstrip('0')
            IMSG = str(value)[53:59]
            DATE = IMSG[0:2]
            IYEAR = str(value)[81:83]
            IYEAR = '20' +IYEAR
            IYEAR = IYEAR_NUM
            IMON = IMSG[2:5]
            #print(IMON)
            datetime_object = datetime.datetime.strptime(IMON, "%b")
            IMONTH = datetime_object.month 
            CONVERTED_IDATE = str(IYEAR) +"-"+str(IMONTH)+"-"+DATE
            SKIP_DATA_TEMP1 = "{0},{1}".format(REC_NUM,value)
            SKIP_DATA_LIST.append(SKIP_DATA_TEMP1.split(','))
        #BASE = IBASE
        #SEQ =  ISEQ
        #MSG = IMSG
        #YEAR = IYEAR
        #MONTH = IMONTH
        #CONVERTED_DATE = CONVERTED_IDATE
        elif(value=='1'):
             NO_FILE = 'NA'
             SKIP_DATA_TEMP2 = "{0},{1}".format(REC_NUM,value)
             SKIP_DATA_LIST.append(SKIP_DATA_TEMP2.split(','))
        elif('CONTINUED IN' in value):
             NO_FILE = 'NA'
             SKIP_DATA_TEMP3 = "{0},{1}".format(REC_NUM,value)
             SKIP_DATA_LIST.append(SKIP_DATA_TEMP3.split(','))
        elif(value == ""):
             NO_FILE = 'NA'
             SKIP_DATA_TEMP4 = "{0},{1}".format(REC_NUM,value)
             SKIP_DATA_LIST.append(SKIP_DATA_TEMP4.split(','))
        elif('*********' in value):
             NO_FILE = 'NA'
             SKIP_DATA_TEMP5 = "{0},{1}".format(REC_NUM,value)
             SKIP_DATA_LIST.append(SKIP_DATA_TEMP5.split(','))
        #elif('PAGE' in value):
         #    NO_FILE = 'NA'
          #   SKIP_DATA_TEMP6 = "{0},{1}".format(REC_NUM,value)
           #  SKIP_DATA_LIST.append(SKIP_DATA_TEMP6.split(','))
        
      
        elif('BASE' in value):
            if(('CABASE' in value) or ('BASEMAN' in value)):
                REC_NUM = REC_NUM+1
                m_ILIN = re.search(r'(.*?(?P<ilin>.*)\*)',value)
                ILIN = m_ILIN['ilin'] if m_ILIN else ''
                IMONTH = str(IMONTH_NUM)
                CREW_TKG_RPT_DATA_TMP3 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(IBASE,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,REC_NUM,IYEAR,IMONTH,INPUT_FILE_NAME,LOAD_TIME)
                CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(','))
            else:
                m_ISEQ = re.search(r'(.*?\SEQ\s(?P<seq>.*)\sBASE)',value)
                ISEQ = m_ISEQ['seq'] if m_ISEQ else ' '
                if('/' in ISEQ):
                  n_ISEQ = re.search(r'(.*?(?P<seq>.*)\/)',ISEQ)
                  ISEQ = n_ISEQ['seq'] if n_ISEQ else ' '
                m_IBASE = re.search(r'(.*?\BASE\s(?P<base>.*))',value)
                IBASE = m_IBASE['base'] if m_IBASE else ' '
                IBASE = IBASE[0:3]
                #REC_NUM = REC_NUM+1
                m_ILIN = re.search(r'(.*?(?P<ilin>.*)\*)',value)
                ILIN = m_ILIN['ilin'] if m_ILIN else ''
  
  
                #else:
                REC_NUM = REC_NUM+1
                IMONTH = str(IMONTH_NUM)
                CREW_TKG_RPT_DATA_TMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(IBASE,ISEQ,IMSG,IMON,fs(' ',66,'*'),CONVERTED_IDATE,REC_NUM,IYEAR,IMONTH,INPUT_FILE_NAME,LOAD_TIME)
                CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP1.split(','))
                REC_NUM = REC_NUM+1
                CREW_TKG_RPT_DATA_TMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(IBASE,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,REC_NUM,IYEAR,IMONTH,INPUT_FILE_NAME,LOAD_TIME)
#                 Remove below comment
                CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))
        #elif(('SEQUENCE FAILED CONTINUITY' in value) or ('ROSTER SEQ' in value) or ('SUPV SEQ' in value)):
         #   REC_NUM = REC_NUM+1
          #  m_ILIN = re.search(r'(.*?(?P<ilin>.*)\*)',value)
           # ILIN = m_ILIN['ilin'] if m_ILIN else ''
            #CREW_TKG_RPT_DATA_TMP4 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(IBASE,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,REC_NUM,IYEAR,IMONTH,INPUT_FILE_NAME,LOAD_TIME)
            #CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP4.split(','))
        else:
            
            REC_NUM = REC_NUM+1
            m_ILIN = re.search(r'(.*?(?P<ilin>.*)\*)',value)
            ILIN = m_ILIN['ilin'] if m_ILIN else ''
            IYEAR = IYEAR_NUM
            CONVERTED_IDATE = str(IYEAR) +"-"+str(IMONTH)+"-"+DATE
            CREW_TKG_RPT_DATA_TMP5 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(IBASE,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,REC_NUM,IYEAR,IMONTH,INPUT_FILE_NAME,LOAD_TIME)
            CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP5.split(','))

  #create Dataframes
  HIST_RPT_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST, schema=DataSchema)
  SKIPPED_DF = spark.createDataFrame(SKIP_DATA_LIST, schema=SkippedDataSchema)      
  
  #filter out empty records
  HIST_RPT_DF = HIST_RPT_DF.filter(HIST_RPT_DF.ILIN !="")
  
  print("HIST_RPT_DF Count: "+str(HIST_RPT_DF.count()))
  print("SKIPPED_DF Count: "+str(SKIPPED_DF.count()))
except Exception as e:
  MSG_DESC = "Failed in proces VD LDC/LDP series History data from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Function to concat all columns into a single column
def myConcat(*cols):
      concat_columns = []
      for c in cols[:-1]:
          concat_columns.append(F.coalesce(c, F.lit("*")))
          concat_columns.append(F.lit(""))  
      concat_columns.append(F.coalesce(cols[-1], F.lit("*")))
      return F.concat(*concat_columns)

# COMMAND ----------

# DBTITLE 1,Function to Write SKIPPED_DF Records in struct-pii
def write():
  
  data_text = SKIPPED_DF.withColumn("combined", myConcat(*SKIPPED_DF.columns)).withColumn("YEAR", lit(IYEAR_NUM)).withColumn("MONTH", lit(IMONTH_NUM)).select("combined","YEAR","MONTH")
  data_text.coalesce(1).write.format("delta").partitionBy("YEAR","MONTH").mode("append").save(Output_File_Data+"/SKIPPED_ROW_"+Crewpay_Run)

# COMMAND ----------

print(Indicator_File_Path)

# COMMAND ----------

# DBTITLE 1,Save SKIPPED Records
# Save SKIPPED Records
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "SKIPPED records has been successfully written in Struct zone"
  TARGET_NM = ""
  
  result = restart_logic(SRC_FILE_NM+".json",Indicator_File_Path,"SKIPPED")
  print("result: "+result)

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "SKIPPED records has been skipped without saving due to rerun of same file in Struct zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write SKIPPED records in Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

# DBTITLE 1,Processing of History data and Assigning SEQ_NO for each and every block
# Assiging SEQ_NO for each and every block 
# Block is represented as below 
#********************************
#            Data 
#********************************

import re
from pyspark.sql import DataFrame
from pyspark.sql.types import *
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import current_date
import datetime

BlockSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("CONVERTED_IDATE", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("INPUT_FILENAME", StringType()),StructField("BLOCK_SEQ", StringType())])
try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  BLOCK_SEQ_LIST =[]
  BLOCK_SEQ = 0

  for row in HIST_RPT_DF.rdd.collect():
    IBAS = row.IBAS
    ISEQ = row.ISEQ
    IMSG = row.IMSG
    IMON = row.IMON
    ILIN = row.ILIN
    CONVERTED_IDATE = row.CONVERTED_IDATE
    YEAR = row.YEAR
    MONTH = row.MONTH
    REC_NUM = row.REC_NUMBER
    LOAD_TIME = row.LOAD_TIME
    SOURCE_FILENAME = row.SOURCE_FILENAME
    if("***********" in ILIN):
      BLOCK_SEQ = BLOCK_SEQ +1
      #print("ILIN" + row.ILIN,"count" +str(SEQ))
      SEQ_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,BLOCK_SEQ)
      BLOCK_SEQ_LIST.append(SEQ_TEMP1.split(','))
    else:
      #SEQ
      #print("ILIN" + row.ILIN,"count" +str(SEQ))
      SEQ_TEMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,BLOCK_SEQ)
      BLOCK_SEQ_LIST.append(SEQ_TEMP2.split(','))
  
  # Creating intermediate report by creating data frame 
  BLOCK_SEQ_DF = spark.createDataFrame(BLOCK_SEQ_LIST,BlockSchema)
  
  print("BLOCK_SEQ_DF Count: "+str(BLOCK_SEQ_DF.count()))

  MSG_DESC = "Assignment of SEQ_NO for each and every block is successfully completed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to assign SEQ_NO for each and every block. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Processing of History data and Assigning SEQ ORIGIN for each and every block
# extracting only that data which is having string as SKD or SKB from block and later raking them as per each block.
import re
from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

try:
  SKDSchema = StructType([StructField("SUB_ILIN", StringType()),StructField("BLOCK_SEQ", StringType()),StructField("RECORD_NUMBER", StringType())])
  
  REVISED_REC_NUM = 0
  SKD_LIST = []

  for row in BLOCK_SEQ_DF.rdd.collect():
    ILIN = row.ILIN
    BLOCK_SEQ = row.BLOCK_SEQ
    ISEQ = row.ISEQ
    #RECORD_NUMBER = row.REC_NUM
    if('SKD' in ILIN) or ('SKB' in ILIN):
      if('SKD ONDUTY' in ILIN) or ('D/P SKD' in ILIN) or ('SEQ SKD' in ILIN):
          NO_FILE = 'NA'
      else:
        RECORD_NUMBER = row.REC_NUM
        SKD_TMP = "{0},{1},{2}".format(ILIN,BLOCK_SEQ,RECORD_NUMBER)
        SKD_LIST.append(SKD_TMP.split(','))  
  SKD_DF_T = spark.createDataFrame(SKD_LIST, SKDSchema)         
  
  #created intermediate view to get datatypes of BLOCK_SEQ, RECORD_NUMBER and id changed to Interger so that sorting can be done effectively
  SKD_DF_T.createOrReplaceTempView("VD_BLOCK_TABLE")
  SKD_DF_T_SEQ = spark.sql("select SUB_ILIN, cast(BLOCK_SEQ as int), cast(RECORD_NUMBER as int) from VD_BLOCK_TABLE order by RECORD_NUMBER")
  
  SKD_DF_T_SEQ_SORTED = SKD_DF_T_SEQ.withColumn("id", F.rank().over(Window.partitionBy("BLOCK_SEQ").orderBy("RECORD_NUMBER")))
  
  SKD_FirstOccurence =  SKD_DF_T_SEQ_SORTED.filter(SKD_DF_T_SEQ_SORTED.id==1)
  
  # joining Two DFs using Left outer join
  VD_DF=BLOCK_SEQ_DF.join(SKD_FirstOccurence, on='BLOCK_SEQ', how='leftouter')
  
  VD_DF1 = VD_DF.na.fill('NA')
  
  #created intermediate view again to get datatypes of BLOCK_SEQ, RECORD_NUMBER and id changed to Interger so that sorting can be done effectively
  VD_DF1.createOrReplaceTempView("VD_TEMP_TABLE")
  VD_DF2 = spark.sql("select cast(BLOCK_SEQ as int), IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,cast(REC_NUM as int),LOAD_TIME,INPUT_FILENAME,SUB_ILIN,RECORD_NUMBER,cast(id as int) from VD_TEMP_TABLE")
  
  #Sorting DF based on "BLOCK_SEQ","id","REC_NUM"
  VD_DF3 = VD_DF2.orderBy("BLOCK_SEQ","id","REC_NUM")
  
  print("VD_DF3 Count: "+str(VD_DF3.count()))

  MSG_DESC = "SEQ ORIGIN date has been extracted successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to extract SEQ ORIGIN date. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Processing of History data and replacing Empty values under SEQ ORIGIN date to "NA"
# Key logics are mentioned while processing data
#if SEQ ORIGIN date is empty into data, ,replace it with String "NA" else it would have SEQ ORIGIN date 


import datetime

try:
  
  WebReportSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("CONVERTED_IDATE", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType()),StructField("SUB_ILIN", StringType()),StructField("BLOCK_SEQ", StringType()),StructField("id", StringType())])

  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  VD_LIST =[]
  for A in VD_DF3.rdd.collect():

      if(A.SUB_ILIN=='NA'):
        ORIG_DATE = 'NA'
      else:
        ORIG_DATE = A.SUB_ILIN[4:6]

      IBAS = A.IBAS
      ISEQ = A.ISEQ
      IMON = A.IMON
      SUB_ILIN= A.SUB_ILIN
      YEAR = A.YEAR
      MONTH = A.MONTH
      CONVERTED_IDATE = YEAR + "-"+MONTH+"-"+ORIG_DATE
      IMSG = A.IMSG
      #IMSG = ORIG_DATE+IMON
      LOAD_TIME = A.LOAD_TIME
      SOURCE_FILENAME = A.INPUT_FILENAME
      REVISED_REC_NUM = REVISED_REC_NUM +1
      REVISED_REC_NUM_ZERO = fs(str(REVISED_REC_NUM),10, '0')
   
      VD_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,A.ILIN,CONVERTED_IDATE,YEAR,MONTH,REVISED_REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME,SUB_ILIN,A.BLOCK_SEQ,A.id)
      VD_LIST.append(VD_TEMP1.split(','))

  # creating final report DF
  FINAL_VD_DF = spark.createDataFrame(VD_LIST,WebReportSchema)
  
  print("FINAL_VD_DF Count: "+str(FINAL_VD_DF.count()))
  
  MSG_DESC = "LDC Web report data is transformed successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to tranform LDC web report. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Processing of History data and Reorderding 'SUPV SEQ' & 'SEQUENCE FAILED CONTINUITY'
# Key logics are mentioned while processing data
# Reorderding 'SUPV SEQ' & 'SEQUENCE FAILED CONTINUITY' data to previous IBAS,ISEQ,IMSG values


import datetime

try:

  VD_LIST_N =[]
  SEQ_IND = 'N'
  ILIN_P = ''
  REC_NUM_P = ''
  for A in FINAL_VD_DF.rdd.collect():
      IBAS = A.IBAS
      ISEQ = A.ISEQ
      IMSG = A.IMSG
      IMON = A.IMON
      ILIN = A.ILIN
      CONVERTED_IDATE = A.CONVERTED_IDATE
      YEAR = A.YEAR
      MONTH = A.MONTH
      REC_NUM = A.REC_NUM
      LOAD_TIME = A.LOAD_TIME
      SOURCE_FILENAME = A.SOURCE_FILENAME
      SUB_ILIN = A.SUB_ILIN
      BLOCK_SEQ = A.BLOCK_SEQ
      id = A.id
      if(ILIN.strip() == 'SUPV SEQ' or ILIN.strip() == 'SEQUENCE FAILED CONTINUITY' or ('ROSTER SEQ' in ILIN.strip())):
        ILIN_P = ILIN
        REC_NUM_P = REC_NUM
        #print(ILIN)
        SEQ_IND = 'Y'
      elif(SEQ_IND == 'Y' and ILIN.strip() == '*****************************************************************'):
#         print(ILIN)
#         print(REC_NUM_P)
#         print(ILIN_P)
#         print(REC_NUM)
        VD_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM_P,LOAD_TIME,SOURCE_FILENAME,SUB_ILIN,BLOCK_SEQ,id)
        VD_LIST_N.append(VD_TEMP1.split(','))
        VD_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,ILIN_P,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,SUB_ILIN,BLOCK_SEQ,id)
        VD_LIST_N.append(VD_TEMP1.split(','))
        SEQ_IND = 'N'
      else:
        VD_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,SUB_ILIN,BLOCK_SEQ,id)
        VD_LIST_N.append(VD_TEMP1.split(','))
        SEQ_IND = 'N'

  # creating final report DF
  FINAL_VD_DF_N = spark.createDataFrame(VD_LIST_N,WebReportSchema)
  
  print("FINAL_VD_DF_N Count: "+str(FINAL_VD_DF_N.count()))

  MSG_DESC = "LDC Web report data is transformed successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to tranform LDC web report. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Function to Write LDC/LDP Records in Delta Prep
def write():
    FINAL_VD_DF_N.select("IBAS","ISEQ","IMSG","IMON","ILIN",to_date(col("CONVERTED_IDATE"),"yyyy-MM-dd").alias("CONVERTED_IDATE"),col("YEAR").cast("int"),col("MONTH").cast("int"),col("REC_NUM").cast("int"),"LOAD_TIME","SOURCE_FILENAME").write.mode("overwrite").format("delta").partitionBy("YEAR","MONTH").option("mergeSchema", "true").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}'".format(YEAR,MONTH)).save(Output_File_Report)

# COMMAND ----------

# DBTITLE 1,Defining Target_name table
# print Input_File name
print(Input_File)

# defining Target_name table based on src file name
if('ACRPPLEG' in Input_File):
  TARGET_NM = "crpay_prep.ldp_report"
  SRC_FILE_NM = SRC_FILE_NM+"_LDP"
else:
  TARGET_NM = "crpay_prep.ldc_report"
  SRC_FILE_NM = SRC_FILE_NM+"_LDC"
  
# print SRC_FILE_NM name
print(SRC_FILE_NM)

# COMMAND ----------

# DBTITLE 1,Save LDC/LDP records into prep
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC/LDP records has been successfully written in Prep zone"
  
  restart_logic(SRC_FILE_NM,Indicator_File_Path,"PREP")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "LDC/LDP records has been skipped without saving due to rerun of same file in Prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC/LDP records in Prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

Prep_File = Output_File_Report + "/YEAR=" + YEAR + '/' + "MONTH=" + MONTH 

# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing all LSeries History records"
END_TMS = str(datetime.datetime.now())

# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

dbutils.notebook.exit(Prep_File+';'+YEAR+';'+MONTH)