# Databricks notebook source
# DBTITLE 1,LDC WEB REPORT prep_to_prep
"Version History of LDC Web report prep_to_prep"

"Changes:"

"Developer: Nitin"
"Date Created: 01/10/2021"
"Date Updated : 02/23/2021"
"Purpose: Read LDC report data from Prep zone, create LDC web report and Load into prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")


# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Initialising logging parameters
# log report function param's 
import datetime

SYS_NM = "crpay"
#SRC_FILE_NM = "LDC_WEB_REPORT"
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"


# COMMAND ----------

# DBTITLE 1,Read LDC Records from Prep Zone
#Read Input Data Files for LDC from prep zone which is o/p of Flight attendant
try:
  Partition_BY_YEAR = (Input_File.split('/')[6]).split('=')[1]
  Partition_BY_MONTH = (Input_File.split('/')[7]).split('=')[1]
  print(Partition_BY_YEAR)
  print(Partition_BY_MONTH)

  Input_File_List = Input_File.split('/')
  delimiter = "/"
  Input_File_Path = delimiter.join(Input_File_List[:-2])+"/"
  print(Input_File_Path)

  web_report_df = spark.read.format("delta").load(Input_File_Path).filter(col("YEAR") == Partition_BY_YEAR).filter(col("MONTH") == Partition_BY_MONTH)
  SRC_FILE_NM = web_report_df.select("SOURCE_FILENAME").collect()[0][0]
  SRC_FILE_NM = "WEB_REPORT_" + SRC_FILE_NM
  MSG_DESC = "LDC Web report data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read LDC records from prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# defined Schema: one is for intermediate report and another one is for final report
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *

DataSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("CONVERTED_IDATE", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("INPUT_FILENAME", StringType()),StructField("BLOCK_SEQ", StringType())])

WebReportSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("CONVERTED_IDATE", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("REVISED_REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("INPUT_FILE_NAME", StringType()),StructField("EMP_NBR", StringType()),StructField("BLOCK_SEQ", StringType()),StructField("id", StringType())])


# COMMAND ----------

# DBTITLE 1,Assigning SEQ_NO for each and every block 
# Assiging SEQ_NO for each and every block 
# Block is represented as below 
#********************************
#            Data 
#********************************

import re
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import current_date
import datetime

try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  BLOCK_SEQ_LIST =[]
  BLOCK_SEQ = 0

  for row in web_report_df.collect():
    IBAS = row.IBAS
    ISEQ = row.ISEQ
    IMSG = row.IMSG
    IMON = row.IMON
    ILIN = row.ILIN
    CONVERTED_IDATE = row.CONVERTED_IDATE
    YEAR = row.YEAR
    MONTH = row.MONTH
    REC_NUM = row.REC_NUM
    LOAD_TIME = row.LOAD_TIME
    SOURCE_FILENAME = row.SOURCE_FILENAME
    if("***********" in ILIN):
      BLOCK_SEQ = BLOCK_SEQ +1
      #print("ILIN" + row.ILIN,"count" +str(SEQ))
      SEQ_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,BLOCK_SEQ)
      BLOCK_SEQ_LIST.append(SEQ_TEMP1.split(','))
    else:
      #SEQ
      #print("ILIN" + row.ILIN,"count" +str(SEQ))
      SEQ_TEMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11}".format(IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REC_NUM,LOAD_TIME,SOURCE_FILENAME,BLOCK_SEQ)
      BLOCK_SEQ_LIST.append(SEQ_TEMP2.split(','))
  MSG_DESC = "Assignment of SEQ_NO for each and every block is successfully completed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to assign SEQ_NO for each and every block. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# Creating intermediate report by creating data frame 
BLOCK_SEQ_DF = spark.createDataFrame(BLOCK_SEQ_LIST,DataSchema)

# COMMAND ----------

# DBTITLE 1,Extracting only that data which is having string as EMP NBR from block
# extracting only that data which is having string as EMP NBR from block and later raking them as per each block.
import re
from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

try:
  EmpNoSchema = StructType([StructField("EMP_ILIN", StringType()),StructField("BLOCK_SEQ", StringType()),StructField("RECORD_NUMBER", StringType())])
  FA = []
  REVISED_REC_NUM = 0
  WEBREPORT_LIST = []

  for row in BLOCK_SEQ_DF.collect():
    ILIN = row.ILIN
    BLOCK_SEQ = row.BLOCK_SEQ
    ISEQ = row.ISEQ
    RECORD_NUMBER = row.REC_NUM
    if('EMP NBR' in ILIN):
          EMP_TMP = "{0},{1},{2}".format(ILIN,BLOCK_SEQ,RECORD_NUMBER)
          FA.append(EMP_TMP.split(','))  

  EMP_DF_T = spark.createDataFrame(FA, EmpNoSchema)         
  EMP_DF_T_SEQ = EMP_DF_T.withColumn("id", F.rank().over(Window.partitionBy("BLOCK_SEQ").orderBy("RECORD_NUMBER")))

  MSG_DESC = "EMP_NBR has been extracted successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to extract EMP_NBR. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e


# COMMAND ----------

#created intermediate view to get datatypes of BLOCK_SEQ, RECORD_NUMBER and id changed to Interger so that sorting can be done effectively
EMP_DF_T_SEQ.createOrReplaceTempView("LDC_BLOCK_TABLE")
EMP_DF_T_SEQ_SORTED = spark.sql("select EMP_ILIN, cast(BLOCK_SEQ as int), cast(RECORD_NUMBER as int), cast(id as int) from LDC_BLOCK_TABLE")

# COMMAND ----------

# DBTITLE 1,Sorting data based on REC_NUM
#Sorting data present into DF based on REC_NUM so that seq can be maintained in ascending order.
EMP_DF_T_SEQ_SORTED = EMP_DF_T_SEQ_SORTED.orderBy("RECORD_NUMBER")

# COMMAND ----------

# DBTITLE 1,Joining two DFs 
# joining Two DFs using Left outer join
WEB_DF=BLOCK_SEQ_DF.join(EMP_DF_T_SEQ_SORTED, on='BLOCK_SEQ', how='leftouter')

# COMMAND ----------

# DBTITLE 1,Assigning 'NA' in place of null values 
# filling null values with default string "NA"
WEB_DF1 = WEB_DF.na.fill('NA')

# COMMAND ----------

#created intermediate view again to get datatypes of BLOCK_SEQ, RECORD_NUMBER and id changed to Interger so that sorting can be done effectively
WEB_DF1.createOrReplaceTempView("LDC_TEMP_TABLE")
WEB_DF2 = spark.sql("select cast(BLOCK_SEQ as int), IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,cast(REC_NUM as int),LOAD_TIME,INPUT_FILENAME,EMP_ILIN,RECORD_NUMBER,cast(id as int) from LDC_TEMP_TABLE")

# COMMAND ----------

#Sorting DF based on "BLOCK_SEQ","id","REC_NUM"
WEB_DF3 = WEB_DF2.orderBy("BLOCK_SEQ","id","REC_NUM")

# COMMAND ----------

# Key logics are mentioned while processing data
# 1. if EMP_NUMBER is empty into data, ,replace it with String "EMPTY"
# 2. if one block is having more one than FA, then same block to be repeated as having number of FA in one block. Also, make sure that one block mush have one FA followed by rest data of block.
# e.g. SEQ 211 is having two FAs so same seq will be repeated twice and each seq would have one FA at a time followed by rest data of block.

import datetime

try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]


  for A in WEB_DF3.collect():

      if(A.EMP_ILIN=='NA'):
        EMP_NUM = 'OPEN'
      else:
        m_EMP_NUM = re.search(r'(.*?NBR\s(?P<EMP_NUM>\d+))', A.EMP_ILIN)
        EMP_NUM = m_EMP_NUM['EMP_NUM'] if m_EMP_NUM else 'OPEN'

      IBAS = A.IBAS
      ISEQ = A.ISEQ
      IMSG = A.IMSG
      IMON = A.IMON
      CONVERTED_IDATE = A.CONVERTED_IDATE
      YEAR = A.YEAR
      MONTH = A.MONTH

      LOAD_TIME = A.LOAD_TIME
      SOURCE_FILENAME = A.INPUT_FILENAME


      if('EMP NBR' in A.ILIN ):
              if(A.EMP_ILIN in A.ILIN):
                  REVISED_REC_NUM = REVISED_REC_NUM +1
                  REVISED_REC_NUM_ZERO = fs(str(REVISED_REC_NUM),10, '0')
                  WEBREPORT_TEMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,A.ILIN,CONVERTED_IDATE,YEAR,MONTH,REVISED_REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME,EMP_NUM,A.BLOCK_SEQ,A.id)
                  WEBREPORT_LIST.append(WEBREPORT_TEMP1.split(','))

      else:
            REVISED_REC_NUM = REVISED_REC_NUM +1
            REVISED_REC_NUM_ZERO = fs(str(REVISED_REC_NUM),10, '0')
            WEBREPORT_TEMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(IBAS,ISEQ,IMSG,IMON,A.ILIN,CONVERTED_IDATE,YEAR,MONTH,REVISED_REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME,EMP_NUM,A.BLOCK_SEQ,A.id)
            WEBREPORT_LIST.append(WEBREPORT_TEMP2.split(','))
  MSG_DESC = "LDC Web report data is transformed successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to tranform LDC web report. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# creating final report DF
WEBREPORT_DF = spark.createDataFrame(WEBREPORT_LIST,WebReportSchema)

# COMMAND ----------

#Load WEB reprot data in Staging area first before loading into actual prep zone , so that duplicate data can be removed in advance
def write():
  WEBREPORT_DF.write.format("delta").mode('append').partitionBy("YEAR","MONTH").save(STG_Output_File_Report)

# COMMAND ----------

# DBTITLE 1,Save LDC web report records into Intermittent area i.e. work-pii
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.

result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC web report records has been successfully written in Work zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STG")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent LDC web report records has been skipped without saving due to rerun of same file in Work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC web report records in intermittent zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

#Reading intermediate web report data for removing duplicate data
WEBREPORT_DF_STG = spark.read.format("delta").load(STG_Output_File_Report)

# COMMAND ----------

#deduplicating WEB report data using SQL solution
WEBREPORT_DF_STG.createOrReplaceTempView("LDC_WEB_REPORT")
WEBREPORT_DF_SQL = spark.sql("select IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,CAST(YEAR AS INT),CAST(MONTH AS INT),CAST(REVISED_REC_NUM as INT), max(LOAD_TIME) as LOAD_TIME,INPUT_FILE_NAME,EMP_NBR from LDC_WEB_REPORT GROUP BY IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,YEAR,MONTH,REVISED_REC_NUM,EMP_NBR,INPUT_FILE_NAME ORDER BY REVISED_REC_NUM")

# COMMAND ----------

#WEB Report files are made available in delta format 
def write():
  WEBREPORT_DF_SQL.write.format("delta").mode('overwrite').partitionBy("YEAR","MONTH").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}' ".format(YEAR,MONTH)).save(Output_File_Report)

# COMMAND ----------

TARGET_NM = "crpay_prep.ldc_fa_web_report"

# COMMAND ----------

# DBTITLE 1,Save LDC web report records into prep zone

# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC web report records has been successfully written in prep zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"PREP")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "LDC web report records has been skipped without saving due to rerun of same file in prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC web report records in prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing all LCD web report records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------


