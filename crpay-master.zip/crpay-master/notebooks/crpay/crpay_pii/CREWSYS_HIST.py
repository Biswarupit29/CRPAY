# Databricks notebook source
dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Input_File_Path", "")
Input_File_Path = dbutils.widgets.get("Input_File_Path")

dbutils.widgets.text("Year", "")
Year = dbutils.widgets.get("Year")

dbutils.widgets.text("Month", "")
Month = dbutils.widgets.get("Month")

dbutils.widgets.text("vd_output", "")
vd_output = dbutils.widgets.get("vd_output")



dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")


# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# MAGIC
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

vd_month = str(Month)
vd_year = str(Year)

# COMMAND ----------

#if Month == "01":
 # YEAR = int(Year)
  #YEAR = YEAR-1
  #vd_year = str(YEAR)
  #print(vd_year)
  #vd_month = "12"
  #print(vd_month)
#else:
 # vd_year =  Year
 # vd_month = int(Month)
 # vd_month = vd_month-1
  
 # vd_month = str(vd_month)
 # print(vd_year)
 # print(vd_month)
  

# COMMAND ----------

cp_pii_df= spark.read.text(Input_File_Path)


# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

CREW_DATA_FINAL_LIST=[]
final_dict = {}
#CREW_TKG_RPT_DATA_FINAL_LIST_2=[]

ROW_NUM = 0


for row in cp_pii_df.collect():
  value = row.value.rstrip(' ')
  
   
  DATA = str(value)[0:132]
  ROW_NUM = ROW_NUM + 1
  #ROW_NUM = int(ROW_NUM)
  other = str(value)[132:182]
  
  final_dict['DATA'] = DATA
  final_dict['other'] = other
  final_dict['ROW_NUM'] = ROW_NUM
  
  RPT_DATA = "{0}".format(final_dict)
  app_json = json.dumps(final_dict)
  #print(app_json)
  CREW_DATA_FINAL_LIST.append(json.loads(app_json))
  

#CREW_DATA_FINAL_LIST

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

structureSchema = StructType([
  
  StructField('DATA', StringType(), True),
         StructField('other', StringType(), True),
  StructField('ROW_NUM', StringType(), True)
])




# COMMAND ----------

from pyspark.sql.types import StructType


first_data = spark.createDataFrame(CREW_DATA_FINAL_LIST, schema=structureSchema)
first_data = first_data.select(col("DATA"),col("other"),col("ROW_NUM").cast("int"))


from pyspark.sql.window import Window
from pyspark.sql.functions import  lead, first, last

Appendcol = first_data.withColumn("other_stg", regexp_replace(col("other"), " ",""))

flagDF = Appendcol.withColumn('other_stg_flag', when((col('other_stg') != lit('')), "|").otherwise(lit('')))
                           
lead_window = Window.orderBy('ROW_NUM')

lead_col = flagDF.withColumn('lead_1', lead('other_stg_flag', 1).over(lead_window))

flagDF = lead_col.withColumn('flag', when(((col('other_stg_flag') == lit('')) & (col('lead_1') == lit('|'))), "|").otherwise(col('other_stg_flag')))




#display(flagDF.orderBy('ROW_NUM'))


# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

DATA_FINAL_LIST=[]
final = {}
#CREW_TKG_RPT_DATA_FINAL_LIST_2=[]

ROW_NUM = 0


for row in flagDF.collect():
  DATA = row.DATA#.rstrip(' ')
  other = row.other#.rstrip(' ')
  other_stg_flag = row.flag#.rstrip(' ')
  

  
  fianledata = DATA  + other + ' ' + other_stg_flag
  RPT_DATA = "{0}".format(fianledata)

  
  DATA_FINAL_LIST.append(RPT_DATA)
  
  


fianllist= ''.join(DATA_FINAL_LIST)
fianl_LIST = fianllist.split('|')

fianl_LIST = fianl_LIST[:-1]


# COMMAND ----------

import ast
import pandas as pd
fianlList = []
for i in fianl_LIST:
  
  data = str(i)
  
  fianlList.append(str(data))
  
#fianlList
df = pd.DataFrame({'DATA':fianlList})

spark_df = spark.createDataFrame(df)
#display(spark_df)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

CREW1=[]
REC_NUM = 0 

for row in spark_df.collect(): 
  value = row.DATA.rstrip(' ')
 
  REC_NUM = REC_NUM +1 
  CREW_TKG_RPT_DATA2 = "{0}|{1}".format(value,REC_NUM)
  CREW1.append(CREW_TKG_RPT_DATA2.split('|'))
   


s = StructType([
  
  StructField('DATA', StringType(), True),
         StructField('REC_NUMBER', StringType(), True)
])
print(s)

VD = spark.createDataFrame(CREW1, schema=s)
VD = VD.select(col("DATA"),col("REC_NUMBER").cast("long"))
VD.createOrReplaceTempView("VD")



VDfinal = spark.sql("""select Data,REC_NUMBER, '{0}' AS `YEAR`, '{1}' AS `MONTH` from VD""".format(vd_year,vd_month))

VDfinal.write.mode("overwrite").format("delta").partitionBy("YEAR","MONTH").option("mergeSchema", "true").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}'".format(vd_year,vd_month)).save(vd_output)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

CREW_TKG_RPT_DATA_FINAL_LIST=[]
CREW_TKG_RPT_DATA_FINAL_LIST_2=[]

ROW_NUM = 0


for row in spark_df.collect():
  value = row.DATA#.rstrip(' ')
  
   
  DATA = str(value)[0:132]
  ROW_NUM = ROW_NUM + 1
  ROW_NUM = int(ROW_NUM)
  other = str(value)[132:182]
  emp_no = str(other)[4:10]
  module = str(other)[0:3]
  
  if('MONTH STARTING' in value):
    MONTH_START = str(value)[15:22]
    MONTH_END = str(value)[34:41]
  
    CREW_TKG_RPT_DATA_TMP1 = "{0}|{1}|{2}|{3}|{4}|{5}|{6}".format(DATA,ROW_NUM,other,emp_no,module,MONTH_START,MONTH_END)
    CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP1.split('|'))
    
  else:
    CREW_TKG_RPT_DATA_TMP2 = "{0}|{1}|{2}|{3}|{4}|{5}|{6}".format(DATA,ROW_NUM,other,emp_no,module,MONTH_START,MONTH_END)
    CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split('|'))
  
  #CREW_TKG_RPT_DATA_TMP2 = "{0}".format(DATA)
  CREW_TKG_RPT_DATA_FINAL_LIST_2.append(DATA)
  
#CREW_TKG_RPT_DATA_FINAL_LIST      
#CREW_TKG_RPT_DATA_FINAL_LIST_2

  
  
  

# COMMAND ----------

DataSchema = StructType([StructField("DATA", StringType()),StructField("REC_NO", StringType()),StructField("OTHER_FIELD", StringType()),StructField("EMP_NO", StringType()),StructField("module", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType())])


HIST_RPT_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST, schema=DataSchema).select(col("DATA"),col("REC_NO").cast("int"),"OTHER_FIELD",col("EMP_NO"),col("module"),col("MONTH_START"),col("MONTH_END"))
#display(HIST_RPT_DF)

# COMMAND ----------




lead_window = Window.orderBy('REC_NO')

Appendcol = HIST_RPT_DF.withColumn('lead_1',lead('EMP_NO', 1).over(lead_window))
Appendcol = Appendcol.withColumn("trimlead_1", regexp_replace(col("lead_1"), " ","")).withColumn("trimemp", regexp_replace(col("EMP_NO"), " ",""))

flagDF = Appendcol.withColumn('flag_header', when((col('trimemp') != col('trimlead_1')), "1").otherwise(lit('')))
                           
#display(flagDF.orderBy('REC_NO'))

# COMMAND ----------

rc_list = []
for row in flagDF.collect():
  el = row.flag_header.rstrip(' ')
  
  if  el == "1":
    #print(el)
    rc = row.REC_NO
    rc_list.append(rc)

#rc_list

# COMMAND ----------

from datetime import date

today = date.today()
date = today.strftime("%d/%m/%Y")


# COMMAND ----------


rno = 0
CREW_L = []
for i in rc_list:
    
    recno = int(i)
    re = recno+rno 
    k = CREW_TKG_RPT_DATA_FINAL_LIST[re]
    ROW_NUM = k[1]
    other = k[2]
    emp = k[3]
    module = k[4]
    MONTH_START = k[5]
    MONTH_END = k[6]
    
    header = "PP004" + " " + module + " " +  emp + " CREWMEMBER PRE/POST ACTIVITY REPORT                  "  + "MONTH STARTING " +MONTH_START + " AND ENDING "+ MONTH_END + " PROCESS DATE " + date  
    
    CREW_2 = "{0}|{1}|{2}|{3}|{4}|{5}|{6}".format(header,ROW_NUM,other,emp,module,MONTH_START,MONTH_END)
    
    
    #CREW_L.append(CREW_2.split('|'))
    
    li = list(CREW_2.split("|"))
    #print(li)
    

    
    CREW_TKG_RPT_DATA_FINAL_LIST.insert(re, li)
    
    rno = rno + 1
#CREW_L    
#CREW_TKG_RPT_DATA_FINAL_LIST

# COMMAND ----------

Schema = StructType([StructField("header", StringType()),StructField("ROW_NUM", StringType()), StructField("other", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("module", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType())])

HIST = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST, schema=Schema)
HIST_DATA =  HIST.filter(HIST.ROW_NUM != "1")
#display(HIST_DATA)
#HIST_DATA.count()

# COMMAND ----------

## processing of History data  

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp

# defined Schema for history report as it should looks like the same as p series report

DataSchema = StructType([StructField("CC_1", StringType()),StructField("PRE_CREW_TKG_RPT_DATA", StringType()), StructField("POST_CREW_TKG_RPT_DATA", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType()),StructField("REC_NUMBER", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])

def fs(str,len,val):
  return str.rjust(len,val)[:len]

CREW_HIST_DATA_FINAL_LIST=[]
REC_NUM = 0 

Y = vd_year
M = vd_month
TS = str(datetime.datetime.now())
  
for row in HIST_DATA.collect(): 
  value = row.header.rstrip(' ')
  lvalue = row.header.strip(' ')
  if('CREWMEMBER PRE/POST ACTIVITY' in value):
    REC_NUM = REC_NUM +1 
    PRE_CREW_TKG_RPT_DATA = str(value)[0:69]
    POST_CREW_TKG_RPT_DATA = str(lvalue)[69:135]
    EMP_NBR = row.EMPLOYEE_NO
    MONTH_START = row.MONTH_START
    MONTH_END = row.MONTH_END
    LOAD_TIME = TS
    YEAR = Y
    MONTH = M
    PRE_INPUT_FILE_NAME = Input_File_Name
    POST_INPUT_FILE_NAME = Input_File_Name
    CREW_TKG_RPT_DATA1 = "{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}".format("",PRE_CREW_TKG_RPT_DATA,POST_CREW_TKG_RPT_DATA,EMP_NBR,MONTH_START,MONTH_END,REC_NUM,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILE_NAME,POST_INPUT_FILE_NAME)
    CREW_HIST_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA1.split('|'))
   
  else:
    
    REC_NUM = REC_NUM +1 
    PRE_CREW_TKG_RPT_DATA = str(value)[0:63]
    POST_CREW_TKG_RPT_DATA = str(value)[63:134]
    EMP_NBR = row.EMPLOYEE_NO
    MONTH_START = row.MONTH_START
    MONTH_END = row.MONTH_END
    LOAD_TIME = TS
    YEAR = Y
    MONTH = M
    PRE_INPUT_FILE_NAME = Input_File_Name
    POST_INPUT_FILE_NAME = Input_File_Name
    
    CREW_TKG_RPT_DATA2 = "{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}".format("",PRE_CREW_TKG_RPT_DATA,POST_CREW_TKG_RPT_DATA,EMP_NBR,MONTH_START,MONTH_END,REC_NUM,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILE_NAME,POST_INPUT_FILE_NAME)
    CREW_HIST_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA2.split('|'))
   
    

# COMMAND ----------

HIST_RPT_DF = spark.createDataFrame(CREW_HIST_DATA_FINAL_LIST, schema=DataSchema)

 
HIST_RPT_DF.createOrReplaceTempView("HIST_TABLE")

HIST_RPT = spark.sql("select CC_1,PRE_CREW_TKG_RPT_DATA,POST_CREW_TKG_RPT_DATA,EMPLOYEE_NO,MONTH_START,MONTH_END,CAST(REC_NUMBER as INT),LOAD_TIME,CAST(YEAR as INT),CAST(MONTH as INT),PRE_INPUT_FILENAME,POST_INPUT_FILENAME from HIST_TABLE ORDER BY REC_NUMBER")


# COMMAND ----------

YEAR = HIST_RPT.select("YEAR").collect()[0][0]
MONTH = HIST_RPT.select("MONTH").collect()[0][0]

HIST_RPT.write.format("delta").mode("overwrite").partitionBy("YEAR","MONTH").option("replaceWhere","YEAR = '{0}' AND MONTH ='{1}'".format(YEAR,MONTH)).save(Output_File_Report)


# COMMAND ----------


