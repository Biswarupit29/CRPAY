# Databricks notebook source
dbutils.widgets.text("oaoom_delta_path", "")

oaoom_delta_path = dbutils.widgets.get("oaoom_delta_path")

dbutils.widgets.text("optimus_path", "")

optimus_path = dbutils.widgets.get("optimus_path")

dbutils.widgets.text("oaoomlog_strctpath", "")

oaoomlog_strctpath = dbutils.widgets.get("oaoomlog_strctpath")

dbutils.widgets.text("oaoomlog_preppath", "")

oaoomlog_preppath = dbutils.widgets.get("oaoomlog_preppath")

dbutils.widgets.text("optimuslog_preppath", "")

optimuslog_preppath = dbutils.widgets.get("optimuslog_preppath")

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

# current_year = datetime.now().year

# starting_date_of_year = datetime(current_year, 1, 1)

# starting_date_string = starting_date_of_year.strftime("%Y-%m-%d")

# print("Starting date of the year:", starting_date_string)

# COMMAND ----------

# max_log_dt_query = spark.sql(f"""select max(log_dt) as max_log_dt from crpay_prep.oaoomlog_np""")
# max_log_dt_result = max_log_dt_query.collect()
# max_log_dt_str = str(max_log_dt_result[0]["max_log_dt"])

# print("Loading logs for and after :", max_log_dt_str)

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame

stack = [oaoom_delta_path]
dfAppend = []
while len(stack) > 0:
  current_folder = stack.pop(0)
  for file in dbutils.fs.ls(current_folder):
    if file.isDir():
      # Check if this is a delta table and do not recurse if so!
      try:
        delta_check_path = f"{file.path}/_delta_log"
        dbutils.fs.ls(delta_check_path)  # raises an exception if missing
        print(f"dataset: {file.path}")
        system_dataDF = spark.read.format("delta").load(file.path)
        #.filter(f"LOG_DT >= '{starting_date_string}'")
        #if system_dataDF.count() > 0:
        dfAppend.append(system_dataDF)
      except:            
        stack.append(file.path)
 
df_series = reduce(DataFrame.unionAll, dfAppend)

# COMMAND ----------

df_optimus = spark.read.format("parquet").load(optimus_path)

# COMMAND ----------

df_series.createTempView('pbi_oaoomlog')
df_optimus.createTempView('pbi_optimus')

# COMMAND ----------

df_oaoomlog_struct = spark.sql("select *, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'MM'))) as PRTN_MONTH, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yy'))) as PRTN_YEAR \
from pbi_oaoomlog")

# COMMAND ----------

#------WRITE RESULT SET TO FILE PATH FOR REPORTING -----#

#df_oaoomlog_struct.write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH").option("mergeSchema", "true").save(oaoomlog_strctpath)

# COMMAND ----------

from pyspark.sql import SQLContext

df_oaoomlog_prep = spark.sql("select *, \
date_format(END_TMS,'mm')- date_format(START_TMS,'mm') as duration_mts, date_format(END_TMS,'ss')- date_format(START_TMS,'ss') as duration_secs, \
case when SRC_FILE_NM like 'WEB_REPORT_VDR%FLG2%' or NOTEBOOK_NM like '%LDC_WEB_REPORT' then 'LDC_FSWEB'  \
     when SRC_FILE_NM like 'WEB_REPORT_AA%' then CONCAT(substr(SRC_FILE_NM,14,3),'_FSWEB') \
     when SRC_FILE_NM like 'WEB_REPORT%LEG%' or NOTEBOOK_NM like '%LDP_WEB_REPORT' then 'LDP_FSWEB' \
     when SRC_FILE_NM like 'VDR%LEG%' then 'VDHIST_LDP'  \
     when SRC_FILE_NM like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SRC_FILE_NM like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SRC_FILE_NM like 'AA%' then substr(SRC_FILE_NM,3,3) \
     when SRC_FILE_NM like ' _AA%' then substr(SRC_FILE_NM,5,3) \
     when SRC_FILE_NM like '%VDR_%PP4F%' then 'VDHIST_PPCD'  \
     when SRC_FILE_NM like '%VDR_%PP4G%' then 'VDHIST_PPAB' \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) ='' and NOTEBOOK_NM not like '%raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) != '' \
     and (NOTEBOOK_NM like '%oasis_raw_to_struct%process%' or NOTEBOOK_NM like '%oasis_struct_to_prep%') then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) ='' and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,47,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(NOTEBOOK_NM) like '%count%' then 'OPS_OASIS' \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%/Fsbch_prep/%' then upper(substr(NOTEBOOK_NM,25,3)) \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%/Fsbch_struct%Raw_to_Struct%' then upper(substr(NOTEBOOK_NM,27,3)) \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '/oasis%' and TARGET_NM !='' and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,47,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '/oasis%' and trim(TARGET_NM) ='' \
     and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%oasis_struct_to_prep%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%oasis_utility%' then 'OPS_OASIS' \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%Fsbch_counts_validation%' then 'OPS_FSBCH' \
     else substr(SRC_FILE_NM,1,3) end as SRC_FEED, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'MM'))) as PRTN_MONTH, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yy'))) as PRTN_YEAR \
from pbi_oaoomlog \
where SYS_NM = 'FSA00'")

# COMMAND ----------

# #------WRITE RESULT SET TO FILE PATH FOR REPORTING -----#

# df_oaoomlog_prep.coalesce(100).write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH").option("mergeSchema", "true").save(oaoomlog_preppath)

# COMMAND ----------

#spark.sql(f"""delete from delta.`{oaoomlog_preppath}` where LOG_DT >= '{max_log_dt_str}'""").display()

# COMMAND ----------

df_oaoomlog_prep.coalesce(100).write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH","SYS_NM").option("OverwriteSchema", "true").save(oaoomlog_preppath)

# COMMAND ----------

# #------Remove this later -----#

# df_oaoomloAg_prep.write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH").option("OverwriteSchema", "true").save(oaoomlog_preppath)

# COMMAND ----------

#------CREATE TABLE IN PREP ZONE FOR REPORTING -----#

# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.oaoomlog USING DELTA LOCATION 'abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/OAOOMLOGS/'")
# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.oaoomlog_np USING DELTA LOCATION 'abfss://oaoom@aabaoriondlsnp.dfs.core.windows.net/prep/oaoomlog/'")

# COMMAND ----------

df_optimus_prep = spark.sql("select *,date_format(DateTimeCompleted,'mm')- date_format(DateTimeStarted,'mm') as optduration_mts, \
date_format(DateTimeCompleted,'ss')- date_format(DateTimeStarted,'ss') as optduration_secs, \
case when DrainFileType like '%.%' then substr(DrainFileType,1,instr(DrainFileType,'.')-1) \
else DrainFileType end as optsys_nm, \
case when SourceFileName like 'WEB_REPORT_VDR%FLG2%' then 'LDC_FSWEB' \
     when SourceFileName like 'WEB_REPORT_AA%' then CONCAT(substr(SourceFileName,14,3),'_FSWEB') \
     when SourceFileName like 'WEB_REPORT%LEG%' then 'LDP_FSWEB' \
     when SourceFileName like 'VDR%LEG%' then 'VDHIST_LDP' \
     when SourceFileName like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SourceFileName like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SourceFileName like 'AA%' then substr(SourceFileName,3,3) \
     else substr(SourceFileName,1,4) end as optsrc_feed \
from pbi_optimus")

# COMMAND ----------

df_optimus_prep.write.mode("overwrite").format("delta").option("OverwriteSchema", "true").save(optimuslog_preppath)

# COMMAND ----------

# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.optimuslog USING DELTA LOCATION 'abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/OPTIMUSADFLOG/'")
# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.optimuslog_np USING DELTA LOCATION 'abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/OPTIMUSADFLOG/'")

# COMMAND ----------

df_dashboard_prep = spark.sql("select * from crpay_prep.oaoomlog left join crpay_prep.optimuslog on SRC_FILE_NM = SourceFileName")

# COMMAND ----------

# df_dashboard_prep.write.mode("overwrite").format("delta").option("mergeSchema", "true").save("abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/PBIDASHBOARD/")
df_dashboard_prep.write.mode("overwrite").format("delta").option("OverwriteSchema", "true").save("abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/PBIDASHBOARD/")

# COMMAND ----------

# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.oaoom_optimus USING DELTA LOCATION 'abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/PBIDASHBOARD/'")
# spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.oaoom_optimus_np USING DELTA LOCATION 'abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-prep/Reports/PBIDASHBOARD/'")
