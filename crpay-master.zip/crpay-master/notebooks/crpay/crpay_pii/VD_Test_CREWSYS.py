# Databricks notebook source
import pandas as pd
from pandas import read_csv
import csv
from pyspark.sql import SparkSession


# COMMAND ----------

dbutils.widgets.text("TableName", "")
TableName = dbutils.widgets.get("TableName")

dbutils.widgets.text("PrepTableName", "")
PrepTableName = dbutils.widgets.get("PrepTableName")

dbutils.widgets.text("VDTableName", "")
VDTableName = dbutils.widgets.get("VDTableName")

dbutils.widgets.text("YEAR", "")
YEAR = dbutils.widgets.get("YEAR")

dbutils.widgets.text("Month", "")
Month = dbutils.widgets.get("Month")


dbutils.widgets.text("file_location", "")
file_location = dbutils.widgets.get("file_location")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("ProcessJson", "")
ProcessJson = dbutils.widgets.get("ProcessJson")


dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Crewpay_Run", " ")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

# COMMAND ----------

receiver_emails = receiver_emails.split()

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, col


VD_JSON_DATA = spark.sql("""
  select SUBSTRING(DATA, 0, 132) as DATA,REC_NUMBER from {0} WHERE YEAR = {1} AND MONTH = {2} ORDER BY REC_NUMBER""".format(VDTableName,YEAR,Month))

VD_JSON_DATA = VD_JSON_DATA.select(regexp_replace(col("DATA"), " ", "").alias('VD_JSON_DATA'),"REC_NUMBER").orderBy("REC_NUMBER")

#display(VD_JSON_DATA)
VD_JSON_DATA.createOrReplaceTempView("VD_JSON_DATA")
VD_JSON_DATA.count()

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

VD_PREP_DATA = spark.sql("""
   SELECT concat(PRE_CREW_TKG_RPT_DATA,' ',POST_CREW_TKG_RPT_DATA) AS DATA, REC_NUMBER from {0} WHERE YEAR = {1} AND MONTH = {2} ORDER BY REC_NUMBER """.format(PrepTableName,YEAR,Month))


VD_PREP_DATA = VD_PREP_DATA.select(regexp_replace(col("DATA")," ", "").alias('VD_PREP_DATA'),"REC_NUMBER")

VD_PREP_DATA.createOrReplaceTempView("prepdata")

#VD_PREP_DATA.count()
VD_PREP_DATA = spark.sql("select *  from prepdata where  ((trim(VD_PREP_DATA) not like '%CREWMEMBERPRE/POSTACTIVITYREPORTMONTHSTARTIN%') OR (trim(REC_NUMBER) == 1 )) ")



CREW1=[]
REC_NUM = 0 

for row in VD_PREP_DATA.collect(): 
  value = row.VD_PREP_DATA.rstrip(' ')
 
  REC_NUM = REC_NUM +1 
  CREW_TKG_RPT_DATA2 = "{0}|{1}".format(value,REC_NUM)
  CREW1.append(CREW_TKG_RPT_DATA2.split('|'))
   


s = StructType([
  
  StructField('VD_PREP_DATA', StringType(), True),
         StructField('REC_NUMBER', StringType(), True)
])


VD = spark.createDataFrame(CREW1, schema=s)
VD = VD.select(col("VD_PREP_DATA"),col("REC_NUMBER")).orderBy("REC_NUMBER")

VD.createOrReplaceTempView("VD_PREP_DATA")

VD.count()


# COMMAND ----------

VD_PREP_JSON_DIFF = spark.sql("""

select count(*) as count from (
  
  
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
  except
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
   
  ) """
)


# COMMAND ----------

VD_JSON_PREP_DIFF = spark.sql("""

select count(*) as count from (
  
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  
  except
  
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
  
   
  ) """
)


# COMMAND ----------

VD_PREP = VD_JSON_PREP_DIFF.select("count").collect()[0][0]
PREP_VD = VD_PREP_JSON_DIFF.select("count").collect()[0][0]
VD_PREP_COUNT = int(VD_PREP)
PREP_VD_COUNT = int(PREP_VD)




# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

if (( VD_PREP_COUNT == 1) and ( PREP_VD_COUNT == 1)):
    print ("Matching")
    send_email(sender_email , receiver_emails , 'matching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}'.format(PrepTableName,ProcessJson,YEAR,Month) , bcc=None, attachments = None)
else:
    VD_JSON_PREP_DIFF_DATA = spark.sql("""

select REC_NUMBER AS VD_JSON_DATA_REC_NUMBER,VD_JSON_DATA from (
    SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  except
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
   
  ) """
)

    VD_PREP_JSON_DIFF_DATA = spark.sql("""

select REC_NUMBER AS VD_PREP_DATA_REC_NUMBER,VD_PREP_DATA from (
  
  
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
  except
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
   
  ) """
)
    join_data = VD_JSON_PREP_DIFF_DATA.join(VD_PREP_JSON_DIFF_DATA, VD_JSON_PREP_DIFF_DATA.VD_JSON_DATA_REC_NUMBER == VD_PREP_JSON_DIFF_DATA.VD_PREP_DATA_REC_NUMBER) 
    
    mismatch_records =  file_location + 'PREP_DIFF_' + Crewpay_Run + '/'+ YEAR + '/' + Month + '/'
    #print(mismatch_records)
    join_data.repartition(1).write.format("csv").option("inferSchema","true").option("header","true").mode("overwrite").save(mismatch_records)
    count = join_data.count()

    count = str(count)
    send_email(sender_email , receiver_emails , 'mismatching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}\r\r\nJsonFile_Name: {4}'.format(PrepTableName,ProcessJson,YEAR,Month,mismatch_records) , bcc=None, attachments = None)

# COMMAND ----------


