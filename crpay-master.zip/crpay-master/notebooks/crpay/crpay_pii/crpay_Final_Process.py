# Databricks notebook source
# MAGIC     %md # Crpay_Final_Process
# MAGIC
# MAGIC Version History of  Crpay_Final_Process
# MAGIC    
# MAGIC    Changes:
# MAGIC
# MAGIC      Developer: Amar
# MAGIC      Date Created: 02/22/2021
# MAGIC      Date Updated : 02/22/2021
# MAGIC      Purpose: Performs Housekeeping and trigger success email

# COMMAND ----------

# DBTITLE 1,Create widgets
#Reading parameter values from DataFactory

dbutils.widgets.text("Adf_Name", "")

Adf_Name = dbutils.widgets.get("Adf_Name")

dbutils.widgets.text("Pipeline_Name", "")

Pipeline_Name = dbutils.widgets.get("Pipeline_Name")

dbutils.widgets.text("From_Email", "")

From_Email = dbutils.widgets.get("From_Email")

dbutils.widgets.text("To_Email", "")

To_Email = dbutils.widgets.get("To_Email")

dbutils.widgets.text("Json_Input", "")

Json_Input = dbutils.widgets.get("Json_Input")

dbutils.widgets.text("Tape_Name", "")

Tape_Name = dbutils.widgets.get("Tape_Name")

dbutils.widgets.text("Indicator_File_Path", "")

Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Raw_Archive_Path", "")

Raw_Archive_Path = dbutils.widgets.get("Raw_Archive_Path")

dbutils.widgets.text("MOCAM_Path", "")

MOCAM_Path = dbutils.widgets.get("MOCAM_Path")

dbutils.widgets.text("Input_File_Name", "")

Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("STG_Output_File_Report", "")

STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")

# COMMAND ----------

# DBTITLE 1,Load Standard Libraries
#Importing required libraries and functions

import datetime;

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# Defining Parameters for mocam logger function

SYS_NM = "crpay"
NOTEBOOK_NM = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
CLUSTER_NM = spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
MSG_DESC = ""
START_TMS = str(datetime.now())
TARGET_NM = ""
END_TMS = ""
STATUS_CD = ""
TARGET_ADLS_ZONE = "struct"
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
SRC_FILE_NM = get_drain_file_name(Json_Input)
TARGET_TYPE_CD = "T"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"

print("Success Path: " + SUCCESS_PATH)
print("Fail Path: " + FAIL_PATH)
print("Run ID: " + RUN_ID)
print("Notebook URL: " + NOTEBOOK_JOB_URL)
print("Susyem Name: " + SYS_NM)
print("Source File Name: " + SRC_FILE_NM)

# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Performs Housekeeping and trigger success email
# Performs Housekeeping and trigger success email
try :
  #Deleting touch file directory
  dbutils.fs.rm(Indicator_File_Path, recurse = True)
  
  #Recreating empty touch file directory for next run
  dbutils.fs.mkdirs(Indicator_File_Path)
  
  #Moving file from raw to raw archive folder
  dbutils.fs.mv(Json_Input+'/'+col("_metadata.file_path"), Raw_Archive_Path+"/"+str(START_TMS).replace("-", "").replace(" ", "_").replace(":", "").replace(".", "_")+'/'+col("_metadata.file_path"))
  
  #Recreating empty raw directory for next run
  #dbutils.fs.mkdirs(Json_Input)
  
  #Deleting stage file directory
  dbutils.fs.rm(STG_Output_File_Report, recurse = True)
  
  To_Email = To_Email.split()
  #Sending Success email with procesed record count
  #send_email(From_Email, To_Email, "Orion Azure: CRPAY-"+Tape_Name+" File Process Completed", "CRPAY: "+Tape_Name+" Crewmember capture file processed in Orion Azure \r\r\nInput_Binary_File_Name: "+SRC_FILE_NM, bcc=None, attachments = None)
  send_email(To_Email, "Orion Azure: CRPAY-"+Tape_Name+" File Process Completed", "CRPAY: "+Tape_Name+" Crewmember capture file processed in Orion Azure <br>Input_Binary_File_Name: "+SRC_FILE_NM, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    
except Exception as e:
  MSG_DESC = "Failed to Perform Housekeeping and trigger success email. Error:" + " " + str(e)
  END_TMS = str(datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

# DBTITLE 1,Write Final Success Log
# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing Housekeeping and trigger success email"
END_TMS = str(datetime.now())

# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

dbutils.notebook.exit(SRC_FILE_NM)
