# Databricks notebook source
dbutils.widgets.text("config_File_Daily_Weekly", "")
config_File_Daily_Weekly = dbutils.widgets.get("config_File_Daily_Weekly")

dbutils.widgets.text("Storage", "")
Storage = dbutils.widgets.get("Storage")

dbutils.widgets.text("Secret_Scope", "")
Secret_Scope = dbutils.widgets.get("Secret_Scope")

dbutils.widgets.text("Secret_Key", "")
Secret_Key = dbutils.widgets.get("Secret_Key")

dbutils.widgets.text("config_File_Monthly", "")
config_File_Monthly = dbutils.widgets.get("config_File_Monthly")

print("config_File_Daily_Weekly: ", config_File_Daily_Weekly)
print("Storage: ", Storage)
print("config_File_Monthly: ", config_File_Monthly)

# COMMAND ----------

# Set the storage account key
spark.conf.set(f"fs.azure.account.key.{Storage}.blob.core.windows.net",
dbutils.secrets.get(scope=f"{Secret_Scope}", key=f"{Secret_Key}"))

# COMMAND ----------

# Read the config file
Optimize_Tables_DF = spark.read.format('csv').load(config_File_Daily_Weekly)

# Loop through the rows and execute the commands
for row in Optimize_Tables_DF.collect():
    print("Executing command '",row._c0,"' Started")
    spark.sql(row._c0)
    print("Executing command '",row._c0,"' Finished")

# COMMAND ----------

import calendar
import datetime

def first_sunday(year, month):
    # Find the first day of the month
    first_day = datetime.date(year, month, 1)
    
    # Find the weekday of the first day (0=Monday, 6=Sunday)
    weekday_of_first_day = first_day.weekday()
    
    # Calculate the difference in days to the first Sunday
    days_to_sunday = (6 - weekday_of_first_day) % 7
    
    # Calculate the first Sunday date
    first_sunday_date = int(str(first_day + datetime.timedelta(days=days_to_sunday))[-2:])
    
    return first_sunday_date

# Get the current date
current_date = datetime.datetime.now()

# Extract the current year and month
year = int(current_date.year)
month = int(current_date.month)
current_day = int(current_date.day)
first_sunday_date_cal = first_sunday(year, month)

print(f"The first Sunday of {calendar.month_name[month]} {year} is: {first_sunday_date_cal}")
print("current day is: ", current_day)

# COMMAND ----------

# Checking if the current day is the first Sunday
if(current_day == first_sunday_date_cal):
    print("Today is first Sunday of the month. So, executing the monthly commands")

    # Read the config file
    Optimize_Tables_DF = spark.read.format('csv').load(config_File_Monthly)

    # Loop through the rows and execute the commands
    for row in Optimize_Tables_DF.collect():
        print("Executing command '",row._c0,"' Started")
        spark.sql(row._c0)
        print("Executing command '",row._c0,"' Finished")

else:
    print("Not the first Sunday of the month. So, skipping the monthly commands")
