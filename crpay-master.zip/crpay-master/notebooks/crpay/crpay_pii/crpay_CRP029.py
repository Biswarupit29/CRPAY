# Databricks notebook source
# DBTITLE 1,Right module together such as PPA & PPB,PPC & PPD from Struct_to_Struct
"Version History of combined module PPA & PPB,PPC and PPD struct_to_strut"

"Changes:"

"Developer: Nitin"
"Date Created: 10/23/2020"
"Date Updated : 03/03/2021"
"Purpose: Read right module together such as PPA & PPB,PPC & PPD data from Struct zone and Load into struct Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for inputs which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File_1", " ")
Input_File_1 = dbutils.widgets.get("Input_File_1")

dbutils.widgets.text("Input_File_2", " ")
Input_File_2 = dbutils.widgets.get("Input_File_2")

dbutils.widgets.text("Output_File_Data", " ")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

dbutils.widgets.text("Manual_Input_File_1", "")
Manual_Input_File_1 = dbutils.widgets.get("Manual_Input_File_1")

dbutils.widgets.text("Manual_Input_File_2", "")
Manual_Input_File_2 = dbutils.widgets.get("Manual_Input_File_2")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
import datetime

SYS_NM = "crpay"
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "STRUCT"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"


# COMMAND ----------

Partition_BY_YEAR = (Manual_Input_File_1.split('/')[5]).split('=')[1]
Partition_BY_MONTH = (Manual_Input_File_1.split('/')[6]).split('=')[1]
Partition_BY_YEAR= int(Partition_BY_YEAR)
Partition_BY_MONTH = int(Partition_BY_MONTH)
print(Partition_BY_YEAR)
print(Partition_BY_MONTH)

Input_File_List = Manual_Input_File_1.split('/')
delimiter = "/"
Input_File_Path = delimiter.join(Input_File_List[:-2])+"/"
print(Input_File_Path)

# COMMAND ----------

Partition_BY_YEAR_2 = (Manual_Input_File_2.split('/')[5]).split('=')[1]
Partition_BY_MONTH_2 = (Manual_Input_File_2.split('/')[6]).split('=')[1]
Partition_BY_YEAR_2= int(Partition_BY_YEAR_2)
Partition_BY_MONTH_2 = int(Partition_BY_MONTH_2)
print(Partition_BY_YEAR_2)
print(Partition_BY_MONTH_2)

Input_File_List_2 = Manual_Input_File_2.split('/')
delimiter = "/"
Input_File_Path_2 = delimiter.join(Input_File_List_2[:-2])+"/"
print(Input_File_Path_2)

# COMMAND ----------

Partition_BY_YEAR_3 = (Input_File_1.split('/')[5]).split('=')[1]
Partition_BY_MONTH_3 = (Input_File_1.split('/')[6]).split('=')[1]
Partition_BY_YEAR_3= int(Partition_BY_YEAR_3)
Partition_BY_MONTH_3 = int(Partition_BY_MONTH_3)
print(Partition_BY_YEAR_3)
print(Partition_BY_MONTH_3)
Partition_BY_YEAR_4 = (Input_File_1.split('/')[5]).split('=')[1]
Partition_BY_MONTH_4 = (Input_File_1.split('/')[6]).split('=')[1]
Partition_BY_YEAR_4= int(Partition_BY_YEAR_4)
Partition_BY_MONTH_4 = int(Partition_BY_MONTH_4)
print(Partition_BY_YEAR_4)
print(Partition_BY_MONTH_4)


# COMMAND ----------

# DBTITLE 1,Read Input Data Files for combination of PPA & PPB,PPC & PPD from Struct Zone
#Read Input Data Files for PPA-PPB and PPC-PPD

try:
  if(LOAD_TYPE=='M') or (LOAD_TYPE=='m'):

    cp_df_samp_proc_post = spark.read.format("delta").load(Input_File_Path).filter(col("YEAR") == Partition_BY_YEAR).filter(col("MONTH") == Partition_BY_MONTH)
    cp_df_samp_proc_pre = spark.read.format("delta").load(Input_File_Path_2).filter(col("YEAR") == Partition_BY_YEAR_2).filter(col("MONTH") == Partition_BY_MONTH_2)
    SRC_FILE_NM1 = cp_df_samp_proc_post.select("SOURCE_FILENAME").collect()[0][0]
    SRC_FILE_NM2 = cp_df_samp_proc_pre.select("SOURCE_FILENAME").collect()[0][0]
    SRC_FILE_NM = SRC_FILE_NM1 + "_" + SRC_FILE_NM2
    print(SRC_FILE_NM)
    

  else:  

    cp_df_samp_proc_post = spark.read.format("delta").load(Input_File_Path).filter(col("YEAR") == Partition_BY_YEAR_3).filter(col("MONTH") == Partition_BY_MONTH_3)
    cp_df_samp_proc_pre  = spark.read.format("delta").load(Input_File_Path_2).filter(col("YEAR") == Partition_BY_YEAR_4).filter(col("MONTH") == Partition_BY_MONTH_4)
    
    SRC_FILE_NM1 = cp_df_samp_proc_post.select("SOURCE_FILENAME").collect()[0][0]
    SRC_FILE_NM2 = cp_df_samp_proc_pre.select("SOURCE_FILENAME").collect()[0][0]
    SRC_FILE_NM = SRC_FILE_NM1 + "_" + SRC_FILE_NM2
    print("SRC_FILE_NM")
  MSG_DESC = "right combination of input data of PPA & PPB,PPC & PPD have been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  # log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read right combination of input data of PPA & PPB,PPC & PPD from Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  # log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Deduplicating pre and post data
#Deduplicating pre and post data using SQL solution
cp_df_samp_proc_post.createOrReplaceTempView("post_table")
cp_df_samp_proc_post = spark.sql("select NFZ_OUT_DATA,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH,max(LOAD_TIME) as LOAD_TIME,max(SOURCE_FILENAME) as SOURCE_FILENAME from post_table GROUP BY NFZ_OUT_DATA,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH order by NFZ_OUT_CTR")

cp_df_samp_proc_pre.createOrReplaceTempView("pre_table")
cp_df_samp_proc_pre = spark.sql("select NFZ_OUT_DATA,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH,max(LOAD_TIME) as LOAD_TIME,max(SOURCE_FILENAME) as SOURCE_FILENAME from pre_table GROUP BY NFZ_OUT_DATA,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH order by NFZ_OUT_CTR")

# COMMAND ----------

# DBTITLE 1,remove unwanted additional records having lines of nines e.g. 999999999999
#remove unwanted additional records having lines of nines
cp_df_samp_proc_pre = cp_df_samp_proc_pre.filter("NFZ_OUT_DATA not like '999999999999%'")
cp_df_samp_proc_post = cp_df_samp_proc_post.filter("NFZ_OUT_DATA not like '999999999999%'")


# COMMAND ----------

# DBTITLE 1,Merging pre and post DFs 
from pyspark.sql import DataFrame
from pyspark.sql.types import *

try:
  # defined Schema for output data file
  DataSchema = StructType([StructField("CREW_TKG_RPT", StringType()),StructField("CREW_POST_TKG_RPT", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])

  def fs(str,len,val):
    return str.rjust(len,val)[:len]

  CREW_TKG_RPT_DATA_APPEND_LIST = []

  # Sorting Input files based on Employee number and merging them based on Emp number 

  from pyspark.sql import functions as F
  from pyspark.sql.window import *
  from pyspark.sql.functions import row_number

  cp_df_samp_proc_pre = cp_df_samp_proc_pre.sort("NFZ_OUT_NBR",ascending=True)
  cp_df_samp_proc_post = cp_df_samp_proc_post.sort("NFZ_OUT_NBR",ascending=True)

  cp_df_samp_proc_pre = cp_df_samp_proc_pre.withColumn("id", F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))
  cp_df_samp_proc_post = cp_df_samp_proc_post.withColumn("id",F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))

  cp_df_samp_proc_pre1 = cp_df_samp_proc_pre.selectExpr("NFZ_OUT_STA as PRE_NFZ_OUT_STA","NFZ_OUT_DATA as PRE_NFZ_OUT_DATA","NFZ_OUT_CTR as PRE_NFZ_OUT_CTR","NFZ_OUT_NAME as PRE_NFZ_OUT_NAME","NFZ_OUT_NBR as PRE_NFZ_OUT_NBR","NFZ_OUT_IND as PRE_NFZ_OUT_IND","NFZ_OUT_PART as PRE_NFZ_OUT_PART","YEAR as PRE_YEAR","MONTH as PRE_MONTH","SOURCE_FILENAME as PRE_SOURCE_FILENAME","id as pre_id")
  cp_df_samp_proc_post1 = cp_df_samp_proc_post.selectExpr("NFZ_OUT_STA as POST_NFZ_OUT_STA","NFZ_OUT_DATA as POST_NFZ_OUT_DATA","NFZ_OUT_CTR as POST_NFZ_OUT_CTR","NFZ_OUT_NAME as POST_NFZ_OUT_NAME","NFZ_OUT_NBR as POST_NFZ_OUT_NBR","NFZ_OUT_IND as POST_NFZ_OUT_IND","NFZ_OUT_PART as POST_NFZ_OUT_PART","YEAR as POST_YEAR","MONTH as POST_MONTH","SOURCE_FILENAME as POST_SOURCE_FILENAME","id as post_id")

  Merge_DF = cp_df_samp_proc_pre1.join(cp_df_samp_proc_post1, ((cp_df_samp_proc_pre1.PRE_NFZ_OUT_NBR == cp_df_samp_proc_post1.POST_NFZ_OUT_NBR) & ( cp_df_samp_proc_pre1.pre_id == cp_df_samp_proc_post1.post_id)), how = 'full')

  Merge_DF.createOrReplaceTempView("Merge_PPA_PPB")

  Merge_DF2 = spark.sql("SELECT coalesce(PRE_NFZ_OUT_STA,POST_NFZ_OUT_STA) as PRE_NFZ_OUT_STA,coalesce(PRE_NFZ_OUT_DATA,' ') as PRE_NFZ_OUT_DATA, PRE_NFZ_OUT_CTR, coalesce(PRE_NFZ_OUT_NAME,POST_NFZ_OUT_NAME) as PRE_NFZ_OUT_NAME, coalesce(cast(PRE_NFZ_OUT_NBR as BIGINT),cast(POST_NFZ_OUT_NBR as BIGINT)) as PRE_NFZ_OUT_NBR1, coalesce(PRE_NFZ_OUT_IND,POST_NFZ_OUT_IND) as PRE_NFZ_OUT_IND, coalesce(PRE_NFZ_OUT_PART,POST_NFZ_OUT_PART) as PRE_NFZ_OUT_PART,coalesce(PRE_SOURCE_FILENAME,' ') as PRE_SOURCE_FILENAME, coalesce(POST_NFZ_OUT_STA,' ') as POST_NFZ_OUT_STA, coalesce(POST_NFZ_OUT_DATA, ' ') as POST_NFZ_OUT_DATA, POST_NFZ_OUT_CTR, coalesce(POST_NFZ_OUT_NAME,PRE_NFZ_OUT_NAME) as POST_NFZ_OUT_NAME, coalesce(cast(POST_NFZ_OUT_NBR as BIGINT),cast(PRE_NFZ_OUT_NBR as BIGINT)) as POST_NFZ_OUT_NBR1, coalesce(POST_NFZ_OUT_IND, PRE_NFZ_OUT_IND) as POST_NFZ_OUT_IND, coalesce(POST_NFZ_OUT_PART,PRE_NFZ_OUT_PART) as POST_NFZ_OUT_PART,coalesce(POST_SOURCE_FILENAME,' ') as POST_SOURCE_FILENAME,coalesce(PRE_YEAR,POST_YEAR) as YEAR, coalesce(PRE_MONTH,POST_MONTH) as MONTH FROM Merge_PPA_PPB  order by coalesce(coalesce(POST_NFZ_OUT_NBR,999999),coalesce(PRE_NFZ_OUT_NBR,999999)), coalesce(POST_NFZ_OUT_CTR,PRE_NFZ_OUT_CTR) ")
  MSG_DESC = "pre and post data has been merged successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to merge pre and post data. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,Merged data from pre and post files are processed
#Merged data from pre and post files are processed and transformed based on three important logic.
# 1. if pre emp_number and part is equal to Post emp_number and part
# 2. if pre emp_number is greater than post emp_number
# 3. if pre emp_number is less than post emp_number

from functools import reduce
from pyspark.sql import DataFrame
import datetime
try:
  CREW_TKG_RPT_DATA_APPEND_DF=[]

  REC_CTR = 0
  SAVE_PART = ''
  SAVE_STA = ''
  SAVE_NBR = ''
  HOLD_IND = ''
  HOLD_NBR = ''
  LOAD_TIME = datetime.datetime.now()
  for row in Merge_DF2.collect(): 
    YEAR = row.YEAR
    MONTH = row.MONTH
    PRE_INPUT_FILENAME = row.PRE_SOURCE_FILENAME
    POST_INPUT_FILENAME = row.POST_SOURCE_FILENAME

    #print(row)
    if ((row.PRE_NFZ_OUT_NBR1 == row.POST_NFZ_OUT_NBR1)  & (row.PRE_NFZ_OUT_PART == row.POST_NFZ_OUT_PART)) :
      CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
      CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
      NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
      NFZ_OUT_IND = row.POST_NFZ_OUT_IND
      HOLD_IND = row.POST_NFZ_OUT_IND
      if row.PRE_NFZ_OUT_STA == '   ' :
        NFZ_OUT_STA = row.POST_NFZ_OUT_STA
        SAVE_STA = row.POST_NFZ_OUT_STA
      else:
        NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
        SAVE_STA = row.PRE_NFZ_OUT_STA
      NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
      SAVE_NBR = row.PRE_NFZ_OUT_NBR1
      HOLD_NBR = row.PRE_NFZ_OUT_NBR1
      REC_CTR = REC_CTR+1
      NFZ_OUT_CTR = REC_CTR
      NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME
      CREW_TKG_RPT_DATA_TMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)

      CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP1.split(','))


    elif ((row.PRE_NFZ_OUT_NBR1 > row.POST_NFZ_OUT_NBR1)) :
      CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
      CREW_POST_TKG_RPT = ' '
      NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
      if (HOLD_NBR == row.PRE_NFZ_OUT_NBR1) :
        NFZ_OUT_IND = HOLD_IND
      else:
        NFZ_OUT_IND = row.PRE_NFZ_OUT_IND
      NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
      NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
      REC_CTR = REC_CTR+1
      NFZ_OUT_CTR = REC_CTR
      NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME

      CREW_TKG_RPT_DATA_TMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)

      CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))

    elif ((row.PRE_NFZ_OUT_NBR1 < row.POST_NFZ_OUT_NBR1)) :

      CREW_TKG_RPT = ' '
      CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
      NFZ_OUT_PART = row.POST_NFZ_OUT_PART
      NFZ_OUT_IND = row.POST_NFZ_OUT_IND
      if (SAVE_NBR == row.POST_NFZ_OUT_NBR1) :
        NFZ_OUT_STA = SAVE_STA
      else:
        NFZ_OUT_STA = row.POST_NFZ_OUT_STA
      NFZ_OUT_NBR = row.POST_NFZ_OUT_NBR1
      REC_CTR = REC_CTR+1    
      NFZ_OUT_CTR = REC_CTR
      NFZ_OUT_NAME = row.POST_NFZ_OUT_NAME

      CREW_TKG_RPT_DATA_TMP3 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)

      CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(',')) 


  MSG_DESC = "pre and post data has been merged successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to merge pre and post data. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 

CREW_TKG_RPT_DATA_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_APPEND_LIST,schema=DataSchema)

# COMMAND ----------

#PPA-PPB and PPC-PPD parquet/delta output files 
def write():
  CREW_TKG_RPT_DATA_APPEND_DF.select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").partitionBy("YEAR","MONTH").save(Output_File_Data)

# COMMAND ----------

# defining Target_name table based on src file name
if('PPA' in SRC_FILE_NM):
  TARGET_NM = "crpay_struct.crp029_ppa_ppb"
else:
  TARGET_NM = "crpay_struct.crp029_ppc_ppd"
#print(TARGET_NM)

# COMMAND ----------

# DBTITLE 1,Save pre and post records into delta struct zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "pre and post records has been successfully written in Struct zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STRUCT")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent pre and post records has been skipped without saving due to rerun of same file in struct zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write pre and post records in Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e




# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing of pre and post records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
