# Databricks notebook source
# DBTITLE 1,Count validation notebook
"Version History of count validation notebook"

"Changes:"

"Developer: Nitin"
"Date Created: 11/12/2020"
"Date Updated : 02/23/2021"
"Purpose: common utility to validate count of each module for P and L series"

# COMMAND ----------

# DBTITLE 1,Create widgets
dbutils.widgets.text("Json_Input", "")
 
Json_Input = dbutils.widgets.get("Json_Input")
 
dbutils.widgets.text("Adf_Name", "")
 
Adf_Name = dbutils.widgets.get("Adf_Name")
 
dbutils.widgets.text("Pipeline_Name", "")
 
Pipeline_Name = dbutils.widgets.get("Pipeline_Name")
 
dbutils.widgets.text("From_Email", "")
 
From_Email = dbutils.widgets.get("From_Email")
 
dbutils.widgets.text("To_Email", "")
 
To_Email = dbutils.widgets.get("To_Email")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("Lseries", "")
Lseries = dbutils.widgets.get("Lseries")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;

# COMMAND ----------

# DBTITLE 1,Read P/L series Records from Raw Zone

if((Crewpay_Run  =='LDA') or (Crewpay_Run =='LDC') or (Crewpay_Run =='LDP')):
  Json_Input_Path = Json_Input + 'AALD*.json'
  #getting count from input json 
  Input_json_Count = spark.read.format("json").load(Json_Input_Path).count()
  #print(Input_json_Count)
  
else:
  Json_Input_Path = Json_Input + 'AAPP*.json'
  #getting count from input json 
  Input_json_Count = spark.read.format("json").load(Json_Input_Path).count()
  #print(Input_json_Count)

# COMMAND ----------

# DBTITLE 1,Read data from files starts with conversionReport* from Raw zone
#getting new format file in JSON for validating count
conversion = "conversionReport*.json"
final_conversion_report_path =  Json_Input+conversion
Raw_converted_Count = spark.read.option("multiLine","true").json(final_conversion_report_path)

# COMMAND ----------

# DBTITLE 1,Read RawRecordReport and ConvertedRecordReport attribute values from conversionReport*
# Read RawRecordReport and ConvertedRecordReport
from pyspark.sql.functions import col
Raw_converted = Raw_converted_Count.select(col("RawRecordReport.TotalRecords").alias("RawRecordReport") ,col("ConvertedRecordReport.TotalRecords").alias("ConvertedRecordReport"))
for row in Raw_converted.collect():
  Raw_Count = row.RawRecordReport
  Converted_Count = row.ConvertedRecordReport
  


# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
#splitting receiver emails so that mails to be delivered to desginated people.
receiver_email = To_Email.split()

# COMMAND ----------

# DBTITLE 1,logic to make sure that counts are matching among input file and converted file
# logic to make sure that counts are matching among input file and converted file
import datetime

if((Crewpay_Run  =='LDA') or (Crewpay_Run =='LDC') or (Crewpay_Run =='LDP')):
  print('a')
  if(int(Raw_Count) == int(Converted_Count)):
    if(int(Raw_Count) == int(Input_json_Count)):
      Result = "Record Counts are Matching"
      send_email(receiver_email  , "CREWPAY-{0} Record Counts are Matching".format(Crewpay_Run), "Crewpay_counts_validation script on {0} <br>Record Counts are Matching for Crewpay-{1}. Below are counts <br>Raw Count : {2} <br>Converted Count : {3} <br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
      
    
    else:
      Result = "Record Counts are not Matching"
      send_email(receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crewpay_counts_validation script on {0} <br>Record Counts are not Matching for Crewpay-{1}. Below are counts<br>Raw Count : {2}<br>Converted Count : {3}<br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    
  else:
    Result = "Record Counts are not Matching"
    send_email(receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run ), "Crewpay_counts_validation script on {0} <br>Record Counts are not Matching for Crewpay-{1}. Below are counts<br>Raw Count : {2}<br>Converted Count : {3}<br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  
else:
  if(int(Raw_Count) == int(Converted_Count)):
    if(int(Raw_Count) == int(Input_json_Count)):
      Result = "Record Counts are Matching"
      send_email(receiver_email  , "CREWPAY-{0} Record Counts are Matching".format(Crewpay_Run), "Crwpay_counts_validation script on {0} <br>Record Counts are Matching for CREWPAY-{1}. Below are counts <br>Raw Count : {2} <br>Converted Count : {3} <br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    
    else:
      Result = "Record Counts are not Matching"
      send_email(receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crwpay_counts_validation script on {0} <br>Record Counts are not Matching for CREWPAY-{1}. Below are counts<br>Raw Count : {2}<br>Converted Count : {3}<br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    
  else:
    Result = "Record Counts are not Matching"
    send_email(receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crwpay_counts_validation script on {0} <br>Record Counts are not Matching for CREWPAY-{1}. Below are counts<br>Raw Count : {2}<br>Converted Count : {3}<br>Json Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  

# COMMAND ----------

# DBTITLE 1,logic to make sure that counts are matching among input file and converted file_Bkp
# # logic to make sure that counts are matching among input file and converted file
# import datetime

# if((Crewpay_Run  =='LDA') or (Crewpay_Run =='LDC') or (Crewpay_Run =='LDP')):
#   print('a')
#   if(int(Raw_Count) == int(Converted_Count)):
#     if(int(Raw_Count) == int(Input_json_Count)):
#       Result = "Record Counts are Matching"
#       send_email(From_Email , receiver_email  , "CREWPAY-{0} Record Counts are Matching".format(Crewpay_Run), "Crewpay_counts_validation script on {0} \r\r\nRecord Counts are Matching for Crewpay-{1}. Below are counts \r\r\nRaw Count : {2} \r\nConverted Count : {3} \r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
    
#     else:
#       Result = "Record Counts are not Matching"
#       send_email(From_Email , receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crewpay_counts_validation script on {0} \r\r\nRecord Counts are not Matching for Crewpay-{1}. Below are counts\r\r\nRaw Count : {2}\r\nConverted Count : {3}\r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
    
#   else:
#     Result = "Record Counts are not Matching"
#     send_email(From_Email , receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run ), "Crewpay_counts_validation script on {0} \r\r\nRecord Counts are not Matching for Crewpay-{1}. Below are counts\r\r\nRaw Count : {2}\r\nConverted Count : {3}\r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
  
# else:
#   if(int(Raw_Count) == int(Converted_Count)):
#     if(int(Raw_Count) == int(Input_json_Count)):
#       Result = "Record Counts are Matching"
#       send_email(From_Email , receiver_email  , "CREWPAY-{0} Record Counts are Matching".format(Crewpay_Run), "Crwpay_counts_validation script on {0} \r\r\nRecord Counts are Matching for CREWPAY-{1}. Below are counts \r\r\nRaw Count : {2} \r\nConverted Count : {3} \r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
    
#     else:
#       Result = "Record Counts are not Matching"
#       send_email(From_Email , receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crwpay_counts_validation script on {0} \r\r\nRecord Counts are not Matching for CREWPAY-{1}. Below are counts\r\r\nRaw Count : {2}\r\nConverted Count : {3}\r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
    
#   else:
#     Result = "Record Counts are not Matching"
#     send_email(From_Email , receiver_email  , "CREWPAY-{0} Count Mismatch Alert".format(Crewpay_Run), "Crwpay_counts_validation script on {0} \r\r\nRecord Counts are not Matching for CREWPAY-{1}. Below are counts\r\r\nRaw Count : {2}\r\nConverted Count : {3}\r\nJson Files Record Count {4}".format(datetime.datetime.now(),Crewpay_Run,Raw_Count,Converted_Count,Input_json_Count) , bcc=None, attachments = None)
  

# COMMAND ----------

dbutils.notebook.exit(Result)
