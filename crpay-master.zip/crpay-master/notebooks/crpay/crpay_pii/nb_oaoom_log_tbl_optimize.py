# Databricks notebook source
dbutils.widgets.text("oaoom_delta_path", "")

oaoom_delta_path = dbutils.widgets.get("oaoom_delta_path")

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.window import *
from datetime import datetime

# COMMAND ----------

# results = []
# id = 0

# stack = [oaoom_delta_path]
# while len(stack) > 0:
#   current_folder = stack.pop(0)
#   for file in dbutils.fs.ls(current_folder):
#     if file.isDir():
#       try:
#         delta_check_path = f"{file.path}/_delta_log"
#         dbutils.fs.ls(delta_check_path)  # raises an exception if _delta_log not found in directory
#         id = id+1
#         start_timestamp = datetime.now()
#         print(f"{id}.Optimizing table :{file.path}")
#         result = spark.sql(f"OPTIMIZE delta.`{file.path}`").withColumn("ID", lit(id)).withColumn("Start_Timestamp", to_timestamp(lit(start_timestamp)))
#         end_timestamp = datetime.now()
#         result = result.withColumn("End_Timestamp", to_timestamp(lit(end_timestamp)))
#         results.append(result)
#       except:            
#         stack.append(file.path)

# df = reduce(DataFrame.unionAll, results)

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame

results = []
id = 0

modules = ["crpay", "fsbch", "enycw", "fcrm", "rim", "ttsfa"]
stack = [oaoom_delta_path]
while len(stack) > 0:
  current_folder = stack.pop(0)
  for file in dbutils.fs.ls(current_folder):
    for m in modules:
      if(m in file.path):
        # print(file.path)
        if file.isDir():
          try:
            delta_check_path = f"{file.path}/_delta_log"
            dbutils.fs.ls(delta_check_path)  # raises an exception if _delta_log not found in directory
            id = id+1
            start_timestamp = datetime.now()
            print(f"{id}.Optimizing table :{file.path}")
            result = spark.sql(f"OPTIMIZE delta.`{file.path}`").withColumn("ID", lit(id)).withColumn("Start_Timestamp", to_timestamp(lit(start_timestamp)))
            end_timestamp = datetime.now()
            result = result.withColumn("End_Timestamp", to_timestamp(lit(end_timestamp)))
            results.append(result)
          except:            
            stack.append(file.path)

# df = reduce(DataFrame.unionAll, results)
union_all = lambda df1, df2: df1.unionAll(df2)
df = reduce(union_all, results)

# COMMAND ----------

window_spec = Window.orderBy("ID")
output = df.withColumn("Elapsed_Time_in_Seconds",unix_timestamp(col("End_Timestamp")) - unix_timestamp(col("Start_Timestamp"))).select("ID","path","Start_Timestamp","End_Timestamp","Elapsed_Time_in_Seconds","metrics").orderBy("ID")

# COMMAND ----------

output.display()
