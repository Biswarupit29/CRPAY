# Databricks notebook source
pip install  openpyxl==2.6.2

# COMMAND ----------

pip install xlsxwriter

# COMMAND ----------

pip install azure-storage-blob

# COMMAND ----------

pip install azure-storage-blob --upgrade

# COMMAND ----------

dbutils.widgets.text("ProcessJson", "")
ProcessJson = dbutils.widgets.get("ProcessJson")

dbutils.widgets.text("storage_account_name", "")
storage_account_name = dbutils.widgets.get("storage_account_name")

dbutils.widgets.text("storage_account_access_key", "")
storage_account_access_key = dbutils.widgets.get("storage_account_access_key")

dbutils.widgets.text("BIN_JSON", "")
BIN_JSON = dbutils.widgets.get("BIN_JSON")

dbutils.widgets.text("blob", "")
blob = dbutils.widgets.get("blob")


dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Crewpay_Run", " ")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")


# COMMAND ----------

storage_account_name = storage_account_name
storage_account_access_key = storage_account_access_key
BIN_JSON = BIN_JSON
blob_name = blob
Crewpay_Run = Crewpay_Run
receiver_emails = receiver_emails
sender_email = sender_email
ProcessJson = ProcessJson
print(blob_name)

# COMMAND ----------

receiver_emails = receiver_emails.split()

# COMMAND ----------

spark.conf.set(
  "fs.azure.account.key."+storage_account_name+".blob.core.windows.net",
  storage_account_access_key)

# COMMAND ----------

import json
import os
from pathlib import Path
import glob
import mmap
import re
from datetime import datetime
import json
import sys
import jmespath as jp
import pandas as pd
import numpy as np
import openpyxl
import xlsxwriter
import codecs
import csv
 
  
def openFileReading(flname):
  with open(flname, 'r') as f:
    with mmap.mmap(f.fileno(), length=0, access=mmap.ACCESS_READ) as mmap_obj:
      file_data = mmap_obj.read()
      return file_data
  


# COMMAND ----------

import sys
#print(sys.version)

# COMMAND ----------

from azure.storage.blob import BlobClient


# COMMAND ----------

from io import StringIO
import pandas as pd
from azure.storage.blob import BlobClient, BlobServiceClient
import os

# COMMAND ----------



blob_service_client = BlobServiceClient.from_connection_string("DefaultEndpointsProtocol=https;AccountName="+storage_account_name+";AccountKey="+storage_account_access_key+";EndpointSuffix=core.windows.net")

blob_client = blob_service_client.get_blob_client(container="p-test-data", blob= blob_name)
blob = blob_client.download_blob().content_as_bytes()



# COMMAND ----------

import io
from io import StringIO
import sys


#file_data = openFileReading(blob)
file_data = blob.decode('cp500')
#print(file_data)
#type(file_data)
#data = io.StringIO(file_data)
#df = data.toDF()


# COMMAND ----------

import json 
line_num = 1
rec_num = 1
block_data = file_data.split('\x85')
final_dict = {}
final_list = []
#temp_dict_data = []
REC_NUM = 0
temp_dict_rec = []
#blob_client = blob_service_client.get_blob_client(container="p-test-data", blob="VDR.ACRPPP4G.Y2021.D0207.20210406211926.1.json")
#fl = blob_client.download_blob().content_as_bytes()

my_list1 = []
CREW_TKG_RPT_DATA_FINAL_LIST3=[]

for i in list(range(0, len(block_data))):
  blk = block_data[i]
  blk = blk.replace("\x00\x00", "") 
  blk = blk.replace("\x00", "") 
  REC_NUM = REC_NUM + 1
  temp_dict_data = blk + "\n"
  
  CREW_TKG_RPT_DATA_TMP2 = "{0}|{1}".format(REC_NUM,temp_dict_data)
  

 
  


  #a = pd.DataFrame.from_dict(jdata, orient='index').T
  #CREW_TKG_RPT_DATA_TMP1 = "{0}".format(temp_dict)
  
  CREW_TKG_RPT_DATA_FINAL_LIST3.append(CREW_TKG_RPT_DATA_TMP2.split('|'))

  #print(CREW_TKG_RPT_DATA_FINAL_LIST2)
  

  #data_frame = pd.DataFrame.from_dict(jdata)

  #df = pd.DataFrame(jdata)
  #pd.Series(h).to_frame()
  #df = pd.DataFrame.from_dict(h, orient='columns')





# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

DataSchema = StructType([StructField("REC_NUMBER", StringType()),StructField("DATA", StringType())])

# COMMAND ----------

file_location = 'wasbs://p-test-data@'+ storage_account_name +'.blob.core.windows.net/' 
#print(file_location)
bin_json_loaction = file_location + BIN_JSON + '/'
#print(bin_json_loaction)
#print(file_location)

# COMMAND ----------

HIST_RPT_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST3, schema=DataSchema)

#display(HIST_RPT_DF)

# COMMAND ----------


df_pd = HIST_RPT_DF.toPandas()
DF = df_pd[:-1]
df_sp = spark.createDataFrame(DF)

df_sp.createOrReplaceTempView("df")
df_sp.count()

# COMMAND ----------


HIST_RPT= spark.sql("select  REC_NUMBER,  DATA from df")
#display(HIST_RPT)
HIST_RPT.repartition(1).write.format("json").mode("overwrite").save(bin_json_loaction)

# COMMAND ----------

filevd = file_location + ProcessJson
file_loc = file_location +  BIN_JSON + '/'
jsonprocess = spark.read.format("json").load(file_loc)
Jsonconversion = spark.read.format("json").load(filevd)
jsonprocess.createOrReplaceTempView("jsonprocess")
Jsonconversion.createOrReplaceTempView("Jsonconversion")
VD_JSON_DATA = spark.sql("""
select SUBSTRING(DATA, 0, 133) as VD_JSON_DATA,REC_NUMBER from jsonprocess
  """)  
VD_JSON_DATA.createOrReplaceTempView("VD_JSON_DATA")
       
PREP_DATA = spark.sql("""
  select SUBSTRING(DATA, 0, 133) as VD_PREP_DATA,REC_NUMBER from Jsonconversion
  """)  
        
PREP_DATA.createOrReplaceTempView("PREP_DATA")
        
DIFF = spark.sql("""

select VD_JSON_DATA,REC_NUMBER from (
  
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  except
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from PREP_DATA
  
  
   
  ) """
)

mismatch_records =  file_location + 'BIN_JSON_MISSMATCH_' + Crewpay_Run
DIFF.repartition(1).write.format("csv").mode("overwrite").save(mismatch_records)

#count = missmatchcount.select("count").collect()[0][0]
        

# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

count = DIFF.count()
count = str(count)
#type(count)

# COMMAND ----------

send_email(sender_email , receiver_emails , 'Mismatch Records in bin file: ' + Crewpay_Run ,'count: ' + count + '\r\r\nMismatchRecords_File_Path: {0}'.format(mismatch_records) , bcc=None, attachments = None)