# Databricks notebook source
# DBTITLE 1,LDC/LDP raw_to_prep
"Version History of LDC/LDP raw_to_prep"

"Changes:"

"Developer: Nitin"
"Date Created: 11/12/2020"
"Date Updated : 02/23/2021"
"Purpose: Read LDC/LDP data from Raw zone and Load into Delta-prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Rejected_Records_path", "")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
receiver_emails = receiver_emails.split()

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# log report function param's 
import datetime

SYS_NM = "crpay"
SRC_FILE_NM = get_drain_file_name(Input_File)
#SRC_FILE_NM = Input_File_Name
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"

print(SRC_FILE_NM)

# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time
# The log will be written in the success folder 

SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Read LDC/LDP Records from Raw Zone
#Read Input Data Files for LDP and LDC and get Source_File name added into DF

from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
import datetime
try:
  Input_File_Path = Input_File + 'AALD*.json'
  #Input_File_Path = Input_File
  if((LOAD_TYPE =='M') or (LOAD_TYPE=='m')):
    if('LDC' in Input_File_Path):
         
        cr052_pli_df = spark.read.json(Input_File_Path)
        cr052_count_df = cr052_pli_df.count()
        #send_email(sender_email, receiver_emails, 'Crewpay-LDC Manual Load', 'Successful Manual Load for Crewpay-LDC is Started.', bcc=None, attachments = None)
        send_email(receiver_emails, 'Crewpay-LDC Manual Load', 'Successful Manual Load for Crewpay-LDC is Started.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    elif ('LDP' in Input_File_Path) :
        cr052_pli_df = spark.read.json(Input_File_Path)
        cr052_count_df = cr052_pli_df.count()
        #send_email(sender_email, receiver_emails, 'Crewpay-LDP Manual Load', 'Successful Manual Load for Crewpay-LDP is Started.', bcc=None, attachments = None)
        send_email(receiver_emails, 'Crewpay-LDP Manual Load', 'Successful Manual Load for Crewpay-LDP is Started.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    else: 
        print("LDA")
  else:
     if(('LDC' in Input_File_Path) or ('LDP' in Input_File_Path)):
        cr052_pli_df = spark.read.json(Input_File_Path)
        cr052_count_df = cr052_pli_df.count()
     else: 
        print("LDA")
  MSG_DESC = "L series data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read L series records from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,validate count of src input file before and after bad records 
#to identify bad records , load them into specified reject path thn remove those bad records for further use
try:
  cp_pii_df = spark.read.format("json").option("badRecordsPath",Rejected_Records_path ).load(Input_File_Path)
  # adding audit columns as an input file name and LOAD TIME in Data frame
  cp_pii_df = cp_pii_df.withColumn("sourcefile",col("_metadata.file_path"))
  regex_str = "[\/]([^\/]+)$"
  cp_pii_df = cp_pii_df.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))
  cp_pii_df_count =cp_pii_df.count()
  if(cr052_count_df==cp_pii_df_count):
    print("no bad records in inpout file")
  else:
    bad_records_count = (int(cr052_count_df)-int(cp_pii_df_count))
    print("bad records count: "+str(bad_records_count))
    #send_email(sender_email, receiver_emails, "Crewpay-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: Crewpay-"+ Crewpay_Run + "\r\r\nBad Records Count : {0} \r\nBad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), bcc=None, attachments = None)
    send_email(receiver_emails, "Crewpay-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: Crewpay-"+ Crewpay_Run + "<br>Bad Records Count : {0} <br>Bad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  MSG_DESC = "performed Count valdaition successfully of src input file before and after bad records"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to validate count of src input file before and after bad records. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

# DBTITLE 1,File_Format_Validation
#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0
#Checks Files Emptiness and both has equal records
try:
  count_check=0
  cnt1=cp_pii_df.count()

  if(cnt1!=0):
    count_check=1# RESULT OF COUNT CHECK

  #Checks has all required columns
  columns_checkv1=1
  expected_cols=['REC_NUMBER','IMON','IBAS','REC_NUMBER','IDAT','ISEQ','INBR','ISLT','IMSG','ILIN','IFILL','sourcefile','SOURCE_FILE','LOADTIME']
  #expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
  for cols in cp_pii_df.columns:
    if(cols not in expected_cols):
      columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1
  if(count_check==1 & columns_checkv1==1):
    print("Success")
    #send_email(sender_email , receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for Crewpay-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for Crewpay-' +Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    MSG_DESC = "File_Format_Validation looks fine"
    END_TMS = str(datetime.datetime.now())
    STATUS_CD = "S"
    SAVE_PATH = SUCCESS_PATH
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    print("Failure")
    #send_email(sender_email , receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and Format of file is not as expected for Crewpay-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(receiver_emails , 'Crewpay-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and Format of file is not as expected for Crewpay-' +Crewpay_Run, bcc=None, attachments = None)
    #send_email(sender_email , receiver_emails , 'File_Format_Validation', 'File can be Empty or/and Format of file is not as expected', bcc=None, attachments = None)
    dbutils.notebook.exit("Failure")
except Exception as e:
      MSG_DESC = "Failed to validate File_Format_Validation. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cr052_pl=cp_pii_df.sort(cp_pii_df.REC_NUMBER.asc())


# COMMAND ----------

# defined Schema for output Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

RepSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("FIXED_DATE", StringType()),StructField("IDATE", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

# COMMAND ----------

# DBTITLE 1,Data Processing for LDP and LDC files
#data processing for LDP and LDC files as per CRP052
import re
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import *
import datetime
try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  NFZ_RPT_OUT_TMP_APPEND_LIST = []
  REC_NUM = 0
  FIXED_DATE = "1966-01-02" 

  for row in cr052_pl.collect():
    OCCU_NUMBER_PER_RECORD = row.ISLT 
    IBAS = row.IBAS
    IMON = row.IMON
    DATE_NUMBER = row.IDAT
    #DATE_NUMBER = cast(DATE_NUMBER)
    SEQ_NUMBER= row.ISEQ
    I_NUMBER = row.INBR
    m_MESSAGE = re.search(r'(.\/.*?\/.*?\/.*?(?P<month>.*))', row.IMSG)
    MESSAGE = m_MESSAGE['month'] if m_MESSAGE else ''
    #Getting Current date and time
    #now = datetime.datetime.now()
    #YEAR= now.strftime("%Y")
    LINE_BREAK_FLAG ='Y'
    LOAD_TIME= row.LOADTIME
    SOURCE_FILENAME = row.SOURCE_FILE
    #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
     # print("OCCU_NUMBER_PER_RECORD"+ " "+str(OCCU_NUMBER_PER_RECORD))

            #i = OCCU_NUMBER_PER_RECORD
    if((I_NUMBER==1) & (LINE_BREAK_FLAG =='Y')):
                       REC_NUM = REC_NUM+1
                       REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                       LINE_BREAK_FLAG = 'N'
                       #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                       NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,fs(' ',64,'*'),FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,'******')
                       NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))

    for A in range(0,OCCU_NUMBER_PER_RECORD):
         if((I_NUMBER==1) & (LINE_BREAK_FLAG == 'N')):
                          ILIN = row.ILIN[A]
                          pad = ' ' * (64-len(ILIN))
                          REC_NUM = REC_NUM+1
                          REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                          #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                          if(ILIN==''):
                              FLAG =1 
                          else:
                              NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4}{5},{6},{7},{8},{9},{10}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,ILIN,pad,FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                              NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))

         elif(I_NUMBER>1):
                #print("ILIN" + ILIN)
                  ILIN = row.ILIN[A]
                  pad = ' ' * (64-len(ILIN))
                  REC_NUM = REC_NUM+1
                  REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                  #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                  if(ILIN==''):
                        FLAG =1 
                  else:
                    NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4}{5},{6},{7},{8},{9},{10}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,ILIN,pad,FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                    NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))

  MSG_DESC = "LDP/LDC Files are sucessfully processed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process LDP/LDC Files. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 
NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

# COMMAND ----------

#convert IDAT value which is in integer format into Dateformat and append static date like 1966-01-02 into converted date format.
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import year, month,unix_timestamp,from_unixtime
from pyspark.sql.types import IntegerType 
from pyspark.sql.functions import *

NFZ_RPT_OUT_TMP_APPEND_DF1= NFZ_RPT_OUT_TMP_APPEND_DF.withColumn("INTDATE",NFZ_RPT_OUT_TMP_APPEND_DF['IDATE'].cast(IntegerType()))
NFZ_RPT_OUT_TMP_APPEND_DF1=  NFZ_RPT_OUT_TMP_APPEND_DF1.selectExpr("IBAS","ISEQ","IMSG","IMON","ILIN","FIXED_DATE","IDATE","date_add(to_date(FIXED_DATE),INTDATE) as CONVERTED_IDATE","REC_NUM","LOAD_TIME","SOURCE_FILENAME")
#NFZ_RPT_OUT_TMP_APPEND_DF1 = NFZ_RPT_OUT_TMP_APPEND_DF1.selectExpr("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","year(CONVERTED_IDATE) as YEAR","month(CONVERTED_IDATE) as MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME")

NFZ_RPT_OUT_TMP_APPEND_DF1 = NFZ_RPT_OUT_TMP_APPEND_DF1.selectExpr("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","year(CONVERTED_IDATE) as CONVERTED_YEAR","REC_NUM","LOAD_TIME","SOURCE_FILENAME")
NFZ_RPT_OUT_TMP_APPEND_DF1 = NFZ_RPT_OUT_TMP_APPEND_DF1.withColumn("MONTH",from_unixtime(unix_timestamp(col("IMON"),'MMM'),'MM'))


# COMMAND ----------

# DBTITLE 1,getting right year 
NFZ_RPT_OUT_TMP_APPEND_DF1.createOrReplaceTempView("L_TEMP")
NFZ_RPT_OUT_TMP_APPEND_DF3= spark.sql("select cast(max(MONTH) as INT) as MONTH from L_TEMP group by MONTH")
MONTH = NFZ_RPT_OUT_TMP_APPEND_DF3.select("MONTH").collect()[0][0]

if (MONTH ==1):
  NFZ_RPT_OUT_TMP_APPEND_DF2 = spark.sql("select cast(max(CONVERTED_YEAR) as INT) as YEAR from L_TEMP group by CONVERTED_YEAR order by CONVERTED_YEAR desc")
  YEAR = NFZ_RPT_OUT_TMP_APPEND_DF2.select("YEAR").collect()[0][0]
else:
  NFZ_RPT_OUT_TMP_APPEND_DF2 = spark.sql("select cast(min(CONVERTED_YEAR) as INT) as YEAR from L_TEMP group by CONVERTED_YEAR")
  YEAR = NFZ_RPT_OUT_TMP_APPEND_DF2.select("YEAR").collect()[0][0]
  

# COMMAND ----------

NFZ_RPT_OUT_TMP_APPEND_DF1 = NFZ_RPT_OUT_TMP_APPEND_DF1.withColumn("YEAR",lit(YEAR))
#LDAP_DATA_DF_REC1 = LDAP_DATA_DF2.withColumn("PARTITION",lit('*')).withColumn("END_PARTITION",lit('*'))

# COMMAND ----------

import re

m_struct_zone = re.search(r'(.*?(?P<struct>.*.net\/))', Rejected_Records_path)
struct_zone = m_struct_zone['struct'] if m_struct_zone else ''
struct_zone = struct_zone + "delta-struct-pii/"
if('LDC' in SRC_FILE_NM):
  struct_zone = struct_zone + "AALDC/"
  TARGET_NM = "crpay_struct.ldc_data"
else:
  struct_zone = struct_zone + "AALDP/"
  TARGET_NM = "crpay_struct.ldp_data"


# COMMAND ----------

print(TARGET_NM)

# COMMAND ----------

# DBTITLE 1,Writing LDC/LDP data in Struct Zone
def write():
  NFZ_RPT_OUT_TMP_APPEND_DF1.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').partitionBy("YEAR","MONTH").save(struct_zone)

# COMMAND ----------

# DBTITLE 1,Save LDC/LDP records into Struct zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC/LDP records has been successfully written in Struct zone"
  
  
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STRUCT")
  

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent LDC/LDP records has been skipped without saving due to rerun of same file in Struct zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC/LDP records in Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

# this intermittent step is added to make sure report should be generated proper as expected when reprocessing data or/and restart the program
def write():
  NFZ_RPT_OUT_TMP_APPEND_DF1.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').partitionBy("YEAR","MONTH").save(STG_Output_File_Report)

# COMMAND ----------

TARGET_NM = ""

# COMMAND ----------

# DBTITLE 1,Save LDC/LDP records into Intermittent area i.e. work-pii
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC/LDP records has been successfully written in Work zone"
  
  
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STG")
  

  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent LDC/LDP records has been skipped without saving due to rerun of same file in Work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC/LDP records in intermittent zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

#read intermediate data 
STG_REPORT_DATA = spark.read.format("delta").load(STG_Output_File_Report)

# COMMAND ----------

# YEAR = STG_REPORT_DATA.select("YEAR").collect()[0][0]
# MONTH = STG_REPORT_DATA.select("MONTH").collect()[0][0]
# print(YEAR)
# print(MONTH)

# COMMAND ----------

#deduplicating report data using SQL solution
STG_REPORT_DATA.createOrReplaceTempView("crp52_report_table")
REPORT_DATA_NON_DUP_DF = spark.sql("select IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,CAST(REC_NUM as INT),CAST(YEAR as INT),CAST(MONTH as INT),max(LOAD_TIME) as LOAD_TIME,max(SOURCE_FILENAME) as SOURCE_FILENAME from crp52_report_table GROUP BY IBAS,ISEQ,IMSG,IMON,ILIN,CONVERTED_IDATE,REC_NUM,YEAR,MONTH order by REC_NUM")

# COMMAND ----------

def write():
  REPORT_DATA_NON_DUP_DF.orderBy(REPORT_DATA_NON_DUP_DF.ISEQ,REPORT_DATA_NON_DUP_DF.IMSG,REPORT_DATA_NON_DUP_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('overwrite').partitionBy("YEAR","MONTH").option("mergeSchema", "true").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}' ".format(YEAR,MONTH)).save(Output_File_Report)

# COMMAND ----------

# defining Target_name table based on src file name
if('LDC' in SRC_FILE_NM):
  TARGET_NM = "crpay_prep.ldc_report"
else:
  TARGET_NM = "crpay_prep.ldp_report"

# COMMAND ----------

# DBTITLE 1,Save LDC/LDP records into prep
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "LDC/LDP records has been successfully written in Prep zone"
  
  restart_logic(SRC_FILE_NM,Indicator_File_Path,"PREP")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "LDC/LDP records has been skipped without saving due to rerun of same file in Prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write LDC/LDP records in Prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

YEAR = str(YEAR)
MONTH = str(MONTH)
Prep_File = Output_File_Report + "YEAR=" + YEAR + '/' + "MONTH=" + MONTH  


# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing all LDP/LDC records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

dbutils.notebook.exit(Prep_File)

# COMMAND ----------


