-- Databricks notebook source
CREATE OR REPLACE VIEW crpay_prep.FLIGHT_ATTNDT_PRE_POST_MONTH_ACTVTY
   (
FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year' ,
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month' ,
EMP_NO COMMENT 'Employee Number' ,
PRE_MONTH_ACTVTY_TXT COMMENT 'Pre month Activity snapshot from fos' ,
POST_MONTH_ACTVTY_TXT COMMENT 'Post month Activity snapshot from fos' ,
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process' ,
CONTRCT_MONTH_START_DT COMMENT 'Contract Month start date' ,
CONTRCT_MONTH_END_DT COMMENT 'Contract Month end  date' ,
PRE_MONTH_ACTVTY_FILE_NM COMMENT 'Pre data file name' ,
POST_MONTH_ACTVTY_FILE_NM COMMENT 'post data file name' ,
LOAD_TMS COMMENT 'Orion Load timestamp' 
   ) 
   COMMENT 'the FA pre and post month activirty by contract month'
   AS 
   SELECT
YEAR AS FLIGHT_CREW_CONTRCT_YEAR ,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH ,
EMPLOYEE_NO AS EMP_NO ,
PRE_CREW_TKG_RPT_DATA AS PRE_MONTH_ACTVTY_TXT ,
POST_CREW_TKG_RPT_DATA AS POST_MONTH_ACTVTY_TXT ,
REC_NUMBER AS RECORD_SEQ_NBR ,
MONTH_START AS CONTRCT_MONTH_START_DT ,
MONTH_END AS CONTRCT_MONTH_END_DT ,
PRE_INPUT_FILENAME AS PRE_MONTH_ACTVTY_FILE_NM ,
POST_INPUT_FILENAME AS POST_MONTH_ACTVTY_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.crp030_ppc_ppd_report;

-- COMMAND ----------

CREATE OR REPLACE VIEW crpay_prep.PILOT_PRE_POST_MONTH_ACTVTY
   (
FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year' ,
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month' ,
EMP_NO COMMENT 'Employee Number' ,
PRE_MONTH_ACTVTY_TXT COMMENT 'Pre month Activity snapshot from fos' ,
POST_MONTH_ACTVTY_TXT COMMENT 'Post month Activity snapshot from fos' ,
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process' ,
CONTRCT_MONTH_START_DT COMMENT 'Contract Month start date' ,
CONTRCT_MONTH_END_DT COMMENT 'Contract Month end  date' ,
PRE_MONTH_ACTVTY_FILE_NM COMMENT 'Pre data file name' ,
POST_MONTH_ACTVTY_FILE_NM COMMENT 'post data file name' ,
LOAD_TMS COMMENT 'Orion Load timestamp' 
   ) 
   COMMENT 'This contains all the Pilot pre and post month activirty by contract month'
   AS 
   SELECT
YEAR AS FLIGHT_CREW_CONTRCT_YEAR ,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH ,
EMPLOYEE_NO AS EMP_NO ,
PRE_CREW_TKG_RPT_DATA AS PRE_MONTH_ACTVTY_TXT ,
POST_CREW_TKG_RPT_DATA AS POST_MONTH_ACTVTY_TXT ,
REC_NUMBER AS RECORD_SEQ_NBR ,
MONTH_START AS CONTRCT_MONTH_START_DT ,
MONTH_END AS CONTRCT_MONTH_END_DT ,
PRE_INPUT_FILENAME AS PRE_MONTH_ACTVTY_FILE_NM ,
POST_INPUT_FILENAME AS POST_MONTH_ACTVTY_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.crp030_ppa_ppb_report;
 

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prep.FLIGHT_ATTNDT_SEQ_DETL
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'FA sequence details by sequece'
   AS 
   SELECT
YEAR AS	FLIGHT_CREW_CONTRCT_YEAR,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH,
IBAS AS	FLIGHT_CREW_BASE_CD,
ISEQ AS	SEQ_NO,
IMSG AS	SEQ_START_DAY_MONTH,
IMON AS	FLIGHT_CREW_CONTRCT_MONTH_CD,
ILIN AS	SEQ_DETL_TXT,
CONVERTED_IDATE AS FOS_DRAIN_DT,
REC_NUM AS RECORD_SEQ_NBR,
SOURCE_FILENAME	AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS
 FROM crpay_prep.ldc_report;

-- COMMAND ----------

  CREATE OR REPLACE VIEW crpay_prep.FLIGHT_ATTNDT_PRE_POST_SEQ_DETL
 ( 
 FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT 'Flight crew contract month  Code',
EMP_NO COMMENT 'Employee number',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
PRE_MONTH_SEQ_TXT COMMENT 'Pre month sequence snapshot from fos',
POST_MONTH_SEQ_TXT COMMENT 'Post month sequence snapshot from fos',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'the FA pre and post month sequence information by contract month'
   AS 
   SELECT
YEAR AS FLIGHT_CREW_CONTRCT_YEAR ,
MONTH  AS FLIGHT_CREW_CONTRCT_MONTH_CD ,
EMP_NBR AS EMP_NO ,
SEQ_NUM AS SEQ_NO ,
DATE_MONTH AS SEQ_START_DAY_MONTH ,
BASE AS FLIGHT_CREW_BASE_CD ,
ABSOLUTE_BASE_DATA AS PRE_MONTH_SEQ_TXT ,
ACTUAL_BASE_DATA AS POST_MONTH_SEQ_TXT ,
REC_NUM AS RECORD_SEQ_NBR ,
SOURCE_FILENAME AS SRC_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDA_REPORT;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prep.FLIGHT_ATTNDT_SEQ_DETL_EMP
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
EMP_NO COMMENT 'Employee number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'FA sequence details by individual employee sequence'
   AS 
   SELECT
YEAR AS FLIGHT_CREW_CONTRCT_YEAR ,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH ,
EMP_NBR AS EMP_NO ,
IBAS AS FLIGHT_CREW_BASE_CD ,
ISEQ AS SEQ_NO ,
IMSG AS SEQ_START_DAY_MONTH ,
IMON AS FLIGHT_CREW_CONTRCT_MONTH_CD ,
ILIN AS SEQ_DETL_TXT ,
CONVERTED_IDATE AS FOS_DRAIN_DT ,
REVISED_REC_NUM AS RECORD_SEQ_NBR ,
INPUT_FILE_NAME AS SRC_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDC_FA_WEB_REPORT;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prep.PILOT_SEQ_DETL
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'Pilot sequence details by sequece'
   AS 
   SELECT
YEAR AS	FLIGHT_CREW_CONTRCT_YEAR,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH,
IBAS AS	FLIGHT_CREW_BASE_CD,
ISEQ AS	SEQ_NO,
IMSG AS	SEQ_START_DAY_MONTH,
IMON AS	FLIGHT_CREW_CONTRCT_MONTH_CD,
ILIN AS	SEQ_DETL_TXT,
CONVERTED_IDATE AS FOS_DRAIN_DT,
REC_NUM AS RECORD_SEQ_NBR,
SOURCE_FILENAME	AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS
 FROM crpay_prep.ldp_report;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prep.PILOT_SEQ_DETL_EMP
( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
EMP_NO COMMENT 'Employee number',
PILOT_SEAT_POSITION_CD COMMENT 'Pilot seat position code',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence ',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code ',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date ',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'Pilot sequence details by individual employee sequence'
   AS 
   SELECT
YEAR AS FLIGHT_CREW_CONTRCT_YEAR,
MONTH AS FLIGHT_CREW_CONTRCT_MONTH,
EMP_NBR AS EMP_NO,
PILOT_SEAT_POSITION_CD AS PILOT_SEAT_POSITION_CD,
IBAS AS FLIGHT_CREW_BASE_CD,
ISEQ AS SEQ_NO,
IMSG AS SEQ_START_DAY_MONTH,
IMON AS FLIGHT_CREW_CONTRCT_MONTH_CD,
ILIN AS SEQ_DETL_TXT,
CONVERTED_IDATE AS FOS_DRAIN_DT,
REVISED_REC_NUM AS RECORD_SEQ_NBR,
INPUT_FILE_NAME AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDP_PILOT_WEB_REPORT;

-- COMMAND ----------

