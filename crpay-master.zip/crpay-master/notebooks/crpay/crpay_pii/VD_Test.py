# Databricks notebook source
import pandas as pd
from pandas import read_csv
import csv
from pyspark.sql import SparkSession



# COMMAND ----------

dbutils.widgets.text("TableName", "")
TableName = dbutils.widgets.get("TableName")

dbutils.widgets.text("PrepTableName", "")
PrepTableName = dbutils.widgets.get("PrepTableName")

dbutils.widgets.text("VDTableName", "")
VDTableName = dbutils.widgets.get("VDTableName")

dbutils.widgets.text("YEAR", "")
YEAR = dbutils.widgets.get("YEAR")

dbutils.widgets.text("Month", "")
Month = dbutils.widgets.get("Month")


dbutils.widgets.text("file_location", "")
file_location = dbutils.widgets.get("file_location")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("ProcessJson", "")
ProcessJson = dbutils.widgets.get("ProcessJson")


dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Crewpay_Run", " ")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

# COMMAND ----------

receiver_emails = receiver_emails.split()

# COMMAND ----------

from pyspark.sql.functions import regexp_replace, col

VD_JSON_DATA = spark.sql("""
  select SUBSTRING(DATA, 0, 135) as DATA,REC_NUMBER from {0}""".format(VDTableName))

VD_JSON_DATA = VD_JSON_DATA.select(regexp_replace(col("DATA"), " ", "").alias('VD_JSON_DATA'),"REC_NUMBER")

#display(VD_JSON_DATA)
VD_JSON_DATA.createOrReplaceTempView("VD_JSON_DATA")
#VD_JSON_DATA.count()

# COMMAND ----------

VD_PREP_DATA = spark.sql("""
   SELECT concat(PRE_CREW_TKG_RPT_DATA,' ',POST_CREW_TKG_RPT_DATA) AS DATA, REC_NUMBER from {0} WHERE YEAR = {1} AND MONTH = {2} ORDER BY REC_NUMBER """.format(PrepTableName,YEAR,Month))


VD_PREP_DATA = VD_PREP_DATA.select(regexp_replace(col("DATA")," ", "").alias('VD_PREP_DATA'),"REC_NUMBER")

VD_PREP_DATA.createOrReplaceTempView("VD_PREP_DATA")
#display(VD_PREP_DATA)
#VD_PREP_DATA.count()

# COMMAND ----------

DIFF = spark.sql("""

select * from (
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  except
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
   
  ) """
)

DIFF.createOrReplaceTempView("DIFF")
DIFF_data = spark.sql("select count(*) as count  from DIFF where (trim(VD_JSON_DATA)!='1' and (trim(VD_JSON_DATA) !='') and (trim(VD_JSON_DATA) not like 'PP%')) ")


# COMMAND ----------

DIFF_data = DIFF_data.select("count").collect()[0][0]

DIFF_data_COUNT = int(DIFF_data)


# COMMAND ----------

if ( DIFF_data_COUNT == 0):
    spark.sql("""
DELETE FROM {0} a
 WHERE NOT EXISTS(SELECT REC_NUMBER
                    FROM (select REC_NUMBER from {1} WHERE YEAR = {2} AND MONTH = {3})AS f
                   WHERE f.REC_NUMBER = a.REC_NUMBER)""".format(VDTableName,PrepTableName,YEAR,Month))
else:
    print("notmatching")





# COMMAND ----------

VD_JSON_PREP_DIFF = spark.sql("""

select count(*) AS count from (
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  except
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
   
  ) """
)
#display(VD_JSON_PREP_DIFF)

# COMMAND ----------

VD_PREP_JSON_DIFF = spark.sql("""

select count(*) AS count from (
  
  
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
  except
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
   
  ) """
)
#display(VD_PREP_JSON_DIFF)

# COMMAND ----------

VD_PREP = VD_JSON_PREP_DIFF.select("count").collect()[0][0]
PREP_VD = VD_PREP_JSON_DIFF.select("count").collect()[0][0]
VD_PREP_COUNT = int(VD_PREP)
PREP_VD_COUNT = int(PREP_VD)
#print(VD_PREP_COUNT)

# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

if (( VD_PREP_COUNT == 0) and ( PREP_VD_COUNT == 0)):
    print ("Matching")
    send_email(sender_email , receiver_emails , 'matching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}'.format(PrepTableName,ProcessJson,YEAR,Month) , bcc=None, attachments = None)
else:
    VD_JSON_PREP_DIFF_DATA = spark.sql("""

select REC_NUMBER AS VD_JSON_DATA_REC_NUMBER,VD_JSON_DATA from (
    SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
  except
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
   
  ) """
)

    VD_PREP_JSON_DIFF_DATA = spark.sql("""

select REC_NUMBER AS VD_PREP_DATA_REC_NUMBER,VD_PREP_DATA from (
  
  
  SELECT sha2(VD_PREP_DATA, 256) AS checksum ,VD_PREP_DATA,REC_NUMBER from VD_PREP_DATA
  except
  SELECT sha2(VD_JSON_DATA, 256) AS checksum ,VD_JSON_DATA,REC_NUMBER from VD_JSON_DATA
   
  ) """
)
    join_data = VD_JSON_PREP_DIFF_DATA.join(VD_PREP_JSON_DIFF_DATA, VD_JSON_PREP_DIFF_DATA.VD_JSON_DATA_REC_NUMBER == VD_PREP_JSON_DIFF_DATA.VD_PREP_DATA_REC_NUMBER) 
    
    mismatch_records =  file_location + 'PREP_DIFF_' + Crewpay_Run + '/'+ YEAR + '/' + Month + '/'
    #print(mismatch_records)
    join_data.repartition(1).write.format("csv").option("inferSchema","true").option("header","true").mode("overwrite").save(mismatch_records)
    count = join_data.count()

    count = str(count)
    send_email(sender_email , receiver_emails , 'mismatching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}\r\r\nJsonFile_Name: {4}'.format(PrepTableName,ProcessJson,YEAR,Month,mismatch_records) , bcc=None, attachments = None)

# COMMAND ----------

