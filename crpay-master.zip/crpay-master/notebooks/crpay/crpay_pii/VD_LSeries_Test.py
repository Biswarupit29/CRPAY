# Databricks notebook source
import pandas as pd
from pandas import read_csv
import csv
from pyspark.sql import SparkSession

# COMMAND ----------

dbutils.widgets.text("YEAR", "")
YEAR = dbutils.widgets.get("YEAR")

dbutils.widgets.text("Month", "")
Month = dbutils.widgets.get("Month")

dbutils.widgets.text("file_location", "")
file_location = dbutils.widgets.get("file_location")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("ProcessJson", "")
ProcessJson = dbutils.widgets.get("ProcessJson")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Crewpay_Run", " ")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

# COMMAND ----------

VDTableName = "crpay_prep."+Crewpay_Run.lower()+"_report_vd"
TableName = "crpay_prep."+Crewpay_Run.lower()+"_report_vd"
PrepTableName = "crpay_prep."+Crewpay_Run.lower()+"_report"

print(VDTableName)
print(TableName)
print(PrepTableName)

# COMMAND ----------

receiver_emails = receiver_emails.split()

# COMMAND ----------

# spark.sql("""select trim(replace(ILIN,"*","")) as ILIN, length(trim(replace(ILIN,"*",""))) as len from crpay_prep.ldp_Report where YEAR={0} and MONTH={1} and ILIN not like '%******%'""".format(YEAR,Month)).display()

# COMMAND ----------

DIFF = spark.sql("""select * from (
select * from (
select a.ILIN as ILIN_a, a.len as len_a, b.ILIN as ILIN_b, b.len as len_b from 
(select trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) as ILIN, length(trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*",""))) as len from {2} where Data not like '%******%' and Data not like '%REPORT%' and Data not like '%CONTINUED%' and trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) <> "1" and trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) <> "") a
full outer join 
(select trim(replace(ILIN,"*","")) as ILIN, length(trim(replace(ILIN,"*",""))) as len from {3} where YEAR={0} and MONTH={1} and ILIN not like '%******%') b
on trim(a.ILIN) = trim(b.ILIN)) t where (ILIN_a is null or ILIN_b is null))""".format(YEAR,Month,VDTableName,PrepTableName))

DIFF_count = DIFF.count()

print("Mismatched Difference count = "+str(DIFF_count))

# COMMAND ----------

DIFF.display()

# COMMAND ----------

# %sql

# select * from (
# select * from (
# select a.ILIN as ILIN_a, a.len as len_a, b.ILIN as ILIN_b, b.len as len_b from 
# (select trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) as ILIN, length(trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*",""))) as len from crpay_prep.ldp_report_vd where Data not like '%******%' and Data not like '%REPORT%' and Data not like '%CONTINUED%' and trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) <> "1" and trim(replace(regexp_replace(regexp_replace(data,'\r',''),'\n',''),"*","")) <> "") a
# full outer join 
# (select trim(replace(ILIN,"*","")) as ILIN, length(trim(replace(ILIN,"*",""))) as len from crpay_prep.ldp_Report where YEAR=2021 and MONTH=2 and ILIN not like '%******%') b
# on trim(a.ILIN) = trim(b.ILIN)) t where (ILIN_a is null or ILIN_b is null))
# -- where 
# -- ILIN_b not like 'CAPT%' or 
# -- ILIN_b is null

# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

if (DIFF_count == 0):
    print ("Matching")
    send_email(sender_email , receiver_emails , 'Matching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}'.format(PrepTableName,ProcessJson,YEAR,Month) , bcc=None, attachments = None)
else:
    mismatch_records =  file_location + '/PREP_DIFF_' + Crewpay_Run + '/' + YEAR + '/' + Month
    #print(mismatch_records)
    DIFF.repartition(1).write.format("csv").option("inferSchema","true").option("header","true").mode("overwrite").save(mismatch_records)
    send_email(sender_email , receiver_emails , 'Mismatching Records in bin file: ' + Crewpay_Run , '\r\r\nPrepTableName: {0}\r\r\nYEAR: {2}\r\r\nMONTH: {3}\r\r\nJsonFile_Name: {1}'.format(PrepTableName,ProcessJson,YEAR,Month) , bcc=None, attachments = None)

# COMMAND ----------

mismatch_records =  file_location + '/PREP_DIFF_' + Crewpay_Run + '/' + YEAR + '/' + Month
print(mismatch_records)