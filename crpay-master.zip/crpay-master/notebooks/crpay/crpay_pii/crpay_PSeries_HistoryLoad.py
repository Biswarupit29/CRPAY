# Databricks notebook source
# DBTITLE 1,VD History Files for P series from raw_to_prep
"Version History of VD History Files for P series from raw to prep"

"Changes:"

"Developer: Nitin"
"Date Created: 02/18/2021"
"Date Updated : 03/09/2021"
"Purpose: Read VD History Files for P series from Raw zone and Load into prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Rejected_Records_path", "")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("vd_output", "")
vd_output = dbutils.widgets.get("vd_output")

dbutils.widgets.text("Prep_Year", "")
Prep_Year = dbutils.widgets.get("Prep_Year")

dbutils.widgets.text("Prep_Month", "")
Prep_Month = dbutils.widgets.get("Prep_Month")

#abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-prep-pii/Reports/HIST_PPAB_TEST/


# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
receiver_emails = receiver_emails.split()

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# log report function param's 
import datetime

SYS_NM = "crpay"
#SRC_FILE_NM = "VD_HISTORY_FILES"
SRC_FILE_NM = Input_File
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"


# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time
# The log will be written in the success folder 

SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Read VD P series History Records from Raw Zone
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
try:
  #cp_pii_df = spark.read.text(Input_File)
  cp_pii_df= spark.read.format("json").load(Input_File)
  cp_pii_df = cp_pii_df.withColumn("sourcefile",input_file_name())
  regex_str = "[\/]([^\/]+)$"
  cp_pii_df = cp_pii_df.withColumn("PRE_INPUT_FILE_NAME", regexp_extract("sourcefile",regex_str,1)).withColumn("POST_INPUT_FILE_NAME",      regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))
  SRC_FILE_NM = cp_pii_df.select("PRE_INPUT_FILE_NAME").distinct().collect()[0][0]
  MSG_DESC = "VD P series History data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read VD P series History data from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

VD =  cp_pii_df.select("Data","REC_NUMBER")
VD.repartition(1).write.format("delta").mode("overwrite").save(vd_output)

# COMMAND ----------

# DBTITLE 1,Data Processing for VD P series History data for PPAB/PPCD
## processing of History data  

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

# defined Schema for history report as it should looks like the same as p series report
try:
  DataSchema = StructType([StructField("CC_1", StringType()),StructField("PRE_CREW_TKG_RPT_DATA", StringType()), StructField("POST_CREW_TKG_RPT_DATA", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType()),StructField("REC_NUMBER", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])


  def fs(str,len,val):
    return str.rjust(len,val)[:len]

  CREW_TKG_RPT_DATA_FINAL_LIST=[]
  REC_NUM = 0 
  
  for row in cp_pii_df.rdd.collect(): 
      value = row.Data.rstrip(' ')
      
      PRE_INPUT_FILE_NAME = row.PRE_INPUT_FILE_NAME
      POST_INPUT_FILE_NAME = row.POST_INPUT_FILE_NAME 
      LOAD_TIME = row.LOADTIME
      CC_1 = ''
      MONTH = Prep_Month
      YEAR = Prep_Year


      if('MONTH STARTING' in value):
          REC_NUM = REC_NUM +1 
          PRE_CREW_TKG_RPT_DATA = str(value)[0:65]
          POST_CREW_TKG_RPT_DATA = str(value)[66:134]
          EMP_NBR = str(PRE_CREW_TKG_RPT_DATA)[21:29]
          MONTH_START = str(POST_CREW_TKG_RPT_DATA)[15:23]
          MONTH_END = str(POST_CREW_TKG_RPT_DATA)[34:42]
          #YEAR = str(20) + str(MONTH_START)[6:8]
         # MONTH_NAME = str(MONTH_START)[3:6]
          #datetime_object = datetime.datetime.strptime(MONTH_NAME, "%b")
          #YEAR = Prep_Year
         # MONTH = Prep_Month
          
         # MONTH = datetime_object.month
          pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
          pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
          CREW_TKG_RPT_DATA_TMP1 = "{0},{1}{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(CC_1,PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,EMP_NBR,MONTH_START,MONTH_END,REC_NUM,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILE_NAME,POST_INPUT_FILE_NAME)
          CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP1.split(','))

      elif((value.strip(' ')=='1') or (value.strip(' ')=='')):
           NO_FILE = 'NA'
      else:
          REC_NUM = REC_NUM+1
          PRE_CREW_TKG_RPT_DATA = str(value)[0:64]
          POST_CREW_TKG_RPT_DATA = str(value)[64:134]
          pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
          pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
          CREW_TKG_RPT_DATA_TMP2 = "{0}|{1}{2}|{3}{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}|{12}|{13}".format(CC_1,PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,EMP_NBR,MONTH_START,MONTH_END,REC_NUM,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILE_NAME,POST_INPUT_FILE_NAME)
          CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split('|'))

  MSG_DESC = "VD P series History Files are sucessfully processed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process VD P series History Files. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e  
       

# COMMAND ----------

HIST_RPT_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST, schema=DataSchema)

# COMMAND ----------

HIST_RPT_DF.createOrReplaceTempView("P_VD")


# COMMAND ----------

HIST_RPT_DF1 = spark.sql("select * from P_VD where trim(PRE_CREW_TKG_RPT_DATA)!='1' or (trim(PRE_CREW_TKG_RPT_DATA) !='' and trim(POST_CREW_TKG_RPT_DATA)!='')")


# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number
from pyspark.sql.functions import rank, col , regexp_replace, dense_rank

#SKD_DF_T_SEQ_SORTED = HIST_RPT_DF1.withColumn("id", F.rank().over(Window.partitionBy("PRE_CREW_TKG_RPT_DATA").orderBy("REC_NUMBER")))
from pyspark.sql.functions import trim


df = HIST_RPT_DF1.withColumn("post", regexp_replace(col("PRE_CREW_TKG_RPT_DATA"), " ",""))

window2 = Window.partitionBy(df['post']).orderBy(df['EMPLOYEE_NO'])
df = df.select('*', row_number().over(window2).alias('rank'))

#display(a)

# COMMAND ----------

spark.conf.set("spark.sql.execution.arrow.enabled", "true")

pd_df_post_1 = df.toPandas()

#convert_dict = {'REC_NUMBER': int }
#pd_df_post_1 = pd_df.astype(convert_dict)


#data_top = pd_df_post.head(1010)
#data_top_1 = pd_df_post_1.loc[pd_df_post_1['REC_NUMBER'] <=348]

#pd_df_post_1.count()

# COMMAND ----------


index_names = pd_df_post_1[ (pd_df_post_1['POST_CREW_TKG_RPT_DATA'].str.contains("MONTH STARTING")) & (pd_df_post_1['rank'] >= 2) ].index
pd_df_post_1.drop(index_names, inplace = True)
#pd_df_post_1.count()

# COMMAND ----------

sparkDF=spark.createDataFrame(pd_df_post_1) 
sparkDF.createOrReplaceTempView("data_top_1")


# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import lag, lead, first, last

Appendcol = sparkDF.withColumn('value', lag('POST_CREW_TKG_RPT_DATA').over(
    Window.partitionBy('EMPLOYEE_NO').orderBy('REC_NUMBER')
    )
)

Appendcol = Appendcol.withColumn('value_pre', lag('PRE_CREW_TKG_RPT_DATA').over(
    Window.partitionBy('EMPLOYEE_NO').orderBy('REC_NUMBER')
    )
)

Appendcol = Appendcol.withColumn("trimvalue", regexp_replace(col("value"), " ",""))
Appendcol = Appendcol.withColumn("trimdata", regexp_replace(col("PRE_CREW_TKG_RPT_DATA"), " ",""))
Appendcol = Appendcol.withColumn("z", regexp_replace(col("value_pre"), " ",""))
Appendcol = Appendcol.withColumn("x", regexp_replace(col("POST_CREW_TKG_RPT_DATA"), " ",""))

#display(z)


# COMMAND ----------

pd_df_final = Appendcol.toPandas()


#pd_df_final.count()

# COMMAND ----------

index_names_post_final = pd_df_final[ (pd_df_final['trimvalue'] == 'ENDOFCOMMENTS') & (pd_df_final['trimdata'] == '') & (pd_df_final['x'] == '')].index
pd_df_final.drop(index_names_post_final, inplace = True)
#pd_df_final.count()



# COMMAND ----------

sparkDF_POST=spark.createDataFrame(pd_df_final) 
sparkDF_POST.createOrReplaceTempView("sparkDF_POST")
#display(sparkDF_POST)


# COMMAND ----------

#Load Report and Data files in Staging area first before loading into actual prep zone , so that duplicate data can be removed in advance


sparkDF_POST.write.format("delta").mode("append").partitionBy("YEAR","MONTH").save(STG_Output_File_Report)

# COMMAND ----------

# DBTITLE 1,Save VD History P series data into Intermittent area i.e. work-pii
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.

result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "VD History P series records has been successfully written in Work zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"HIST_STG")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent VD History P series records has been skipped without saving due to rerun of same file in Work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write VD History P series records in intermittent zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  #log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  #raise e



# COMMAND ----------

#Reading intermediate report data for removing duplicate data
HIST_RPT_DF_STG = spark.read.format("delta").load(STG_Output_File_Report)

# COMMAND ----------

#deduplicating pre and post data using SQL 
HIST_RPT_DF_STG.createOrReplaceTempView("HIST_TABLE")
HIST_RPT = spark.sql("select CC_1,PRE_CREW_TKG_RPT_DATA,POST_CREW_TKG_RPT_DATA,EMPLOYEE_NO,MONTH_START,MONTH_END,CAST(REC_NUMBER as INT),LOAD_TIME,CAST(YEAR as INT),CAST(MONTH as INT),PRE_INPUT_FILENAME,POST_INPUT_FILENAME from HIST_TABLE ORDER BY REC_NUMBER")

# COMMAND ----------

if('ACRPPP4G' in SRC_FILE_NM):
  TARGET_NM = "crpay_prep.crp030_ppa_ppb_report"
else:
  TARGET_NM = "crpay_prep.crp030_ppc_ppd_report"


# COMMAND ----------

YEAR = HIST_RPT.select("YEAR").collect()[0][0]
MONTH = HIST_RPT.select("MONTH").collect()[0][0]



# COMMAND ----------

#History Report are made available in delta format 
def write():
  
    HIST_RPT.write.format("delta").mode("overwrite").partitionBy("YEAR","MONTH").option("replaceWhere","YEAR = '{0}' AND MONTH ='{1}'".format(YEAR,MONTH)).save(Output_File_Report)
  


# COMMAND ----------


# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "VD History P series records has been successfully written in prep zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"HIST_PREP")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    
    STATUS_CD = "SK"
    MSG_DESC = "VD History P series records has been skipped without saving due to rerun of same file in prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write VD History P series records in prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e



# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing VD History P series records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

