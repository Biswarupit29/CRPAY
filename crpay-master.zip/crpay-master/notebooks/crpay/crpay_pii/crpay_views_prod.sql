-- Databricks notebook source
create database if not exists crpay_prod_prep_pii;

-- COMMAND ----------

CREATE OR REPLACE VIEW crpay_prod_prep_pii.FLIGHT_ATTNDT_PRE_POST_MONTH_ACTVTY
   (
FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year' ,
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month' ,
EMP_NO COMMENT 'Employee Number' ,
PRE_MONTH_ACTVTY_TXT COMMENT 'Pre month Activity snapshot from fos' ,
POST_MONTH_ACTVTY_TXT COMMENT 'Post month Activity snapshot from fos' ,
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process' ,
CONTRCT_MONTH_START_DT COMMENT 'Contract Month start date' ,
CONTRCT_MONTH_END_DT COMMENT 'Contract Month end  date' ,
PRE_MONTH_ACTVTY_FILE_NM COMMENT 'Pre data file name' ,
POST_MONTH_ACTVTY_FILE_NM COMMENT 'post data file name' ,
LOAD_TMS COMMENT 'Orion Load timestamp' 
   ) 
   COMMENT 'the FA pre and post month activirty by contract month'
   AS 
   SELECT
trim(YEAR) AS FLIGHT_CREW_CONTRCT_YEAR ,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH ,
trim(EMPLOYEE_NO) AS EMP_NO ,
rtrim(PRE_CREW_TKG_RPT_DATA) AS PRE_MONTH_ACTVTY_TXT ,
rtrim(POST_CREW_TKG_RPT_DATA) AS POST_MONTH_ACTVTY_TXT ,
trim(REC_NUMBER) AS RECORD_SEQ_NBR ,
trim(MONTH_START) AS CONTRCT_MONTH_START_DT ,
trim(MONTH_END) AS CONTRCT_MONTH_END_DT ,
trim(PRE_INPUT_FILENAME) AS PRE_MONTH_ACTVTY_FILE_NM ,
trim(POST_INPUT_FILENAME) AS POST_MONTH_ACTVTY_FILE_NM ,
LOAD_TIME AS LOAD_TMS  
 FROM crpay_prep.crp030_ppc_ppd_report;

-- COMMAND ----------

CREATE OR REPLACE VIEW crpay_prod_prep_pii.PILOT_PRE_POST_MONTH_ACTVTY
   (
FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year' ,
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month' ,
EMP_NO COMMENT 'Employee Number' ,
PRE_MONTH_ACTVTY_TXT COMMENT 'Pre month Activity snapshot from fos' ,
POST_MONTH_ACTVTY_TXT COMMENT 'Post month Activity snapshot from fos' ,
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process' ,
CONTRCT_MONTH_START_DT COMMENT 'Contract Month start date' ,
CONTRCT_MONTH_END_DT COMMENT 'Contract Month end  date' ,
PRE_MONTH_ACTVTY_FILE_NM COMMENT 'Pre data file name' ,
POST_MONTH_ACTVTY_FILE_NM COMMENT 'post data file name' ,
LOAD_TMS COMMENT 'Orion Load timestamp' 
   ) 
   COMMENT 'This contains all the Pilot pre and post month activirty by contract month'
   AS 
   SELECT
trim(YEAR) AS FLIGHT_CREW_CONTRCT_YEAR ,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH ,
trim(EMPLOYEE_NO) AS EMP_NO ,
rtrim(PRE_CREW_TKG_RPT_DATA) AS PRE_MONTH_ACTVTY_TXT ,
rtrim(POST_CREW_TKG_RPT_DATA) AS POST_MONTH_ACTVTY_TXT ,
trim(REC_NUMBER) AS RECORD_SEQ_NBR ,
trim(MONTH_START) AS CONTRCT_MONTH_START_DT ,
trim(MONTH_END) AS CONTRCT_MONTH_END_DT ,
trim(PRE_INPUT_FILENAME) AS PRE_MONTH_ACTVTY_FILE_NM ,
trim(POST_INPUT_FILENAME) AS POST_MONTH_ACTVTY_FILE_NM ,
LOAD_TIME AS LOAD_TMS  
 FROM crpay_prep.crp030_ppa_ppb_report;
 

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prod_prep_pii.FLIGHT_ATTNDT_SEQ_DETL
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'FA sequence details by sequece'
   AS 
   SELECT
trim(YEAR) AS	FLIGHT_CREW_CONTRCT_YEAR,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH,
trim(IBAS) AS	FLIGHT_CREW_BASE_CD,
trim(ISEQ) AS	SEQ_NO,
trim(IMSG) AS	SEQ_START_DAY_MONTH,
trim(IMON) AS	FLIGHT_CREW_CONTRCT_MONTH_CD,
rtrim(ILIN) AS	SEQ_DETL_TXT,
trim(CONVERTED_IDATE) AS FOS_DRAIN_DT,
trim(REC_NUM) AS RECORD_SEQ_NBR,
trim(SOURCE_FILENAME)	AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS
 FROM crpay_prep.ldc_report;

-- COMMAND ----------

  CREATE OR REPLACE VIEW crpay_prod_prep_pii.FLIGHT_ATTNDT_PRE_POST_SEQ_DETL
 ( 
 FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT 'Flight crew contract month  Code',
EMP_NO COMMENT 'Employee number',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
PRE_MONTH_SEQ_TXT COMMENT 'Pre month sequence snapshot from fos',
POST_MONTH_SEQ_TXT COMMENT 'Post month sequence snapshot from fos',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'the FA pre and post month sequence information by contract month'
   AS 
   SELECT
trim(YEAR) AS FLIGHT_CREW_CONTRCT_YEAR ,
trim(MONTH)  AS FLIGHT_CREW_CONTRCT_MONTH_CD ,
trim(EMP_NBR) AS EMP_NO ,
trim(SEQ_NUM) AS SEQ_NO ,
trim(DATE_MONTH) AS SEQ_START_DAY_MONTH ,
trim(BASE) AS FLIGHT_CREW_BASE_CD ,
rtrim(ABSOLUTE_BASE_DATA) AS PRE_MONTH_SEQ_TXT ,
rtrim(ACTUAL_BASE_DATA) AS POST_MONTH_SEQ_TXT ,
trim(REC_NUM) AS RECORD_SEQ_NBR ,
trim(SOURCE_FILENAME) AS SRC_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDA_REPORT;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prod_prep_pii.FLIGHT_ATTNDT_SEQ_DETL_EMP
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
EMP_NO COMMENT 'Employee number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'FA sequence details by individual employee sequence'
   AS 
   SELECT
trim(YEAR) AS FLIGHT_CREW_CONTRCT_YEAR ,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH ,
trim(EMP_NBR) AS EMP_NO ,
trim(IBAS) AS FLIGHT_CREW_BASE_CD ,
trim(ISEQ) AS SEQ_NO ,
trim(IMSG) AS SEQ_START_DAY_MONTH ,
trim(IMON) AS FLIGHT_CREW_CONTRCT_MONTH_CD ,
rtrim(ILIN) AS SEQ_DETL_TXT ,
trim(CONVERTED_IDATE) AS FOS_DRAIN_DT ,
trim(REVISED_REC_NUM) AS RECORD_SEQ_NBR ,
trim(INPUT_FILE_NAME) AS SRC_FILE_NM ,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDC_FA_WEB_REPORT;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prod_prep_pii.PILOT_SEQ_DETL
 ( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'Pilot sequence details by sequece'
   AS 
   SELECT
trim(YEAR) AS	FLIGHT_CREW_CONTRCT_YEAR,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH,
trim(IBAS) AS	FLIGHT_CREW_BASE_CD,
trim(ISEQ) AS	SEQ_NO,
trim(IMSG) AS	SEQ_START_DAY_MONTH,
trim(IMON) AS	FLIGHT_CREW_CONTRCT_MONTH_CD,
rtrim(ILIN) AS	SEQ_DETL_TXT,
trim(CONVERTED_IDATE) AS FOS_DRAIN_DT,
trim(REC_NUM) AS RECORD_SEQ_NBR,
trim(SOURCE_FILENAME)	AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS
 FROM crpay_prep.ldp_report;

-- COMMAND ----------

 CREATE OR REPLACE VIEW crpay_prod_prep_pii.PILOT_SEQ_DETL_EMP
( FLIGHT_CREW_CONTRCT_YEAR COMMENT 'Flight crew contract Year',
FLIGHT_CREW_CONTRCT_MONTH COMMENT 'Flight crew contract month  number',
EMP_NO COMMENT 'Employee number',
PILOT_SEAT_POSITION_CD COMMENT 'Pilot seat position code',
FLIGHT_CREW_BASE_CD COMMENT 'Three letter Flight Crew Base Code',
SEQ_NO COMMENT 'Number that identifies the Crew Sequence ',
SEQ_START_DAY_MONTH COMMENT 'Sequence start day and Month',
FLIGHT_CREW_CONTRCT_MONTH_CD COMMENT '3 letter contract month code ',
SEQ_DETL_TXT COMMENT 'Sequence detailed text for an employee',
FOS_DRAIN_DT COMMENT 'FOS drain Extract Date ',
RECORD_SEQ_NBR COMMENT 'generated record sequence number with in Orion process',
SRC_FILE_NM COMMENT 'source fiule name',
LOAD_TMS COMMENT 'Orion Load timestamp'
)
COMMENT 'Pilot sequence details by individual employee sequence'
   AS 
   SELECT
trim(YEAR) AS FLIGHT_CREW_CONTRCT_YEAR,
trim(MONTH) AS FLIGHT_CREW_CONTRCT_MONTH,
trim(EMP_NBR) AS EMP_NO,
trim(PILOT_SEAT_POSITION_CD) AS PILOT_SEAT_POSITION_CD,
trim(IBAS) AS FLIGHT_CREW_BASE_CD,
trim(ISEQ) AS SEQ_NO,
trim(IMSG) AS SEQ_START_DAY_MONTH,
trim(IMON) AS FLIGHT_CREW_CONTRCT_MONTH_CD,
rtrim(ILIN) AS SEQ_DETL_TXT,
trim(CONVERTED_IDATE) AS FOS_DRAIN_DT,
trim(REVISED_REC_NUM) AS RECORD_SEQ_NBR,
trim(INPUT_FILE_NAME) AS SRC_FILE_NM,
LOAD_TIME AS LOAD_TMS 
 FROM crpay_prep.LDP_PILOT_WEB_REPORT;