# Databricks notebook source
dbutils.widgets.text("oaoom_delta_path", "")
oaoom_delta_path = dbutils.widgets.get("oaoom_delta_path")

dbutils.widgets.text("optimus_path", "")
optimus_path = dbutils.widgets.get("optimus_path")

dbutils.widgets.text("oaoomlog_strctpath", "")
oaoomlog_strctpath = dbutils.widgets.get("oaoomlog_strctpath")

dbutils.widgets.text("oaoomlog_preppath", "")
oaoomlog_preppath = dbutils.widgets.get("oaoomlog_preppath")

dbutils.widgets.text("optimuslog_preppath", "")
optimuslog_preppath = dbutils.widgets.get("optimuslog_preppath")

dbutils.widgets.text("pbidsb_path", "")
pbidsb_path = dbutils.widgets.get("pbidsb_path")

# COMMAND ----------

print("'oaoom_delta_path' :", "'"+ oaoom_delta_path+"',")
print("'oaoomlog_preppath' :", "'"+ oaoomlog_preppath+"',")
print("'oaoomlog_strctpath' :", "'"+ oaoomlog_strctpath+"',")
print("'optimus_path' :", "'"+ optimus_path+"',")
print("'optimuslog_preppath' :", "'"+ optimuslog_preppath+"',")

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
import pytz
from datetime import timedelta
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", "true")
spark.conf.set("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", "true")

# COMMAND ----------

# DBTITLE 1,Get Year Month 
now = datetime.now(pytz.timezone('US/Central'))
date_n=str(now.strftime("%Y%m%d"))
# date_n= "20250109"
Today = datetime.strptime(date_n, "%Y%m%d").date()
current_month = Today.month
current_year = int(str(Today.year)[2:])
previous_month = (current_month - 1) if current_month > 1 else 12
previous_year = current_year - 1 if previous_month == 12 else current_year
# max_log_dt_str = str(spark.sql(f"""select max(log_dt) as max_log_dt from crpay_prep.oaoomlog_np""").collect()[0][0])

# print("Loading logs for and after :", max_log_dt_str)
print("Today :", date_n)
print("Current Month :", current_month)
print("Current Year :", current_year)
print("Previous Month :", previous_month)
print("Previous Year :", previous_year)

# COMMAND ----------

# DBTITLE 1,Get Max log dt

max_log_dt_str = spark.read.format('delta').load(oaoomlog_preppath).agg(max("log_dt")).collect()[0][0]
# max_log_dt_str = '2024-09-30'

print("Loading logs for and after :", max_log_dt_str)

# COMMAND ----------

# DBTITLE 1,Read OAOOM Data
from functools import reduce
from pyspark.sql import DataFrame

stack = [oaoom_delta_path]
dfAppend = []
paths = []
while len(stack) > 0:
  current_folder = stack.pop(0)
  for file in dbutils.fs.ls(current_folder):
    if file.isDir():
      # Check if this is a delta table and do not recurse if so!
      try:
        delta_check_path = f"{file.path}/_delta_log"
        dbutils.fs.ls(delta_check_path)  # raises an exception if missing
        # print(f"dataset: {file.path}")
        paths.append(file.path)
      except:            
        stack.append(file.path)
 

# COMMAND ----------

# DBTITLE 1,Finalize struct OAOOM Data
read_str = ""
read_str = read_str + "df_series = spark.read.format('delta').load('" + paths[0] + "').filter(col('LOG_DT') >= '" + max_log_dt_str + "')"
for p in paths[1:]:
  read_str = read_str + ".union(spark.read.format('delta').load('" + p + "')).filter(col('LOG_DT') >= '" + max_log_dt_str + "')"

exec(read_str)

# COMMAND ----------

# DBTITLE 1,Transfrom and Load Oaoom prep data
from pyspark.sql import SQLContext

df_series.createOrReplaceTempView('pbi_oaoomlog')

df_oaoomlog_prep = spark.sql("select *, \
date_format(END_TMS,'mm')- date_format(START_TMS,'mm') as duration_mts, date_format(END_TMS,'ss')- date_format(START_TMS,'ss') as duration_secs, \
case when SRC_FILE_NM like 'WEB_REPORT_VDR%FLG2%' or NOTEBOOK_NM like '%LDC_WEB_REPORT' then 'LDC_FSWEB'  \
     when SRC_FILE_NM like 'WEB_REPORT_AA%' then CONCAT(substr(SRC_FILE_NM,14,3),'_FSWEB') \
     when SRC_FILE_NM like 'WEB_REPORT%LEG%' or NOTEBOOK_NM like '%LDP_WEB_REPORT' then 'LDP_FSWEB' \
     when SRC_FILE_NM like 'VDR%LEG%' then 'VDHIST_LDP'  \
     when SRC_FILE_NM like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SRC_FILE_NM like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SRC_FILE_NM like 'AA%' then substr(SRC_FILE_NM,3,3) \
     when SRC_FILE_NM like ' _AA%' then substr(SRC_FILE_NM,5,3) \
     when SRC_FILE_NM like '%VDR_%PP4F%' then 'VDHIST_PPCD'  \
     when SRC_FILE_NM like '%VDR_%PP4G%' then 'VDHIST_PPAB' \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) ='' and NOTEBOOK_NM not like '%raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) != '' \
     and (NOTEBOOK_NM like '%oasis_raw_to_struct%process%' or NOTEBOOK_NM like '%oasis_struct_to_prep%') then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(TARGET_NM) ='' and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,47,2)),'_OASIS') \
     when SRC_FILE_NM like 'OAASIS%' and trim(NOTEBOOK_NM) like '%count%' then 'OPS_OASIS' \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%/Fsbch_prep/%' then upper(substr(NOTEBOOK_NM,25,3)) \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%/Fsbch_struct%Raw_to_Struct%' then upper(substr(NOTEBOOK_NM,27,3)) \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '/oasis%' and TARGET_NM !='' and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,47,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '/oasis%' and trim(TARGET_NM) ='' \
     and NOTEBOOK_NM like '%process-raw%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%oasis_struct_to_prep%' then CONCAT(UPPER(substr(NOTEBOOK_NM,37,2)),'_OASIS') \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%oasis_utility%' then 'OPS_OASIS' \
     when trim(SRC_FILE_NM)='' and NOTEBOOK_NM like '%Fsbch_counts_validation%' then 'OPS_FSBCH' \
     else substr(SRC_FILE_NM,1,3) end as SRC_FEED, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'MM'))) as PRTN_MONTH, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yy'))) as PRTN_YEAR \
from pbi_oaoomlog ")

# COMMAND ----------

# DBTITLE 1,Oaoom prep data
df_oaoomlog_prep.write.mode("overwrite")\
                .format("delta")\
                .partitionBy("PRTN_YEAR","PRTN_MONTH","LOG_DT")\
                .option("partitionOverwriteMode", "dynamic")\
                .save(oaoomlog_preppath)

df_oaoomlog_prep.unpersist()

# COMMAND ----------

# DBTITLE 1,Load and Write optimus prep data in prep path
df_optimus = spark.read.format("parquet").load(optimus_path)
df_optimus.createOrReplaceTempView('pbi_optimus')

df_optimus_prep = spark.sql("select *,date_format(DateTimeCompleted,'mm')- date_format(DateTimeStarted,'mm') as optduration_mts, \
date_format(DateTimeCompleted,'ss')- date_format(DateTimeStarted,'ss') as optduration_secs, \
case when DrainFileType like '%.%' then substr(DrainFileType,1,instr(DrainFileType,'.')-1) \
else DrainFileType end as optsys_nm, \
case when SourceFileName like 'WEB_REPORT_VDR%FLG2%' then 'LDC_FSWEB' \
     when SourceFileName like 'WEB_REPORT_AA%' then CONCAT(substr(SourceFileName,14,3),'_FSWEB') \
     when SourceFileName like 'WEB_REPORT%LEG%' then 'LDP_FSWEB' \
     when SourceFileName like 'VDR%LEG%' then 'VDHIST_LDP' \
     when SourceFileName like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SourceFileName like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SourceFileName like 'AA%' then substr(SourceFileName,3,3) \
     else substr(SourceFileName,1,4) end as optsrc_feed \
from pbi_optimus")

df_optimus_prep.write.mode("overwrite").format("delta").option("OverwriteSchema", "true").save(optimuslog_preppath)

# COMMAND ----------

# DBTITLE 1,load without ym
# df_dashboard_prep = spark.sql("""select * from crpay_prep.oaoomlog a left join crpay_prep.optimuslog b on a.SRC_FILE_NM = b.SourceFileName """)

# df_dashboard_prep.write.mode("overwrite")\
#                  .format("delta")\
#                  .partitionBy("PRTN_YEAR","PRTN_MONTH")\
#                  .option("partitionOverwriteMode", "dynamic")\
#                  .save(pbidsb_path)

# COMMAND ----------

# DBTITLE 1,Load and Write dashboard prep data in prep path
df_dashboard_prep = spark.sql("""select * from crpay_prep.oaoomlog a left join crpay_prep.optimuslog b on a.SRC_FILE_NM = b.SourceFileName where ((a.PRTN_YEAR={0} AND a.PRTN_MONTH={1}) or (a.PRTN_YEAR={2} AND a.PRTN_MONTH={3}))""".format(current_year,current_month,previous_year,previous_month))

df_dashboard_prep.write.mode("overwrite")\
                 .format("delta")\
                 .partitionBy("PRTN_YEAR","PRTN_MONTH")\
                 .option("partitionOverwriteMode", "dynamic")\
                 .save(pbidsb_path)
