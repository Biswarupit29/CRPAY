# Databricks notebook source
# DBTITLE 1,PPA/PPB/PPC/PPD raw_to_struct
"Version History of module PPA,PPB,PPC and PPD raw_to_strut"

"Changes:"

"Developer: Nitin"
"Date Created: 10/23/2020"
"Date Updated : 03/03/2021"
"Purpose: Read PPA,PPB,PPC and PPD data from Raw zone and Load into struct Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
#    Testing Repo
#    Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", " ")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Rejected_Records_path", " ")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("Output_File_Data", " ")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")


# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Split multiple receivers
#splitting receiver emails so that mails to be delivered to desginated people.
receiver_emails = receiver_emails.split()

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
# log report function param's 
import datetime

SYS_NM = "crpay"
SRC_FILE_NM = get_drain_file_name(Input_File)
#SRC_FILE_NM = Input_File_Name
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "STRUCT"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"

print(RUN_ID)


# COMMAND ----------

dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()

# COMMAND ----------

# DBTITLE 1,Log the Starting of this Notebook
# Write the first log with start time
# The log will be written in the success folder 

SAVE_PATH = SUCCESS_PATH
STATUS_CD = "R"
MSG_DESC = "Notebook starting"

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Read Input Data Files for PPA,PPB,PPC & PPD from Raw Zone
#Read Input Data Files for PPA,PPB,PPC & PPD
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
try:
  Input_File_Path = Input_File + 'AAPP*.json'
  cp_src_df = spark.read.json(Input_File_Path)
  cp_cf_count = cp_src_df.count()
  
  MSG_DESC = "P series data has been read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read P series records from Raw zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

# DBTITLE 1,validate count of src input file before and after bad records
#to identify bad records , load them into specified reject path thn remove those bad records for further use
try:
  cp_pii_df = spark.read.format("json").option("badRecordsPath",Rejected_Records_path ).load(Input_File_Path)
  # adding audit columns as an input file name and LOAD TIME in Data frame
  cp_pii_df = cp_pii_df.withColumn("sourcefile",col("_metadata.file_path"))
  regex_str = "[\/]([^\/]+)$"
  cp_pii_df = cp_pii_df.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))
  cp_pii_df_count =cp_pii_df.count()
  #validate count of src input file before and after bad records 
  if(cp_cf_count==cp_pii_df_count):
    print("no bad records in inpout file")
  else:
    bad_records_count = (int(cp_cf_count)-int(cp_pii_df_count))
    print("bad records count: "+str(bad_records_count))
    #send_email(sender_email, receiver_emails, "CREWPAY-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: CREWPAY-"+ Crewpay_Run + "\r\r\nBad Records Count : {0} \r\nBad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), bcc=None, attachments = None)
    send_email(receiver_emails, "CREWPAY-"+ Crewpay_Run +" Bad Records Count Alert" , "Below are Bad record counts of: CREWPAY-"+ Crewpay_Run + "<br>Bad Records Count : {0} <br>Bad Records logged location : {1}".format(str(bad_records_count),Rejected_Records_path), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  MSG_DESC = "performed Count valdaition successfully of src input file before and after bad records"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to validate count of src input file before and after bad records. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e

# COMMAND ----------

#extracting distinct input file name
#SRC_FILE_NM = cp_pii_df.select("SOURCE_FILE").distinct().collect()[0][0]

# COMMAND ----------

# DBTITLE 1,File_Format_Validation
#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0
#Checks Files Emptiness and both has equal records
try:
  count_check=0
  cnt1=cp_pii_df.count()

  if(cnt1!=0):
    count_check=1# RESULT OF COUNT CHECK

  #Checks has all required columns
  columns_checkv1=1
  expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
  for cols in cp_pii_df.columns:
    if(cols not in expected_cols):
      columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1



  #Checks "Month Starting" is present in PPABCD_RECORD[0].DATA columns
  val_check=0  
  cp_pii_df.createOrReplaceTempView("ppaTempView")
  #spark.sql("SELECT COUNT(*) FROM ppaTempView WHERE array_contains(PPABCD_RECORD['DATA'],'MONTH STARTING%')").show()

  if(cnt1>0):
    ppa_val=spark.sql("SELECT COUNT(*) as cnt  FROM ppaTempView WHERE PPABCD_RECORD[0].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[1].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[2].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[3].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[4].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[5].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[6].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[7].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[8].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[9].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[10].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[11].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[12].DATA like '%MONTH STARTING%'").collect()
    if(ppa_val[0].cnt>0):
      val_check=1
  else:
    val_check=0

  if(count_check==1 & columns_checkv1==1  & val_check==1):
    print("Success")
    #send_email(sender_email , receiver_emails , 'CREWPAY-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for CREWPAY-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(receiver_emails , 'CREWPAY-'+Crewpay_Run + ' File_Format_Validation' , 'File format is as expected for CREWPAY-' +Crewpay_Run , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    MSG_DESC = "File_Format_Validation looks fine"
    END_TMS = str(datetime.datetime.now())
    STATUS_CD = "S"
    SAVE_PATH = SUCCESS_PATH
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    print("Failure")
    #send_email(sender_email , receiver_emails , 'CREWPAY-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and array does not contain "MONTH STARTING" or/and Format of file is not as expected for CREWPAY-' +Crewpay_Run, bcc=None, attachments = None)
    send_email(receiver_emails , 'CREWPAY-'+Crewpay_Run + ' File_Format_Validation', 'Either File can be Empty or/and array does not contain "MONTH STARTING" or/and Format of file is not as expected for CREWPAY-' +Crewpay_Run , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    dbutils.notebook.exit("Failure")
except Exception as e:
      MSG_DESC = "Failed to validate File_Format_Validation. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e  

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cp_df_sorted = cp_pii_df.orderBy(cp_pii_df.REC_NUMBER)

# COMMAND ----------

# defined Schema for output data and Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

DataSchema = StructType([StructField("NFZ_OUT_DATA", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

RepSchema = StructType([StructField("RPT_DATA", StringType()),StructField("RPT_PART", StringType()),StructField("RPT_IND", StringType()),StructField("RPT_STA", StringType()),StructField("RPT_NBR", StringType()),StructField("RPT_CTR", StringType()),StructField("RPT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

# COMMAND ----------

# DBTITLE 1,Data Processing for PPA/PPB/PPC/PPD files
#Data processing for PPA,PPB,PPC and PPD input JSON files as per CRP028 program

try:
  def fs(str,len,val):
     return str.rjust(len,val)[:len]

  NFZ_FILE_OUT_TMP_APPEND_LIST = []
  NFZ_RPT_OUT_TMP_APPEND_LIST = []

  CNTL_PARTITION_ID = 'AA'
  LINE_NUMBER = 1
  MONTH_STARTING = 'N'
  EMP_IND = 'N'
  space = ''

  for row in cp_df_sorted.collect():
      LOAD_TIME = row.LOADTIME
      SOURCE_FILENAME = row.SOURCE_FILE
      for A in range(1,14):
        HDR_REC_CHK = row.PPABCD_RECORD[A-1].DATA
        START_DATE =  row.PPABCD_RECORD[A-1].StartDate
        pad = ' ' * (80-len(HDR_REC_CHK))
        if (("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'N')):
            MONTH_STARTING = 'Y'
            EMP_IND = 'Y'
            NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','',START_DATE,LOAD_TIME,SOURCE_FILENAME)
            NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
            NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
        elif(("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'Y')):
            MONTH_STARTING = 'Y'
            EMP_IND = 'Y'
        else:
            EMPLOYEE_STATION = row.PPABCD_RECORD[A-1].EmployeeStation
            EMPLOYEE_NUMBER = row.PPABCD_RECORD[A-1].EmployeeNumber
            EMPLOYEE_NAME_RAW  = row.PPABCD_RECORD[A-1].EmployeeName
            EMPLOYEE_NAME = EMPLOYEE_NAME_RAW[0:17]
            Domestic_International = row.PPABCD_RECORD[A-1].DomesticInternational
            INDICATOR = Domestic_International[0:1]
            LINE_NUMBER = LINE_NUMBER + 1
            LINE_NUMBER_ZERO = fs(str(LINE_NUMBER),7, '0')
            if(EMP_IND == 'Y'):

              NFZ_RPT_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
              NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))
              EMP_IND = 'N'
            NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
            NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
  MSG_DESC = "PPA/PPB/PPC/PPD Files are sucessfully processed"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process PPA/PPB/PPC/PPD Files. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 
NFZ_FILE_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_FILE_OUT_TMP_APPEND_LIST,schema=DataSchema)


# COMMAND ----------

# DBTITLE 1,converting DATE format into YYYY-MM-DD from MM-DD-YYYY
#converting START_DATE format into YYYY-MM-DD from MM-DD-YYYY
from datetime import datetime
import pyspark.sql.types as T
import pyspark.sql.functions as F


def user_defined_timestamp(date_col):
    _date = datetime.strptime(date_col, '%m-%d-%Y')
    return _date.strftime('%Y-%m-%d')

user_defined_timestamp_udf = F.udf(user_defined_timestamp, T.StringType())

NFZ_FILE_OUT_TMP_APPEND_DF = NFZ_FILE_OUT_TMP_APPEND_DF.withColumn('new_date', user_defined_timestamp_udf('START_DATE'))

# COMMAND ----------

# DBTITLE 1,Extracting YEAR and MONTH separately from column TRANSFORMED_STARTDATE
#extract YEAR and MONTH separately from column TRANSFORMED_STARTDATE
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import year, month
from pyspark.sql.types import IntegerType 
from pyspark.sql.functions import *
import pyspark.sql.functions as sf

NFZ_FILE_OUT_TMP_APPEND_DF1= NFZ_FILE_OUT_TMP_APPEND_DF.withColumn("TRANSFORMED_STARTDATE",date_add(to_date("new_date"),4))
NFZ_FILE_OUT_TMP_APPEND_DF1=  NFZ_FILE_OUT_TMP_APPEND_DF1.selectExpr("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","START_DATE","TRANSFORMED_STARTDATE","year(TRANSFORMED_STARTDATE) as YEAR","month(TRANSFORMED_STARTDATE) as MONTH","month(LOAD_TIME) as PROCESSING_MONTH","LOAD_TIME","SOURCE_FILENAME")

# COMMAND ----------

# DBTITLE 1,validate month for pre/post files and ensure right month of pre/post should be processed.
#validate month for pre/post files and ensure right month of pre/post should be processed.
# implemented Manual load process ensuring that any month file requested during manual load is validated.

try:
  CP_VAL= NFZ_FILE_OUT_TMP_APPEND_DF1.limit(1).select("MONTH","SOURCE_FILENAME","PROCESSING_MONTH")

  for record in CP_VAL.collect():
    if(LOAD_TYPE=='M') or (LOAD_TYPE=='m'):
        if("PPA" in record.SOURCE_FILENAME):
            #send_email(sender_email, receiver_emails, 'CREWPAY-PPA Manual Load', 'Successful Manual Load for CREWPAY-PPA.', bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-PPA Manual Load', 'Successful Manual Load for CREWPAY-PPA.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
        elif("PPB" in record.SOURCE_FILENAME):
            #send_email(sender_email, receiver_emails, 'CREWPAY-PPB Manual Load', 'Successful Manual Load for CREWPAY-PPB.', bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-PPB Manual Load', 'Successful Manual Load for CREWPAY-PPB.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
        elif("PPC" in record.SOURCE_FILENAME):
            #send_email(sender_email, receiver_emails, 'CREWPAY-PPC Manual Load', 'Successful Manual Load for CREWPAY-PPC.', bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-PPC Manual Load', 'Successful Manual Load for CREWPAY-PPC.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
        else:
          #send_email(sender_email, receiver_emails, 'CREWPAY-PPD Manual Load', 'Successful Manual Load for CREWPAY-PPD.', bcc=None, attachments = None)
          send_email(receiver_emails, 'CREWPAY-PPD Manual Load', 'Successful Manual Load for CREWPAY-PPD.', clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
    else: 
        if(((record.PROCESSING_MONTH==12) & (record.MONTH==1)) or ((record.MONTH==12) & (record.PROCESSING_MONTH==1))):
                pre_PROCESSING_MONTH = 1
                post_PROCESSING_MONTH = 12
                print("pre_PROCESSING_MONTH="+str(pre_PROCESSING_MONTH),"post_PROCESSING_MONTH="+str(post_PROCESSING_MONTH))
        else:       
                pre_PROCESSING_MONTH = record.PROCESSING_MONTH + 1
                post_PROCESSING_MONTH = record.PROCESSING_MONTH -1
                print(pre_PROCESSING_MONTH,post_PROCESSING_MONTH)


        if("PPA" in record.SOURCE_FILENAME ) or ("PPC" in record.SOURCE_FILENAME):
          if(record.MONTH==post_PROCESSING_MONTH):
            print("PPA/PPC_success")
            #send_email(sender_email, receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Post_MONTH_Validation', 'Post month matching for CREWPAY-'+Crewpay_Run, bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Post_MONTH_Validation', 'Post month matching for CREWPAY-'+Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
          else:
            print("PPA/PPC_failure")
            #send_email(sender_email, receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Post_MONTH_Validation', 'Post month is not matching for CREWPAY-'+Crewpay_Run, bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Post_MONTH_Validation', 'Post month is not matching for CREWPAY-'+Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
            fail 
            dbutils.notebook.exit("PPA/PPC_Failure")

        else:
          if(record.MONTH==pre_PROCESSING_MONTH):
            print("PPB/PPD_success")
            #send_email(sender_email, receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Pre_MONTH_Validation', 'Pre month matching for CREWPAY-'+Crewpay_Run, bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Pre_MONTH_Validation', 'Pre month matching for CREWPAY-'+Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
          else:
            print("PPB/PPD_failure")
            #send_email(sender_email, receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Pre_MONTH_Validation', 'Pre month is not matching for CREWPAY-'+Crewpay_Run, bcc=None, attachments = None)
            send_email(receiver_emails, 'CREWPAY-'+Crewpay_Run + ' Pre_MONTH_Validation', 'Pre month is not matching for CREWPAY-'+Crewpay_Run, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
            fail 
            dbutils.notebook.exit("PPB/PPD_Failure") 
          
  MSG_DESC = "Right/Expected month of pre/post data is processed sucessfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH) 
except Exception as e:
      MSG_DESC = "Failed to process Right/Expected month of pre/post data. Error:" + " " + str(e)
      END_TMS = str(datetime.datetime.now())
      STATUS_CD = "E"
      SAVE_PATH = FAIL_PATH
      log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
      
      raise e    

# COMMAND ----------

#create data delta file 
def write():
  NFZ_FILE_OUT_TMP_APPEND_DF1.orderBy(NFZ_FILE_OUT_TMP_APPEND_DF1.NFZ_OUT_NBR).select("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","YEAR","MONTH","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").partitionBy("YEAR","MONTH").save(Output_File_Data)



# COMMAND ----------

# defining Target_name table based on src file name
if('PPA' in SRC_FILE_NM):
  TARGET_NM = "crpay_struct.crp028_ppa"
elif('PPB' in SRC_FILE_NM):
  TARGET_NM = "crpay_struct.crp028_ppb"
elif('PPC' in SRC_FILE_NM):
  TARGET_NM = "crpay_struct.crp028_ppc"
else:
  TARGET_NM = "crpay_struct.crp028_ppd"
#print(TARGET_NM)

# COMMAND ----------

# DBTITLE 1,Save PPA/PPB/PPC/PPD records into Intermittent area i.e. work-pii
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "PPA/PPB/PPC/PPD records has been successfully written in Struct zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STRUCT")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent PPA/PPB/PPC/PPD records has been skipped without saving due to rerun of same file in Struct zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write PPA/PPB/PPC/PPD records in Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e



# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "Notebook completed processing all PPA/PPB/PPC/PPD records"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------


