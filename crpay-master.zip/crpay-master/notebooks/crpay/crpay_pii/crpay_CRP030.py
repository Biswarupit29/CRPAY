# Databricks notebook source
# DBTITLE 1,program crp029 input from Struct_to_prep
"Version History of program crp029 input from struct_to_prep"

"Changes:"

"Developer: Nitin"
"Date Created: 10/23/2020"
"Date Updated : 03/03/2021"
"Purpose: Read program crp029 input from Struct zone and Load into prep Zone"

# COMMAND ----------

# DBTITLE 1,Create widgets
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("Output_File_Data", "")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

dbutils.widgets.text("STG_epays_Output_File_Report", "")
STG_epays_Output_File_Report = dbutils.widgets.get("STG_epays_Output_File_Report")

dbutils.widgets.text("epays_Output_File_Report", "")
epays_Output_File_Report = dbutils.widgets.get("epays_Output_File_Report")

dbutils.widgets.text("Partition_BY_YEAR", "")
Partition_BY_YEAR = dbutils.widgets.get("Partition_BY_YEAR")

dbutils.widgets.text("Partition_BY_MONTH", "")
Partition_BY_MONTH = dbutils.widgets.get("Partition_BY_MONTH")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("BLOB_NAME", "")
BLOB_NAME = dbutils.widgets.get("BLOB_NAME")



dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

dbutils.widgets.text("Manual_Input_File", "")
Manual_Input_File = dbutils.widgets.get("Manual_Input_File")

dbutils.widgets.text("epays_archive_path", "")
epays_archive_path = dbutils.widgets.get("epays_archive_path")

dbutils.widgets.text("epays_blob_scope", "")
epays_blob_scope = dbutils.widgets.get("epays_blob_scope")

dbutils.widgets.text("epays_blob_key", "")
epays_blob_key = dbutils.widgets.get("epays_blob_key")

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;
# MAGIC set spark.sql.legacy.timeParserPolicy = LEGACY

# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,Initialize Logging Variables
import datetime

SYS_NM = "crpay"
NOTEBOOK_NM = notebook_path
CLUSTER_NM= spark.conf.get("spark.databricks.clusterUsageTags.clusterName")
CLUSTER_ID = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
START_TMS = str(datetime.datetime.now()) 
END_TMS = ""
STATUS_CD = ""
TARGET_NM = ""
TARGET_TYPE_CD = "F"
TARGET_ADLS_ZONE = "PREP"
MOCAM_Path = Operational_Metadata_Path
RUN_ID = str(get_notebook_run_id())
NOTEBOOK_JOB_URL = get_notebook_job_url()
TARGET_TYPE_CD = "F"
SUCCESS_PATH = MOCAM_Path + "/success"
FAIL_PATH = MOCAM_Path + "/failure"


# COMMAND ----------

Input_File_Name = Input_File
Month = Input_File.split('/')[-1]
Month = Month.split('=')[-1]
Month = Month.lstrip("0")
input_nonmonth_path = Input_File.rsplit('=', 1)[0]
Input_File = input_nonmonth_path+'='+Month

# COMMAND ----------

Partition_BY_YEAR = (Manual_Input_File.split('/')[6]).split('=')[1]
Partition_BY_MONTH = (Manual_Input_File.split('/')[7]).split('=')[1]
Partition_BY_YEAR = int(Partition_BY_YEAR)
Partition_BY_MONTH = int(Partition_BY_MONTH)


Input_File_List = Manual_Input_File.split('/')
delimiter = "/"
Input_File_Path = delimiter.join(Input_File_List[:-2])+"/"


Partition_BY_YEAR_1 = (Input_File.split('/')[6]).split('=')[1]
Partition_BY_MONTH_2 = (Input_File.split('/')[7]).split('=')[1]
Partition_BY_YEAR_1 = int(Partition_BY_YEAR_1)
Partition_BY_MONTH_2 = int(Partition_BY_MONTH_2)


# COMMAND ----------

# DBTITLE 1,Read data from Struct Zone which is o/p of program crp029
try:
  if(LOAD_TYPE=='M') or (LOAD_TYPE=='m'):
    cp_df = spark.read.format("delta").load(Input_File_Path).filter(col("YEAR") == Partition_BY_YEAR).filter(col("MONTH") == Partition_BY_MONTH)
    # extracting file name for pre and post 
    SRC_FILE_NM1 = cp_df.select("PRE_INPUT_FILENAME").collect()[0][0]
    SRC_FILE_NM2 = cp_df.select("POST_INPUT_FILENAME").collect()[0][0]
    SRC_FILE_NM = SRC_FILE_NM1 + "_" + SRC_FILE_NM2
   

  else:
    cp_df = spark.read.format("delta").load(Input_File_Path).filter(col("YEAR") == Partition_BY_YEAR_1).filter(col("MONTH") == Partition_BY_MONTH_2)
    # extracting file name for pre and post 
    SRC_FILE_NM1 = cp_df.select("PRE_INPUT_FILENAME").collect()[0][0]
    SRC_FILE_NM2 = cp_df.select("POST_INPUT_FILENAME").collect()[0][0]
    SRC_FILE_NM = SRC_FILE_NM1 + "_" + SRC_FILE_NM2
    print()
  MSG_DESC = "Input data of program crp029 is read successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to read Input data of program crp029 from Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
 
  raise e

# COMMAND ----------

#deduplicating o/p of program 29 using SQL solution for further processing
cp_df.createOrReplaceTempView("crp030_table")
cp_df = spark.sql("select CREW_TKG_RPT,CREW_POST_TKG_RPT,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH,max(LOAD_TIME) as LOAD_TIME,max(PRE_INPUT_FILENAME) as PRE_INPUT_FILENAME,max(POST_INPUT_FILENAME) as POST_INPUT_FILENAME from crp030_table GROUP BY CREW_TKG_RPT,CREW_POST_TKG_RPT,NFZ_OUT_PART,NFZ_OUT_IND,NFZ_OUT_STA,NFZ_OUT_NBR,NFZ_OUT_CTR,NFZ_OUT_NAME,YEAR,MONTH order by NFZ_OUT_CTR")

# COMMAND ----------

# DBTITLE 1,Merged data from o/p of program crp029 is processed for Sharp System
## Merged data from o/p of program crp029 is processed for Sharp System based on few certain logics
## if emp_number falls into '069531' then data process should be terminated
## if emp_number is not null then data should keep processed until ends.
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

# defined Schema for Reprort output and processing output of program 29 data based on desinged program 30  
try:
  DataSchema = StructType([StructField("CC_1", StringType()),StructField("PRE_CREW_TKG_RPT_DATA", StringType()), StructField("POST_CREW_TKG_RPT_DATA", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType()),StructField("REC_NUMBER", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])

  def fs(str,len,val):
    return str.rjust(len,val)[:len]

  CREW_TKG_RPT_DATA_FINAL_LIST=[]

  LINE_CTR = 1
  PAGE_TYPE = 2
  ODD_PAGE = 1
  EVEN_PAGE = 2
  HOLD_NBR = '      '
  HEAD_STA = '   '
  HEAD_NBR = '      '
  PR_POST_HD = '                                         '

  HEAD_DATE = datetime.datetime.now()
  PROCESS_DATE = datetime.datetime.now().strftime("%m/%d/%y")
  CC_1 = ''
  REC_CTR = 0
  FIRST_CHAR = 0

  cp_df_rep1 = cp_df.orderBy("NFZ_OUT_NBR","NFZ_OUT_CTR")

  for row in cp_df_rep1.collect():  
    PR_POST_HD = row.CREW_POST_TKG_RPT.strip()
    YEAR = row.YEAR
    MONTH = row.MONTH
    PRE_INPUT_FILENAME = row.PRE_INPUT_FILENAME
    POST_INPUT_FILENAME = row.POST_INPUT_FILENAME
    NFZ_TKG_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT

    if row.NFZ_OUT_NBR == '069531':
      quit
    if (HOLD_NBR != row.NFZ_OUT_NBR ) :
      if (row.NFZ_OUT_STA != '   ') :
        if (HOLD_NBR != row.NFZ_OUT_NBR) :

          CREW_TKG_RPT_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT

          CC_1 = ' '

      REC_CTR = REC_CTR + 1
      HOLD_NBR = row.NFZ_OUT_NBR
      HEAD_NBR = row.NFZ_OUT_NBR
      HEAD_STA = row.NFZ_OUT_STA
      LINE_CTR = LINE_CTR + 1 

      if REC_CTR == 1 :
        START_LINE = row.CREW_POST_TKG_RPT.strip()
        SL_DF_T = spark.createDataFrame([(START_LINE,)], ['s',])
        SL_DF = SL_DF_T.select(substring(SL_DF_T.s, 16, 7).alias('MS'),substring(SL_DF_T.s, 35, 7).alias('ME')).collect()
        MONTH_START = SL_DF[0][0]
        MONTH_END = SL_DF[0][1]


      PRE_PR_HEAD = 'PP004'+'       ' +str(HEAD_STA)+' ' + str(HEAD_NBR) + ' ' + 'CREWMEMBER PRE/POST' + ' ACTIVITY REPORT' +' '
      POST_PR_HEAD = str(START_LINE) # + ' ' + 'PROCESS DATE' + ' ' + str(HEAD_DATE)

      PRE_CREW_TKG_RPT_DATA = PRE_PR_HEAD
      POST_CREW_TKG_RPT_DATA = POST_PR_HEAD + '  PROCESS DATE' + ' '+PROCESS_DATE 

      if REC_CTR > 2 :
        FIRST_CHAR = 1
        pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
        pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
        CREW_TKG_RPT_DATA_TMP2 = "{0},{1}{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,fs(str(HEAD_NBR),6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)

        CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))

    PRE_CREW_TKG_RPT_DATA = row.CREW_TKG_RPT
    POST_CREW_TKG_RPT_DATA = row.CREW_POST_TKG_RPT
    CREW_TKG_DATA = NFZ_TKG_DATA

    if (LINE_CTR/2 != 0):
      CC_1 = 0
      LINE_CTR = LINE_CTR + 1
    LINE_CTR = LINE_CTR + 1
    REC_CTR = REC_CTR + 1
    FIRST_CHAR = FIRST_CHAR + 1
    if (FIRST_CHAR > 6 or (FIRST_CHAR >1 and FIRST_CHAR < 4)) :
      CC_1=''
    if REC_CTR > 2 :
        pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
        pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
        CREW_TKG_RPT_DATA_TMP3 = "{0},{1}{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,fs(str(HEAD_NBR),6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
        CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(','))
    
  MSG_DESC = "Input data of program crp029 for report is processed successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to process Input data of program crp029 for report from Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# Create Structure report as per defiend schema which to be used further to create o/p file 
CREW_TKG_RPT_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST,schema=DataSchema)


# COMMAND ----------

# DBTITLE 1,Extracting year and month for stage area.
# extracting year and month for stage area.
YEAR_STG = CREW_TKG_RPT_APPEND_DF.select("YEAR").collect()[0][0]
MONTH_STG = CREW_TKG_RPT_APPEND_DF.select("MONTH").collect()[0][0]


# COMMAND ----------

#Load Report and Data files in Staging area first before loading into actual prep zone , so that duplicate data can be removed in advance
def write():
  CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA","EMPLOYEE_NO","MONTH_START","MONTH_END","REC_NUMBER","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.format('delta').mode("append").option("overwriteSchema","true").partitionBy("YEAR","MONTH").save(STG_Output_File_Report)
  


# COMMAND ----------

# DBTITLE 1,Save process data into intermittent zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "processed records for report has been successfully written in work zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"STRUCT_30")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent processed records for report has been skipped without saving due to rerun of same file in work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write processed records for report in work zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

# Read_STG_Output_File_Report = STG_Output_File_Report + '/YEAR=' + YEAR_STG + '/MONTH=' + MONTH_STG 
Read_STG_Output_File_Report = STG_Output_File_Report + '/'


# COMMAND ----------

if(LOAD_TYPE=='M') or (LOAD_TYPE=='m'):
    SHARP_REPORT = spark.read.format("delta").load(STG_Output_File_Report).filter(col("YEAR") == Partition_BY_YEAR).filter(col("MONTH") == Partition_BY_MONTH)
else:
    SHARP_REPORT = spark.read.format("delta").load(STG_Output_File_Report).filter(col("YEAR") == Partition_BY_YEAR_1).filter(col("MONTH") == Partition_BY_MONTH_2)


# COMMAND ----------

# #Reading intermediate report data for removing duplicate data
# SHARP_REPORT = spark.read.format("delta").load(Read_STG_Output_File_Report)

# COMMAND ----------

#deduplicating pre and post data using SQL solution
SHARP_REPORT.createOrReplaceTempView("crp30_report_table")

REPORT_DATA_NON_DUP_DF = spark.sql("select CC_1,PRE_CREW_TKG_RPT_DATA,max(POST_CREW_TKG_RPT_DATA) as POST_CREW_TKG_RPT_DATA,TRIM(EMPLOYEE_NO) AS EMPLOYEE_NO,MONTH_START,MONTH_END,CAST(REC_NUMBER as INT),max(LOAD_TIME) as LOAD_TIME,CAST(YEAR AS INT),CAST(MONTH AS INT),max(PRE_INPUT_FILENAME) as PRE_INPUT_FILENAME ,max(POST_INPUT_FILENAME) as POST_INPUT_FILENAME from crp30_report_table GROUP BY CC_1,PRE_CREW_TKG_RPT_DATA,EMPLOYEE_NO,MONTH_START,MONTH_END,REC_NUMBER,YEAR,MONTH order by REC_NUMBER")


# COMMAND ----------

YEAR = REPORT_DATA_NON_DUP_DF.select("YEAR").collect()[0][0]
MONTH = REPORT_DATA_NON_DUP_DF.select("MONTH").collect()[0][0]



# COMMAND ----------

#Report files are made available in delta format 
 
def write():
  REPORT_DATA_NON_DUP_DF.coalesce(1).write.mode("overwrite").format("delta").partitionBy("YEAR","MONTH").option("mergeSchema", "true").option("replaceWhere", "YEAR = '{0}' AND MONTH = '{1}' ".format(YEAR,MONTH)).save(Output_File_Report)


# COMMAND ----------

# defining Target_name table based on src file name
if('PPA' in SRC_FILE_NM):
  TARGET_NM = "crpay_prep.crp030_ppa_ppb_report"
else:
  TARGET_NM = "crpay_prep.crp030_ppc_ppd_report"


# COMMAND ----------

# DBTITLE 1,Save process data into prep zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "processed records for report has been successfully written in prep zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"PREP")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent processed records for report has been skipped without saving due to rerun of same file in prep zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write processed records for report in prep zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "report has been made available into prep zone"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

# DBTITLE 1,Merged data from o/p of program crp029 is processed for downstream System like epays
## Merged data from o/p of program crp029 is processed for epays System based on few certain logics
## if emp_number falls into '069531' then data process should be terminated
## if emp_number is not null then data should keep processed until ends.

from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring
import re
import dateutil.relativedelta

# defined Schema for Reprort output and processing output of program 29 data based on desinged program 30  
try:
  DataSchema = StructType([StructField("CC_1", StringType()),StructField("PRE_CREW_TKG_RPT_DATA", StringType()), StructField("POST_CREW_TKG_RPT_DATA", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType()),StructField("REC_NUMBER", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType()),StructField("CURRENT_DATE_TIME", StringType())])

  def fs(str,len,val):
    return str.rjust(len,val)[:len]

  CREW_TKG_RPT_DATA_FINAL_LIST=[]

  LINE_CTR = 1
  PAGE_TYPE = 2
  ODD_PAGE = 1
  EVEN_PAGE = 2
  HOLD_NBR = '      '
  HEAD_STA = '   '
  HEAD_NBR = '      '
  PR_POST_HD = '                                         '
  HEAD_DATE = datetime.datetime.now()
  PROCESS_DATE = datetime.datetime.now().strftime("%m/%d/%y")
  m_RPTHDR = re.search(r'(.*?(?P<YM>.*)\-)', str(HEAD_DATE))
  RPTHDR = m_RPTHDR['YM'] if m_RPTHDR else ''
  CURRENT_DATE = RPTHDR + "-01"
  DATE = datetime.datetime.strptime(CURRENT_DATE, "%Y-%m-%d")
  SUB_MONTH = DATE - dateutil.relativedelta.relativedelta(months=1)
  CURRENT_DATE_TIME = SUB_MONTH.strftime("%Y-%m-%d")
  CC_1 = ''
  REC_CTR = 0
  FIRST_CHAR = 0

  cp_df_rep1 = cp_df.orderBy("NFZ_OUT_NBR","NFZ_OUT_CTR")

  for row in cp_df_rep1.collect():  
    PR_POST_HD = row.CREW_POST_TKG_RPT.strip()
    YEAR = row.YEAR
    MONTH = row.MONTH
    PRE_INPUT_FILENAME = row.PRE_INPUT_FILENAME
    POST_INPUT_FILENAME = row.POST_INPUT_FILENAME
    NFZ_TKG_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT

    if row.NFZ_OUT_NBR == '069531':
      quit
    if (HOLD_NBR != row.NFZ_OUT_NBR ) :
      if (row.NFZ_OUT_STA != '   ') :
        if (HOLD_NBR != row.NFZ_OUT_NBR) :

          CREW_TKG_RPT_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT
          CC_1 = ' '

      REC_CTR = REC_CTR + 1
      HOLD_NBR = row.NFZ_OUT_NBR
      HEAD_NBR = row.NFZ_OUT_NBR
      HEAD_STA = row.NFZ_OUT_STA
      LINE_CTR = LINE_CTR + 1 

      if REC_CTR == 1 :
        START_LINE = row.CREW_POST_TKG_RPT.strip()
        SL_DF_T = spark.createDataFrame([(START_LINE,)], ['s',])
        SL_DF = SL_DF_T.select(substring(SL_DF_T.s, 16, 7).alias('MS'),substring(SL_DF_T.s, 35, 7).alias('ME')).collect()
        MONTH_START = SL_DF[0][0]
        MONTH_END = SL_DF[0][1]

      PRE_PR_HEAD = 'PP004'+'       ' +str(HEAD_STA)+' ' + str(HEAD_NBR) + ' ' + 'CREWMEMBER PRE/POST' + ' ACTIVITY REPORT' +' '
      POST_PR_HEAD = str(START_LINE) # + ' ' + 'PROCESS DATE' + ' ' + str(HEAD_DATE)

      PRE_CREW_TKG_RPT_DATA = PRE_PR_HEAD
      POST_CREW_TKG_RPT_DATA = POST_PR_HEAD + '  PROCESS DATE' + '   '+'   '+PROCESS_DATE 

      if REC_CTR > 2 :
        FIRST_CHAR = 1
        pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))     
        pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
        CREW_TKG_RPT_DATA_TMP2 = "{0},{1}{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,fs(str(HEAD_NBR),8,'0'),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME,CURRENT_DATE_TIME)
        CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))


    PRE_CREW_TKG_RPT_DATA = row.CREW_TKG_RPT
    POST_CREW_TKG_RPT_DATA = row.CREW_POST_TKG_RPT

    CREW_TKG_DATA = NFZ_TKG_DATA

    if (LINE_CTR/2 != 0):
      CC_1 = 0
      LINE_CTR = LINE_CTR + 1
    LINE_CTR = LINE_CTR + 1
    REC_CTR = REC_CTR + 1
    FIRST_CHAR = FIRST_CHAR + 1
    if (FIRST_CHAR > 6 or (FIRST_CHAR >1 and FIRST_CHAR < 4)) :
      CC_1=''
    if REC_CTR > 2 :
        pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
        pad1 = ' ' * (69-len(POST_CREW_TKG_RPT_DATA))
        CREW_TKG_RPT_DATA_TMP3 = "{0},{1}{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,POST_CREW_TKG_RPT_DATA,pad1,fs(str(HEAD_NBR),8,'0'),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME,CURRENT_DATE_TIME)

        CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(','))
  MSG_DESC = "Input data of program crp029 for epays system is processed successfully"
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "S"
  SAVE_PATH = SUCCESS_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to process Input data of program crp029 for epays system from Struct zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------

CREW_TKG_RPT_APPEND_ePays = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST,schema=DataSchema)

# COMMAND ----------

YEAR_STG_epay = CREW_TKG_RPT_APPEND_ePays.select("YEAR").collect()[0][0]
MONTH_STG_epay = CREW_TKG_RPT_APPEND_ePays.select("MONTH").collect()[0][0]



# COMMAND ----------

#Load epays Report Data in Staging area first before loading into actual prep zone , so that duplicate data can be removed in advance

def write():
  CREW_TKG_RPT_APPEND_ePays.select("CC_1","CURRENT_DATE_TIME","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA","EMPLOYEE_NO","MONTH_START","MONTH_END","REC_NUMBER","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").partitionBy("YEAR","MONTH").save(STG_epays_Output_File_Report)

# COMMAND ----------

# DBTITLE 1,Save process data for epays into work zone
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "processed records for epays has been successfully written in work zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"epays_struct")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent processed records for epays has been skipped without saving due to rerun of same file in work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write processed records for epays in work zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

STG_epays_Output_File_Report_epays = STG_epays_Output_File_Report + '/'


# COMMAND ----------

if(LOAD_TYPE=='M') or (LOAD_TYPE=='m'):
    epays_REPORT = spark.read.format("delta").load(STG_epays_Output_File_Report).filter(col("YEAR") == Partition_BY_YEAR).filter(col("MONTH") == Partition_BY_MONTH)
else:
    epays_REPORT = spark.read.format("delta").load(STG_epays_Output_File_Report).filter(col("YEAR") == Partition_BY_YEAR_1).filter(col("MONTH") == Partition_BY_MONTH_2)

# COMMAND ----------

# #Read intermediate data 
# epays_REPORT = spark.read.format("delta").load(STG_epays_Output_File_Report_epays)

# COMMAND ----------

# DBTITLE 1,Deduplicating records for epays
#deduplicating records for epays using SQL solution
epays_REPORT.createOrReplaceTempView("crp30_epays_report_table")
epays_REPORT_DATA_NON_DUP_DF = spark.sql("select CC_1,CURRENT_DATE_TIME,PRE_CREW_TKG_RPT_DATA,max(POST_CREW_TKG_RPT_DATA) as POST_CREW_TKG_RPT_DATA,TRIM(EMPLOYEE_NO) AS EMPLOYEE_NO,MONTH_START,MONTH_END,REC_NUMBER,CAST(YEAR AS INT),CAST(MONTH AS INT),max(LOAD_TIME) as LOAD_TIME,max(PRE_INPUT_FILENAME) as PRE_INPUT_FILENAME ,max(POST_INPUT_FILENAME) as POST_INPUT_FILENAME from crp30_epays_report_table GROUP BY CC_1,CURRENT_DATE_TIME,PRE_CREW_TKG_RPT_DATA,EMPLOYEE_NO,MONTH_START,MONTH_END,REC_NUMBER,YEAR,MONTH order by REC_NUMBER")

# COMMAND ----------

## instead of maintaing REC_NUMBER for each record, reset REC_NUMBER based on EMP_NUMBER
from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import *

CREW_TK_DFG_RPT_APPEND_ePays_DF = epays_REPORT_DATA_NON_DUP_DF.withColumn("id", F.rank().over(Window.partitionBy("EMPLOYEE_NO").orderBy("REC_NUMBER")))

CREW_TK_DFG_RPT_APPEND_ePays_sort = CREW_TK_DFG_RPT_APPEND_ePays_DF.orderBy("REC_NUMBER")

CREW_TK_DFG_RPT_APPEND_ePays_Final = CREW_TK_DFG_RPT_APPEND_ePays_sort.withColumn("SEQ_NUM",lpad(CREW_TK_DFG_RPT_APPEND_ePays_sort.id,7,'0'))

# COMMAND ----------

# DBTITLE 1,concatening four columns and making single column
#concatening four columns EMPLOYEE_NO,SEQ_NUM,CURRENT_DATE_TIME,PRE_CREW_TKG_RPT_DATA and making single column.
from pyspark.sql.types import *

CREW_TKG_RPT_APPEND_ePays_DF= CREW_TK_DFG_RPT_APPEND_ePays_Final.selectExpr("concat(EMPLOYEE_NO,SEQ_NUM,CURRENT_DATE_TIME,PRE_CREW_TKG_RPT_DATA) as onerecord","POST_CREW_TKG_RPT_DATA")

# COMMAND ----------

# concating epays output data path with partitions YEAR and MONTH and make final epays output path
#final_epays_Output_Report= epays_Output_File_Report+'/'+ YEAR +'/'+ MONTH

# COMMAND ----------

#configure BLOB for epays file 
spark.conf.set("fs.azure.account.key."+BLOB_NAME+".blob.core.windows.net",dbutils.secrets.get(scope = epays_blob_scope, key = epays_blob_key ))

# COMMAND ----------

# DBTITLE 1,transforming YYYY-MM-DD to MMDDYY 
#transforming YYYY-MM-DD to MMDDYY 
import datetime
today = str(datetime.datetime.now())[0:10]
file_date_format=datetime.datetime.strptime(today, '%Y-%m-%d').strftime('%m%d%y')


# COMMAND ----------

# DBTITLE 1,Defining file name as per business naming convention for programs PPA-PPB and PPC-PPD
#Defining file name as per business naming convention for programs PPA-PPB and PPC-PPD
if('PPA' in SRC_FILE_NM):
  File_Name = "HRI191.PILOT."+file_date_format
else:
  File_Name = "HRI191.FA." + file_date_format


# COMMAND ----------

## building epays archive location comprises of epays archive path and file name 
epays_archive_location = epays_archive_path +"/" +File_Name


# COMMAND ----------

## as requested adding additional steps to keep epays files into epays_archive zone in crpay ADLS 
import pyspark.sql.functions as F
  
def write():
 
  def myConcat(*cols):
      concat_columns = []
      for c in cols[:-1]:
          concat_columns.append(F.coalesce(c, F.lit("*")))
          concat_columns.append(F.lit(""))  
      concat_columns.append(F.coalesce(cols[-1], F.lit("*")))
      return F.concat(*concat_columns)

  data_text = CREW_TKG_RPT_APPEND_ePays_DF.withColumn("combined", myConcat(*CREW_TKG_RPT_APPEND_ePays_DF.columns)).select("combined")
  data_text.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save(epays_archive_location)
  files = dbutils.fs.ls(epays_archive_location)
  output_file = [x.path for x in files if x.path.endswith(".txt")][0]
  dbutils.fs.mv(output_file, epays_archive_location.rstrip('/') + ".txt")
  dbutils.fs.rm(epays_archive_location, recurse = True)

# COMMAND ----------

# DBTITLE 1,Save process data for epays into archive zone as backup
# retsart logic to call write method if same file is not present otherwise it skips creating stage file step.
result = ''
SRC_FILE_NM = File_Name
try :
  # Log the success message 
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "processed records for epays has been successfully written in work zone"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"epays_archive")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent processed records for epays has been skipped without saving due to rerun of same file in work zone"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write processed records for epays in work zone. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e




# COMMAND ----------

output_blob_folder = epays_Output_File_Report + SRC_FILE_NM

# COMMAND ----------

import pyspark.sql.functions as F
  
def write():
 
  def myConcat(*cols):
      concat_columns = []
      for c in cols[:-1]:
          concat_columns.append(F.coalesce(c, F.lit("*")))
          concat_columns.append(F.lit(""))  
      concat_columns.append(F.coalesce(cols[-1], F.lit("*")))
      return F.concat(*concat_columns)

  data_text = CREW_TKG_RPT_APPEND_ePays_DF.withColumn("combined", myConcat(*CREW_TKG_RPT_APPEND_ePays_DF.columns)).select("combined")
  data_text.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save(output_blob_folder)
  files = dbutils.fs.ls(output_blob_folder)
  output_file = [x.path for x in files if x.path.endswith(".txt")][0]
  dbutils.fs.mv(output_file, output_blob_folder.rstrip('/') + ".txt")
  dbutils.fs.rm(output_blob_folder, recurse = True)

# COMMAND ----------

# DBTITLE 1,Save process data for epays into epays container

#retsart logic to call write method if same file is not present otherwise it skips creating epays data file step.

result = ''

try :
  # Log the success message
  SAVE_PATH = SUCCESS_PATH
  STATUS_CD = "S"
  MSG_DESC = "processed records for epays has been successfully written in epays container"
    
  result = restart_logic(SRC_FILE_NM,Indicator_File_Path,"epays")
  
  if(result == "Saved"):
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  else:
    STATUS_CD = "SK"
    MSG_DESC = "intermittent processed records for epays has been skipped without saving due to rerun of same file in epays container"
    log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
except Exception as e:
  MSG_DESC = "Failed to write processed records for epays in epays container. Error:" + " " + str(e)
  END_TMS = str(datetime.datetime.now())
  STATUS_CD = "E"
  SAVE_PATH = FAIL_PATH
  log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)
  raise e


# COMMAND ----------

# Write the final log with end time

# The log will be written in the success folder 
SAVE_PATH = SUCCESS_PATH
STATUS_CD = "S"
MSG_DESC = "epays file is finally archieved"
END_TMS = str(datetime.datetime.now())
# Empty the Target Name so that it does not calculate insert/update/delete counts for this log
TARGET_NM = ""

log_operational_data(SYS_NM, NOTEBOOK_NM, CLUSTER_NM, CLUSTER_ID, SRC_FILE_NM, TARGET_NM, START_TMS, END_TMS, TARGET_TYPE_CD, STATUS_CD, MSG_DESC, TARGET_ADLS_ZONE, RUN_ID, NOTEBOOK_JOB_URL, SAVE_PATH)

# COMMAND ----------


