# Databricks notebook source
dbutils.widgets.text("Table_Cols", "")
Table_Cols = dbutils.widgets.get("Table_Cols")

dbutils.widgets.text("Prep_Database_Name", "")
Prep_Database_Name = dbutils.widgets.get("Prep_Database_Name")

dbutils.widgets.text("TD_Prep_Table_Name", "")
TD_Prep_Table_Name = dbutils.widgets.get("TD_Prep_Table_Name")

dbutils.widgets.text("LZ_Database_Name", "")
LZ_Database_Name = dbutils.widgets.get("LZ_Database_Name")

dbutils.widgets.text("Present_Database_Name", "")
Present_Database_Name = dbutils.widgets.get("Present_Database_Name")

dbutils.widgets.text("host_Name", "")
host_Name = dbutils.widgets.get("host_Name")

dbutils.widgets.text("database_Name", "")
database_Name = dbutils.widgets.get("database_Name")

dbutils.widgets.text("user_Name", "")
user_Name = dbutils.widgets.get("user_Name")

dbutils.widgets.text("batch_size", "")
batch_size = dbutils.widgets.get("batch_size")

dbutils.widgets.text("Num_of_Sessions", "")
Num_of_Sessions = dbutils.widgets.get("Num_of_Sessions")

dbutils.widgets.text("Secret_Scope", "")
Secret_Scope = dbutils.widgets.get("Secret_Scope")

dbutils.widgets.text("Secret_Key", "")
Secret_Key = dbutils.widgets.get("Secret_Key")

dbutils.widgets.text("Year", "")
Year = dbutils.widgets.get("Year")

dbutils.widgets.text("Month", "")
Month = dbutils.widgets.get("Month")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

print(Table_Cols)

# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

import datetime

# COMMAND ----------

# Extracting Year and Month

if(LOAD_TYPE == "S"):
  Year = int(str(datetime.datetime.now())[0:4])
  Month = int(str(datetime.datetime.now())[5:7])
  if(Month == 1):
    Month = 12
    Year = Year -1
  else:
    Month = Month - 1
print("Year: "+str(Year))
print("Month: "+str(Month))

# COMMAND ----------

# New
# Extract Month's ALPHABETICAL NAME

Month_Name = ''
datetime_object = datetime.datetime.strptime(str(Month), "%m")
Month_Name = datetime_object.strftime("%b").upper()
print("Month Name: ",Month_Name)

# COMMAND ----------

# New
# Delete LZ Table and insert current month's data from PRESNT Table to LZ Table

query = """DELETE {0}.{1} ALL; insert into {0}.{1} sel * from {2}.{1} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH = {4}; """.format(LZ_Database_Name,TD_Prep_Table_Name,Present_Database_Name,Year,Month)

if(TD_Prep_Table_Name == "FLIGHT_ATTNDT_PRE_POST_SEQ_DETL"):
  query = """DELETE {0}.{1} ALL; insert into {0}.{1} sel * from {2}.{1} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH_CD = '{4}'""".format(LZ_Database_Name,TD_Prep_Table_Name,Present_Database_Name,Year,Month_Name)

print(query)
hostName = host_Name
userName = user_Name

td_dml(query, hostName, userName, dbutils.secrets.get(scope = Secret_Scope, key = Secret_Key))

# COMMAND ----------

# New
# Read LZ Table count and based on that delete current month's data from PRESNT Table

driver = "com.teradata.jdbc.TeraDriver"
hostName = host_Name
database = database_Name
userName = user_Name
batchsize = batch_size
sessions = Num_of_Sessions

DF = spark.read.format("jdbc")\
.option('driver', driver) \
.option('url', "jdbc:teradata://{0}/{1}".format(hostName, database)) \
.option('dbtable', LZ_Database_Name+"."+TD_Prep_Table_Name) \
.option('user', userName) \
.option('password', dbutils.secrets.get(scope = Secret_Scope, key = Secret_Key)) \
.option('Type',"FASTLOAD") \
.option('batchsize', batchsize)\
.option('sessions', sessions)\
.load()

Latest_Month_Count = DF.count()
print("Latest_Month_Count: "+str(Latest_Month_Count))

if(Latest_Month_Count > 0):
  query = """DELETE {0}.{1} ALL; delete from {2}.{1} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH = {4}; """.format(LZ_Database_Name,TD_Prep_Table_Name,Present_Database_Name,Year,Month)
  
  if(TD_Prep_Table_Name == "FLIGHT_ATTNDT_PRE_POST_SEQ_DETL"):
    query = """DELETE {0}.{1} ALL; delete from {2}.{1} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH_CD = '{4}'""".format(LZ_Database_Name,TD_Prep_Table_Name,Present_Database_Name,Year,Month_Name)
  
  print(query)
  td_dml(query, hostName, userName, dbutils.secrets.get(scope = Secret_Scope, key = Secret_Key))
  print("Deleted existing month presnt database table data")

# COMMAND ----------

# Prepare query for Fastload

query = """select {0} from {1}.{2} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH = {4}""".format(Table_Cols,Prep_Database_Name,TD_Prep_Table_Name,Year,Month)
#print(query)

Month_Name = ''
if(TD_Prep_Table_Name == "FLIGHT_ATTNDT_PRE_POST_SEQ_DETL"):
  #month_num = 12
  datetime_object = datetime.datetime.strptime(str(Month), "%m")
  Month_Name = datetime_object.strftime("%b").upper()
  print("Month Name: ",Month_Name)
  
  query = """select {0} from {1}.{2} where FLIGHT_CREW_CONTRCT_YEAR = {3} and FLIGHT_CREW_CONTRCT_MONTH_CD = '{4}'""".format(Table_Cols,Prep_Database_Name,TD_Prep_Table_Name,Year,Month_Name)

print(query)

# COMMAND ----------

#Perform FastLoad to LZ Table

driver = "com.teradata.jdbc.TeraDriver"
hostName = host_Name
database = database_Name
tableName = LZ_Database_Name+"."+TD_Prep_Table_Name
userName = user_Name
batchsize = batch_size
sessions = Num_of_Sessions

print(tableName)

td_fastload(query, driver, hostName, database, tableName, userName, dbutils.secrets.get(scope = Secret_Scope, key = Secret_Key), batchsize, sessions)

# COMMAND ----------

#insert from LZ Table Data to PRESNT Table

query = """insert into {0}.{2}
 sel * from {1}.{2};""".format(Present_Database_Name,LZ_Database_Name,TD_Prep_Table_Name)
hostName = host_Name
userName = user_Name

td_dml(query, hostName, userName, dbutils.secrets.get(scope = Secret_Scope, key = Secret_Key))