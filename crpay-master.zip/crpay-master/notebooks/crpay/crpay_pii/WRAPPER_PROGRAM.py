# Databricks notebook source
# Create widgets for input which receive concrete path from ADF and output files. precisely, reading parameters value from ADF

dbutils.widgets.text("notebook_path", "")
notebook_path = dbutils.widgets.get("notebook_path")

dbutils.widgets.text("Input_File", "")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Input_File_1", "")
Input_File_1 = dbutils.widgets.get("Input_File_1")

dbutils.widgets.text("Input_File_2", "")
Input_File_2 = dbutils.widgets.get("Input_File_2")

dbutils.widgets.text("Output_File_Report", "")
Output_File_Report = dbutils.widgets.get("Output_File_Report")
  
dbutils.widgets.text("Output_File_Data", "")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

dbutils.widgets.text("STG_Output_File_Report", "")
STG_Output_File_Report = dbutils.widgets.get("STG_Output_File_Report")

dbutils.widgets.text("STG_epays_Output_File_Report", "")
STG_epays_Output_File_Report = dbutils.widgets.get("STG_epays_Output_File_Report")

dbutils.widgets.text("epays_Output_File_Report", "")
epays_Output_File_Report = dbutils.widgets.get("epays_Output_File_Report")

dbutils.widgets.text("Partition_BY_YEAR", "")
Partition_BY_YEAR = dbutils.widgets.get("Partition_BY_YEAR")

dbutils.widgets.text("Partition_BY_MONTH", "")
Partition_BY_MONTH = dbutils.widgets.get("Partition_BY_MONTH")

dbutils.widgets.text("sender_email", " ")
sender_email = dbutils.widgets.get("sender_email")

dbutils.widgets.text("receiver_emails", " ")
receiver_emails = dbutils.widgets.get("receiver_emails")
 
dbutils.widgets.text("Adf_Name", "")
Adf_Name = dbutils.widgets.get("Adf_Name")

dbutils.widgets.text("Pipeline_Name", "") 
Pipeline_Name = dbutils.widgets.get("Pipeline_Name")
 
dbutils.widgets.text("From_Email", "") 
From_Email = dbutils.widgets.get("From_Email")
 
dbutils.widgets.text("To_Email", "") 
To_Email = dbutils.widgets.get("To_Email")

dbutils.widgets.text("Rejected_Records_path", "")
Rejected_Records_path = dbutils.widgets.get("Rejected_Records_path")

dbutils.widgets.text("Indicator_File_Path", "")
Indicator_File_Path = dbutils.widgets.get("Indicator_File_Path")

dbutils.widgets.text("Operational_Metadata_Path", "")
Operational_Metadata_Path = dbutils.widgets.get("Operational_Metadata_Path")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("LOAD_TYPE", "")
LOAD_TYPE = dbutils.widgets.get("LOAD_TYPE")

dbutils.widgets.text("Manual_Input_File_1", " ")
Manual_Input_File_1 = dbutils.widgets.get("Manual_Input_File_1")

dbutils.widgets.text("Manual_Input_File_2", " ")
Manual_Input_File_2 = dbutils.widgets.get("Manual_Input_File_2")

dbutils.widgets.text("Manual_Input_File", " ")
Manual_Input_File = dbutils.widgets.get("Manual_Input_File")

dbutils.widgets.text("Crewpay_Run", " ")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("Business_email", " ")
Business_email = dbutils.widgets.get("Business_email")

dbutils.widgets.text("BLOB_NAME", "")
BLOB_NAME = dbutils.widgets.get("BLOB_NAME")



dbutils.widgets.text("Lseries", "")
Lseries = dbutils.widgets.get("Lseries")

dbutils.widgets.text("epays_archive_path", "")
epays_archive_path = dbutils.widgets.get("epays_archive_path")

dbutils.widgets.text("epays_blob_scope", "")
epays_blob_scope = dbutils.widgets.get("epays_blob_scope")

dbutils.widgets.text("epays_blob_key", "")
epays_blob_key = dbutils.widgets.get("epays_blob_key")


# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")



# COMMAND ----------

# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

subject = "CREWPAY-"+Crewpay_Run + " Job Failed"
body = "Child Notebook Failed :" + notebook_path +"<br>Module: CREWPAY-"+ Crewpay_Run + "<br>Adf_Name : {0} <br>Pipeline_Name : {1}".format(Adf_Name,Pipeline_Name)

# COMMAND ----------

# placeholder/Utility to call child notebook by passing parameters.
 
try:
  Prep_file = dbutils.notebook.run(notebook_path, 20000, {"Input_File" : Input_File,"Input_File_1" : Input_File_1,"Input_File_2" : Input_File_2, "Output_File_Report" : Output_File_Report,"Output_File_Data" : Output_File_Data,"STG_Output_File_Report" : STG_Output_File_Report,"STG_epays_Output_File_Report" : STG_epays_Output_File_Report,"epays_Output_File_Report" : epays_Output_File_Report,"Partition_BY_YEAR" : Partition_BY_YEAR,"Partition_BY_MONTH" : Partition_BY_MONTH, "sender_email" : sender_email, "receiver_emails" : receiver_emails, "Rejected_Records_path" : Rejected_Records_path, "Indicator_File_Path" : Indicator_File_Path, "Input_File_Name" : Input_File_Name, "Operational_Metadata_Path" : Operational_Metadata_Path, "notebook_path" : notebook_path, "LOAD_TYPE" : LOAD_TYPE, "Manual_Input_File" : Manual_Input_File,"Manual_Input_File_1" : Manual_Input_File_1, "Manual_Input_File_2" : Manual_Input_File_2, "Crewpay_Run" : Crewpay_Run, "Business_email" : Business_email,"BLOB_NAME" : BLOB_NAME, "epays_archive_path" : epays_archive_path, "epays_blob_scope" : epays_blob_scope,"epays_blob_key" : epays_blob_key,"clinet_id" : clinet_id,"app_tenant_id" : app_tenant_id,"resource_id" : resource_id,"secret_scope" : secret_scope,"app_key" : app_key})
  

except Exception as e:
    
      receiver_emails = receiver_emails.split()
      #send_email(sender_email, receiver_emails , subject, body, bcc=None, attachments = None)
      send_email(receiver_emails, subject, body, clinet_id, app_tenant_id, resource_id, secret_scope, app_key)


# COMMAND ----------

dbutils.notebook.exit(str(Prep_file))