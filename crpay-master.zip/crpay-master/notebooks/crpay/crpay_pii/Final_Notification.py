# Databricks notebook source
"Version History of Final notification"

"Changes:"

"Developer: Nitin"
"Date Created: 12/10/2020"
"Date Updated : 02/23/2021"
"Purpose: send notification mail once required module gets completed"

# COMMAND ----------

# DBTITLE 1,Create widgets
#Reading parameter values from DataFactory

dbutils.widgets.text("sender_email", "")
 
sender_email = dbutils.widgets.get("sender_email")
 
dbutils.widgets.text("receiver_emails", "")
 
receiver_emails = dbutils.widgets.get("receiver_emails")

dbutils.widgets.text("Crewpay_Run", "")
Crewpay_Run = dbutils.widgets.get("Crewpay_Run")

dbutils.widgets.text("Business_email", "")
Business_email = dbutils.widgets.get("Business_email")

dbutils.widgets.text("Input_File_Name", "")
Input_File_Name = dbutils.widgets.get("Input_File_Name")

dbutils.widgets.text("Lseries", "")
Lseries = dbutils.widgets.get("Lseries")

# clinet_id, app_tenant_id, resource_id, secret_scope, app_key

dbutils.widgets.text("clinet_id", "")
clinet_id = dbutils.widgets.get("clinet_id")

dbutils.widgets.text("app_tenant_id", "")
app_tenant_id = dbutils.widgets.get("app_tenant_id")

dbutils.widgets.text("resource_id", "")
resource_id = dbutils.widgets.get("resource_id")

dbutils.widgets.text("secret_scope", "")
secret_scope = dbutils.widgets.get("secret_scope")

dbutils.widgets.text("app_key", "")
app_key = dbutils.widgets.get("app_key")

# COMMAND ----------

email = receiver_emails + " "+ Business_email 
#splitting receiver emails so that mails to be delivered to desginated people.
receiver_emails = email.split()



# COMMAND ----------

# DBTITLE 1,Load the Common Utilities
# MAGIC %run /crpay/crpay_pii/Common_Utilities

# COMMAND ----------

# DBTITLE 1,final notification logic
if((Crewpay_Run  =='LDA') or (Crewpay_Run =='LDC') or (Crewpay_Run =='LDP')):
  print('a')
  if Crewpay_Run == 'LDP':
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-LDP File Process Completed','CREWPAY: LDP Pilot Leg Details - Sequence History file processed in Orion Azure. Power BI paginated report “Pilot SEQ Details” is now available for the previous contract month.\r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name) , bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-LDP File Process Completed','CREWPAY: LDP Pilot Leg Details - Sequence History file processed in Orion Azure. Power BI paginated report “Pilot SEQ Details” is now available for the previous contract month.<br>Input_Binary_File_Name: {0}'.format(Input_File_Name) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  elif Crewpay_Run == 'LDC':
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-LDC File Process Completed','CREWPAY: LDC FA Leg Details - Sequence History file processed in Orion Azure. Power BI paginated report “FA SEQ Details” is now available for the previous contract month.\r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name) , bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-LDC File Process Completed','CREWPAY: LDC FA Leg Details - Sequence History file processed in Orion Azure. Power BI paginated report “FA SEQ Details” is now available for the previous contract month.<br>Input_Binary_File_Name: {0}'.format(Input_File_Name) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  else:
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-LDA File Process Completed','CREWPAY: LDA AA (Exclude LA FA) FA Sequence History file processed in Orion Azure. Power BI paginated report “FA SEQ Details (HSE)” is now available for the previous contract month.\r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name) , bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-LDA File Process Completed','CREWPAY: LDA AA (Exclude LA FA) FA Sequence History file processed in Orion Azure. Power BI paginated report “FA SEQ Details (HSE)” is now available for the previous contract month.<br>Input_Binary_File_Name: {0}'.format(Input_File_Name) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
else:
  if Crewpay_Run == 'PPB':
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-PPB File Process Completed', 'CREWPAY: PPB Pilots Activity Pre capture file processed in Orion Azure.\r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name) , bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-PPB File Process Completed', 'CREWPAY: PPB Pilots Activity Pre capture file processed in Orion Azure.<br>Input_Binary_File_Name: {0}'.format(Input_File_Name) , clinet_id, app_tenant_id, resource_id, secret_scope, app_key)

  elif Crewpay_Run == 'PPD':
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-PPD File Process Completed', 'CREWPAY: PPD FA Activity Pre capture file processed in Orion Azure.\r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name), bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-PPD File Process Completed', 'CREWPAY: PPD FA Activity Pre capture file processed in Orion Azure.<br>Input_Binary_File_Name: {0}'.format(Input_File_Name), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  elif Crewpay_Run == 'PPA':
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-PPA File Process Completed', 'CREWPAY: PPA Pilot Activity Post capture file processed in Orion Azure. Power BI paginated report “Pilots pre and post Activity” is now available for the previous contract month. \r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name), bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-PPA File Process Completed', 'CREWPAY: PPA Pilot Activity Post capture file processed in Orion Azure. Power BI paginated report “Pilots pre and post Activity” is now available for the previous contract month. <br>Input_Binary_File_Name: {0}'.format(Input_File_Name), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  else:
    #send_email(sender_email , receiver_emails , 'Orion Azure: CREWPAY-PPC File Process Completed', 'CREWPAY: PPC FA Activity Post capture file processed in Orion Azure. Power BI paginated report “FA pre and post Activity” is now available for the previous contract month. \r\r\nInput_Binary_File_Name: {0}'.format(Input_File_Name), bcc=None, attachments = None)
    send_email(receiver_emails , 'Orion Azure: CREWPAY-PPC File Process Completed', 'CREWPAY: PPC FA Activity Post capture file processed in Orion Azure. Power BI paginated report “FA pre and post Activity” is now available for the previous contract month. <br>Input_Binary_File_Name: {0}'.format(Input_File_Name), clinet_id, app_tenant_id, resource_id, secret_scope, app_key)
  
