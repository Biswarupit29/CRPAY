# Databricks notebook source
dbutils.widgets.text("crpay_fail_path", "")

crpay_fail_path = dbutils.widgets.get("crpay_fail_path")

dbutils.widgets.text("crpay_success_path", "")

crpay_success_path = dbutils.widgets.get("crpay_success_path")

dbutils.widgets.text("fsbch_fail_path", "")

fsbch_fail_path = dbutils.widgets.get("fsbch_fail_path")

dbutils.widgets.text("fsbch_success_path", "")

fsbch_success_path = dbutils.widgets.get("fsbch_success_path")

dbutils.widgets.text("oasis_fail_path", "")

oasis_fail_path = dbutils.widgets.get("oasis_fail_path")

dbutils.widgets.text("oasis_success_path", "")

oasis_success_path = dbutils.widgets.get("oasis_success_path")

dbutils.widgets.text("optimus_path", "")

optimus_path = dbutils.widgets.get("optimus_path")

dbutils.widgets.text("oaoomlog_strctpath", "")

oaoomlog_strctpath = dbutils.widgets.get("oaoomlog_strctpath")

dbutils.widgets.text("oaoomlog_preppath", "")

oaoomlog_preppath = dbutils.widgets.get("oaoomlog_preppath")

dbutils.widgets.text("optimuslog_preppath", "")

optimuslog_preppath = dbutils.widgets.get("optimuslog_preppath")

# COMMAND ----------

# crpay_fail_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/crpay-log/failure/"
# crpay_fdataDf =  spark.read.format("delta").load(crpay_fail_folderPath)

# crpay_success_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/crpay-log/success/"
# crpay_sdataDf = spark.read.format("delta").load(crpay_success_folderPath)

# fsbch_fail_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/fsbch-log/failure/"
# fsbch_fdataDf =  spark.read.format("delta").load(fsbch_fail_folderPath)

# fsbch_success_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/fsbch-log/success/"
# fsbch_sdataDf = spark.read.format("delta").load(fsbch_success_folderPath)

# oasis_fail_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/oasis-log/failure/"
# oasis_fdataDf =  spark.read.format("delta").load(oasis_fail_folderPath)

# oasis_success_folderPath = "abfss://oaoom@aabaoriondlsprod.dfs.core.windows.net/delta-struct/oasis-log/success/"
# oasis_sdataDf = spark.read.format("delta").load(oasis_success_folderPath)

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false

# COMMAND ----------



crpay_fdataDf =  spark.read.format("parquet").load(crpay_fail_path)
crpay_sdataDf = spark.read.format("parquet").load(crpay_success_path)

fsbch_fdataDf =  spark.read.format("parquet").load(fsbch_fail_path)
fsbch_sdataDf = spark.read.format("parquet").load(fsbch_success_path)

#oasis_fdataDf =  spark.read.format("delta").load(oasis_fail_path)
oasis_sdataDf = spark.read.format("parquet").load(oasis_success_path)

optimus_Df = spark.read.format("parquet").load(optimus_path)

# COMMAND ----------

crpayuniondf = crpay_sdataDf.union(crpay_fdataDf)
fsbchuniondf = fsbch_sdataDf.union(fsbch_fdataDf)
#oasisuniondf = oasis_sdataDf.union(oasis_fdataDf)

# COMMAND ----------

#mergeunionDf = crpayuniondf.union(fsbchuniondf).union(oasisuniondf)
mergeunionDf = crpayuniondf.union(fsbchuniondf).union(oasis_sdataDf)

# COMMAND ----------

mergeunionDf.createTempView('pbi_adflog') 
optimus_Df.createTempView('pbi_optimus')
#apidtls_Df.createTempView('pbi_apidtls')
#crpayuniondf.createTempView('pbi_adflog')

# COMMAND ----------

df_oaoomlog_struct = spark.sql("select *, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'MM'))) as PRTN_MONTH, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yy'))) as PRTN_YEAR \
from pbi_adflog")

# COMMAND ----------

#------WRITE RESULT SET TO FILE PATH FOR REPORTING -----#

df_oaoomlog_struct.write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH").option("mergeSchema", "true").save(oaoomlog_strctpath)

# COMMAND ----------

from pyspark.sql import SQLContext

df_oaoomlog_prep = spark.sql("select *, \
date_format(END_TMS,'mm')- date_format(START_TMS,'mm') as duration_mts, date_format(END_TMS,'ss')- date_format(START_TMS,'ss') as duration_secs, \
case when SRC_FILE_NM like 'WEB_REPORT_VDR%FLG2%' then 'LDC_FSWEB' \
     when SRC_FILE_NM like 'WEB_REPORT_AA%' then CONCAT(substr(SRC_FILE_NM,14,3),'_FSWEB') \
     when SRC_FILE_NM like 'WEB_REPORT%LEG%' then 'LDP_FSWEB' \
     when SRC_FILE_NM like 'VDR%LEG%' then 'VDHIST_LDP' \
     when SRC_FILE_NM like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SRC_FILE_NM like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SRC_FILE_NM like 'AA%' then substr(SRC_FILE_NM,3,3) \
     else substr(SRC_FILE_NM,1,3) end as SRC_FEED, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'MM'))) as PRTN_MONTH, \
upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yy'))) as PRTN_YEAR \
from pbi_adflog where upper((date_format(to_date(LOG_DT,'yyyy-MM-dd'), 'yyyy'))) = date_format(current_date(),'yyyy')")

# COMMAND ----------

#------WRITE RESULT SET TO FILE PATH FOR REPORTING -----#

df_oaoomlog_prep.write.mode("overwrite").format("delta").partitionBy("PRTN_YEAR","PRTN_MONTH").option("mergeSchema", "true").save(oaoomlog_preppath)

# COMMAND ----------

#------CREATE TABLE IN PREP ZONE FOR REPORTING -----#

spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.oaoomlog USING DELTA LOCATION 'oaoomlog_preppath'")

# COMMAND ----------

df_optimus_prep = spark.sql("select *,date_format(DateTimeCompleted,'mm')- date_format(DateTimeStarted,'mm') as optduration_mts, \
date_format(DateTimeCompleted,'ss')- date_format(DateTimeStarted,'ss') as optduration_secs, \
case when DrainFileType like '%.%' then substr(DrainFileType,1,instr(DrainFileType,'.')-1) \
else DrainFileType end as optsys_nm, \
case when SourceFileName like 'WEB_REPORT_VDR%FLG2%' then 'LDC_FSWEB' \
     when SourceFileName like 'WEB_REPORT_AA%' then CONCAT(substr(SourceFileName,14,3),'_FSWEB') \
     when SourceFileName like 'WEB_REPORT%LEG%' then 'LDP_FSWEB' \
     when SourceFileName like 'VDR%LEG%' then 'VDHIST_LDP' \
     when SourceFileName like 'VDR%FLG2%' then 'VDHIST_LDC' \
     when SourceFileName like 'VD_%LDC%LDP%' then 'VDHIST_LDC_LDP' \
     when SourceFileName like 'AA%' then substr(SourceFileName,3,3) \
     else substr(SourceFileName,1,4) end as optsrc_feed \
from pbi_optimus ")

# COMMAND ----------

df_optimus_prep.write.mode("overwrite").format("delta").option("mergeSchema", "true").save(optimuslog_preppath)

# COMMAND ----------

spark.sql("CREATE TABLE IF NOT EXISTS crpay_prep.optimuslog USING DELTA LOCATION 'optimuslog_preppath'")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create TABLE IF NOT EXISTS crpay_prep.oaoom_optimus as
# MAGIC select *
# MAGIC from crpay_prep.oaoomlog left join crpay_prep.optimuslog on SRC_FILE_NM = SourceFileName