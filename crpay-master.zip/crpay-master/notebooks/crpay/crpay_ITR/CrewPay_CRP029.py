# Databricks notebook source
# Create widgets for inputs which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File_1", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP28_PPC_DELTA_DATA/")
Input_File_1 = dbutils.widgets.get("Input_File_1")

dbutils.widgets.text("Input_File_2", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP28_PPD_DELTA_DATA/")
Input_File_2 = dbutils.widgets.get("Input_File_2")

dbutils.widgets.text("Output_File_Data", "abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/struct/CREWPAY/PROG29_Data.parquet")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;

# COMMAND ----------

#cp_df_samp_proc_post = spark.read.parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-struct-pii/CRP028_PPC_DATA_DELTA/")
#cp_df_samp_proc_pre = spark.read.parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-struct-pii/CRP028_PPD_DATA_DELTA/")



# COMMAND ----------



# COMMAND ----------

#Read Input Data Files for PPA-PPB and PPC-PPD
cp_df_samp_proc_post = spark.read.parquet(Input_File_1)
cp_df_samp_proc_pre  = spark.read.parquet(Input_File_2)


# COMMAND ----------

#remove unwanted additional records having lines of nines
cp_df_samp_proc_pre = cp_df_samp_proc_pre.filter("NFZ_OUT_DATA not like '999999999999%'")
cp_df_samp_proc_post = cp_df_samp_proc_post.filter("NFZ_OUT_DATA not like '999999999999%'")


# COMMAND ----------

#display(cp_df_samp_proc_pre)


# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.types import *

# defined Schema for output data file
DataSchema = StructType([StructField("CREW_TKG_RPT", StringType()),StructField("CREW_POST_TKG_RPT", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])

def fs(str,len,val):
  return str.rjust(len,val)[:len]
  
CREW_TKG_RPT_DATA_APPEND_LIST = []

# Sorting Input files based on Employee number and merging them based on Emp number 

from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

cp_df_samp_proc_pre = cp_df_samp_proc_pre.sort("NFZ_OUT_NBR",ascending=True)
cp_df_samp_proc_post = cp_df_samp_proc_post.sort("NFZ_OUT_NBR",ascending=True)

cp_df_samp_proc_pre = cp_df_samp_proc_pre.withColumn("id", F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))
cp_df_samp_proc_post = cp_df_samp_proc_post.withColumn("id",F.rank().over(Window.partitionBy("NFZ_OUT_NBR").orderBy("NFZ_OUT_CTR")))

cp_df_samp_proc_pre1 = cp_df_samp_proc_pre.selectExpr("NFZ_OUT_STA as PRE_NFZ_OUT_STA","NFZ_OUT_DATA as PRE_NFZ_OUT_DATA","NFZ_OUT_CTR as PRE_NFZ_OUT_CTR","NFZ_OUT_NAME as PRE_NFZ_OUT_NAME","NFZ_OUT_NBR as PRE_NFZ_OUT_NBR","NFZ_OUT_IND as PRE_NFZ_OUT_IND","NFZ_OUT_PART as PRE_NFZ_OUT_PART","YEAR as PRE_YEAR","MONTH as PRE_MONTH","SOURCE_FILENAME as PRE_SOURCE_FILENAME","id as pre_id")
cp_df_samp_proc_post1 = cp_df_samp_proc_post.selectExpr("NFZ_OUT_STA as POST_NFZ_OUT_STA","NFZ_OUT_DATA as POST_NFZ_OUT_DATA","NFZ_OUT_CTR as POST_NFZ_OUT_CTR","NFZ_OUT_NAME as POST_NFZ_OUT_NAME","NFZ_OUT_NBR as POST_NFZ_OUT_NBR","NFZ_OUT_IND as POST_NFZ_OUT_IND","NFZ_OUT_PART as POST_NFZ_OUT_PART","YEAR as POST_YEAR","MONTH as POST_MONTH","SOURCE_FILENAME as POST_SOURCE_FILENAME","id as post_id")

Merge_DF = cp_df_samp_proc_pre1.join(cp_df_samp_proc_post1, ((cp_df_samp_proc_pre1.PRE_NFZ_OUT_NBR == cp_df_samp_proc_post1.POST_NFZ_OUT_NBR) & ( cp_df_samp_proc_pre1.pre_id == cp_df_samp_proc_post1.post_id)), how = 'full')

Merge_DF.createOrReplaceTempView("Merge_PPA_PPB")
#Merge_DF2 = spark.sql("SELECT coalesce(PRE_NFZ_OUT_STA,POST_NFZ_OUT_STA) as PRE_NFZ_OUT_STA,coalesce(PRE_NFZ_OUT_DATA,' ') as PRE_NFZ_OUT_DATA, PRE_NFZ_OUT_CTR, coalesce(PRE_NFZ_OUT_NAME,POST_NFZ_OUT_NAME) as PRE_NFZ_OUT_NAME, coalesce(cast(PRE_NFZ_OUT_NBR as BIGINT),cast(POST_NFZ_OUT_NBR as BIGINT)) as PRE_NFZ_OUT_NBR1, coalesce(PRE_NFZ_OUT_IND,POST_NFZ_OUT_IND) as PRE_NFZ_OUT_IND, coalesce(PRE_NFZ_OUT_PART,POST_NFZ_OUT_PART) as PRE_NFZ_OUT_PART, coalesce(POST_NFZ_OUT_STA,' ') as POST_NFZ_OUT_STA, coalesce(POST_NFZ_OUT_DATA, ' ') as POST_NFZ_OUT_DATA, POST_NFZ_OUT_CTR, coalesce(POST_NFZ_OUT_NAME,PRE_NFZ_OUT_NAME) as POST_NFZ_OUT_NAME, coalesce(cast(POST_NFZ_OUT_NBR as BIGINT),cast(PRE_NFZ_OUT_NBR as BIGINT)) as POST_NFZ_OUT_NBR1, coalesce(POST_NFZ_OUT_IND, PRE_NFZ_OUT_IND) as POST_NFZ_OUT_IND, coalesce(POST_NFZ_OUT_PART,PRE_NFZ_OUT_PART) as POST_NFZ_OUT_PART FROM Merge_PPA_PPB  order by coalesce(coalesce(POST_NFZ_OUT_NBR,999999),coalesce(PRE_NFZ_OUT_NBR,999999)), coalesce(POST_NFZ_OUT_CTR,PRE_NFZ_OUT_CTR) ")

Merge_DF2 = spark.sql("SELECT coalesce(PRE_NFZ_OUT_STA,POST_NFZ_OUT_STA) as PRE_NFZ_OUT_STA,coalesce(PRE_NFZ_OUT_DATA,' ') as PRE_NFZ_OUT_DATA, PRE_NFZ_OUT_CTR, coalesce(PRE_NFZ_OUT_NAME,POST_NFZ_OUT_NAME) as PRE_NFZ_OUT_NAME, coalesce(cast(PRE_NFZ_OUT_NBR as BIGINT),cast(POST_NFZ_OUT_NBR as BIGINT)) as PRE_NFZ_OUT_NBR1, coalesce(PRE_NFZ_OUT_IND,POST_NFZ_OUT_IND) as PRE_NFZ_OUT_IND, coalesce(PRE_NFZ_OUT_PART,POST_NFZ_OUT_PART) as PRE_NFZ_OUT_PART,coalesce(PRE_SOURCE_FILENAME,' ') as PRE_SOURCE_FILENAME, coalesce(POST_NFZ_OUT_STA,' ') as POST_NFZ_OUT_STA, coalesce(POST_NFZ_OUT_DATA, ' ') as POST_NFZ_OUT_DATA, POST_NFZ_OUT_CTR, coalesce(POST_NFZ_OUT_NAME,PRE_NFZ_OUT_NAME) as POST_NFZ_OUT_NAME, coalesce(cast(POST_NFZ_OUT_NBR as BIGINT),cast(PRE_NFZ_OUT_NBR as BIGINT)) as POST_NFZ_OUT_NBR1, coalesce(POST_NFZ_OUT_IND, PRE_NFZ_OUT_IND) as POST_NFZ_OUT_IND, coalesce(POST_NFZ_OUT_PART,PRE_NFZ_OUT_PART) as POST_NFZ_OUT_PART,coalesce(POST_SOURCE_FILENAME,' ') as POST_SOURCE_FILENAME,coalesce(PRE_YEAR,POST_YEAR) as YEAR, coalesce(PRE_MONTH,POST_MONTH) as MONTH FROM Merge_PPA_PPB  order by coalesce(coalesce(POST_NFZ_OUT_NBR,999999),coalesce(PRE_NFZ_OUT_NBR,999999)), coalesce(POST_NFZ_OUT_CTR,PRE_NFZ_OUT_CTR) ")

# COMMAND ----------

#Merged data is processed and transformed based on program

from functools import reduce
from pyspark.sql import DataFrame
import datetime

CREW_TKG_RPT_DATA_APPEND_DF=[]

REC_CTR = 0
SAVE_PART = ''
SAVE_STA = ''
SAVE_NBR = ''
HOLD_IND = ''
HOLD_NBR = ''
LOAD_TIME = datetime.datetime.now()
for row in Merge_DF2.rdd.collect(): 
  YEAR = row.YEAR
  MONTH = row.MONTH
  PRE_INPUT_FILENAME = row.PRE_SOURCE_FILENAME
  POST_INPUT_FILENAME = row.POST_SOURCE_FILENAME
  
  #print(row)
  if ((row.PRE_NFZ_OUT_NBR1 == row.POST_NFZ_OUT_NBR1)  & (row.PRE_NFZ_OUT_PART == row.POST_NFZ_OUT_PART)) :
    CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
    CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
    NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
    NFZ_OUT_IND = row.POST_NFZ_OUT_IND
    HOLD_IND = row.POST_NFZ_OUT_IND
    if row.PRE_NFZ_OUT_STA == '   ' :
      NFZ_OUT_STA = row.POST_NFZ_OUT_STA
      SAVE_STA = row.POST_NFZ_OUT_STA
    else:
      NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
      SAVE_STA = row.PRE_NFZ_OUT_STA
    NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
    SAVE_NBR = row.PRE_NFZ_OUT_NBR1
    HOLD_NBR = row.PRE_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME
    CREW_TKG_RPT_DATA_TMP1 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP1.split(','))
    
    
  elif ((row.PRE_NFZ_OUT_NBR1 > row.POST_NFZ_OUT_NBR1)) :
    CREW_TKG_RPT = row.PRE_NFZ_OUT_DATA
    CREW_POST_TKG_RPT = ' '
    NFZ_OUT_PART = row.PRE_NFZ_OUT_PART
    if (HOLD_NBR == row.PRE_NFZ_OUT_NBR1) :
      NFZ_OUT_IND = HOLD_IND
    else:
      NFZ_OUT_IND = row.PRE_NFZ_OUT_IND
    NFZ_OUT_STA = row.PRE_NFZ_OUT_STA
    NFZ_OUT_NBR = row.PRE_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.PRE_NFZ_OUT_NAME
    
    CREW_TKG_RPT_DATA_TMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))
  
  elif ((row.PRE_NFZ_OUT_NBR1 < row.POST_NFZ_OUT_NBR1)) :
    print(3)
    CREW_TKG_RPT = ' '
    CREW_POST_TKG_RPT = row.POST_NFZ_OUT_DATA
    NFZ_OUT_PART = row.POST_NFZ_OUT_PART
    NFZ_OUT_IND = row.POST_NFZ_OUT_IND
    if (SAVE_NBR == row.POST_NFZ_OUT_NBR1) :
      NFZ_OUT_STA = SAVE_STA
    else:
      NFZ_OUT_STA = row.POST_NFZ_OUT_STA
    NFZ_OUT_NBR = row.POST_NFZ_OUT_NBR1
    REC_CTR = REC_CTR+1    
    NFZ_OUT_CTR = REC_CTR
    NFZ_OUT_NAME = row.POST_NFZ_OUT_NAME
    
    CREW_TKG_RPT_DATA_TMP3 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(CREW_TKG_RPT,63,' '),fs(CREW_POST_TKG_RPT,69,' '),  fs(NFZ_OUT_PART,2,' '), fs(NFZ_OUT_IND,1,' '), fs(NFZ_OUT_STA,3,' '), fs(str(NFZ_OUT_NBR),6,'0'), fs(str(NFZ_OUT_CTR),7,'0'), NFZ_OUT_NAME,LOAD_TIME,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
    
    CREW_TKG_RPT_DATA_APPEND_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(',')) 

      


# COMMAND ----------

#display(CREW_TKG_RPT_DATA_APPEND_LIST)

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 
CREW_TKG_RPT_DATA_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_APPEND_LIST,schema=DataSchema)

# COMMAND ----------

#CREW_TKG_RPT_DATA_APPEND_DF2=CREW_TKG_RPT_DATA_APPEND_DF.filter(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR=='009606')
#display(CREW_TKG_RPT_DATA_APPEND_DF2)

# COMMAND ----------

#PPA-PPB and PPC-PPD parquet/delta output files 

#CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").partitionBy("YEAR","MONTH").save("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-struct-pii/CRP029_PPC_PPD_DATA_DELTA/")


CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Data)

# COMMAND ----------

#Download the PARQUET format data in Single file
#CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR,CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_CTR).coalesce(1).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME").coalesce(1).write.mode('overwrite').parquet(Output_File_Data)