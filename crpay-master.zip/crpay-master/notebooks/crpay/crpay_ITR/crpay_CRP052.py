# Databricks notebook source
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPA.json")
Input_File = dbutils.widgets.get("Input_File")


dbutils.widgets.text("Output_File_Report", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP028_PPD_DELTA_REPORT")
Output_File_Report = dbutils.widgets.get("Output_File_Report")


# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false

# COMMAND ----------

#Read Input Data Files for LDP and LDC and get Source_File name added into DF
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
#cr052_pli = spark.read.json("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/raw-pii/LDP.DAT/")
cr052_pli = spark.read.json(Input_File)
cr052_pli = cr052_pli.withColumn("sourcefile",input_file_name())
regex_str = "[\/]([^\/]+)$"
cr052_pli = cr052_pli.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))

# COMMAND ----------

#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0


#Checks Files Emptiness and both has equal records
count_check=0
cnt1=cr052_pli.count()

if(cnt1!=0):
  count_check=1# RESULT OF COUNT CHECK

#Checks has all required columns
columns_checkv1=1
expected_cols=['REC_NUMBER','IMON','IBAS','REC_NUMBER','IDAT','ISEQ','INBR','ISLT','IMSG','ILIN','IFILL','sourcefile','SOURCE_FILE','LOADTIME']
#expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
for cols in cr052_pli.columns:
  if(cols not in expected_cols):
    columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1
if(count_check==1 & columns_checkv1==1):
  print("Success")
else:
  print("Failure")
  dbutils.notebook.exit("Failure")

# COMMAND ----------

#display(cr052_pli)

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cr052_pl=cr052_pli.sort(cr052_pli.REC_NUMBER.asc())


# COMMAND ----------

# defined Schema for output Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

RepSchema = StructType([StructField("IBAS", StringType()),StructField("ISEQ", StringType()),StructField("IMSG", StringType()),StructField("IMON", StringType()),StructField("ILIN", StringType()),StructField("FIXED_DATE", StringType()),StructField("IDATE", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

# COMMAND ----------

#data processing for LDP and LDC files as per CRP052
import re
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import current_date
import datetime

def fs(str,len,val):
   return str.rjust(len,val)[:len]

NFZ_RPT_OUT_TMP_APPEND_LIST = []
REC_NUM = 0
FIXED_DATE = "1966-01-02" 

for row in cr052_pl.rdd.collect():
  OCCU_NUMBER_PER_RECORD = row.ISLT 
  IBAS = row.IBAS
  IMON = row.IMON
  DATE_NUMBER = row.IDAT
  SEQ_NUMBER= row.ISEQ
  I_NUMBER = row.INBR
  m_MESSAGE = re.search(r'(.\/.*?\/.*?\/.*?(?P<month>.*))', row.IMSG)
  MESSAGE = m_MESSAGE['month'] if m_MESSAGE else ''
  #Getting Current date and time
  #now = datetime.datetime.now()
  #YEAR= now.strftime("%Y")
  LINE_BREAK_FLAG ='Y'
  LOAD_TIME= row.LOADTIME
  SOURCE_FILENAME = row.SOURCE_FILE
  #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
   # print("OCCU_NUMBER_PER_RECORD"+ " "+str(OCCU_NUMBER_PER_RECORD))
 
          #i = OCCU_NUMBER_PER_RECORD
  if((I_NUMBER==1) & (LINE_BREAK_FLAG =='Y')):
                     REC_NUM = REC_NUM+1
                     REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                     LINE_BREAK_FLAG = 'N'
                     #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                     NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,fs(' ',64,'*'),FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,'******')
                     NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))
  
  for A in range(0,OCCU_NUMBER_PER_RECORD):
       if((I_NUMBER==1) & (LINE_BREAK_FLAG == 'N')):
                        ILIN = row.ILIN[A]
                        pad = ' ' * (64-len(ILIN))
                        REC_NUM = REC_NUM+1
                        REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                        #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                        if(ILIN==''):
                            FLAG =1 
                        else:
                            NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4}{5},{6},{7},{8},{9},{10}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,ILIN,pad,FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                            NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))
                
       elif(I_NUMBER>1):
              #print("ILIN" + ILIN)
                ILIN = row.ILIN[A]
                pad = ' ' * (64-len(ILIN))
                REC_NUM = REC_NUM+1
                REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
                #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                if(ILIN==''):
                      FLAG =1 
                else:
                  NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3},{4}{5},{6},{7},{8},{9},{10}".format(IBAS,SEQ_NUMBER,MESSAGE,IMON,ILIN,pad,FIXED_DATE,DATE_NUMBER,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                  NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))

            

# COMMAND ----------

#display(NFZ_RPT_OUT_TMP_APPEND_LIST)

# COMMAND ----------

#display(NFZ_RPT_OUT_TMP_APPEND_LIST)

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 
NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

# COMMAND ----------

#display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#convert IDAT value which is in integer format into Dateformat and append static date like 1966-01-02 into converted date format.
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import year, month
#NFZ_RPT_OUT_TMP_APPEND_DF_With_IDAT= NFZ_RPT_OUT_TMP_APPEND_DF.withColumn("IDAT",F.expr(date_add(to_date(NFZ_RPT_OUT_TMP_APPEND_DF.JULIAN_DATE),NFZ_RPT_OUT_TMP_APPEND_DF.IDATE)))
#NFZ_RPT_OUT_TMP_APPEND_DF_withDate=NFZ_RPT_OUT_TMP_APPEND_DF.select(F.expr(date_add(NFZ_RPT_OUT_TMP_APPEND_DF.JULIAN_DATE, NFZ_RPT_OUT_TMP_APPEND_DF.IDATE)).alias('next_date')).collect()
#NFZ_RPT_OUT_TMP_APPEND_DF_With_IDAT = NFZ_RPT_OUT_TMP_APPEND_DF.withColumn('IDAT', F.expr(date_add(to_date('01/02/1966'), NFZ_RPT_OUT_TMP_APPEND_DF.JULIAN_DATE)))
NFZ_RPT_OUT_TMP_APPEND_DF=  NFZ_RPT_OUT_TMP_APPEND_DF.selectExpr("IBAS","ISEQ","IMSG","IMON","ILIN","FIXED_DATE","IDATE","date_add(to_date(FIXED_DATE),IDATE) as CONVERTED_IDATE","REC_NUM","LOAD_TIME","SOURCE_FILENAME")
NFZ_RPT_OUT_TMP_APPEND_DF = NFZ_RPT_OUT_TMP_APPEND_DF.selectExpr("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","year(CONVERTED_IDATE) as YEAR","month(CONVERTED_IDATE) as MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME")
display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#CREW_TKG_RPT_DATA_APPEND_DF.orderBy(CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_NBR,CREW_TKG_RPT_DATA_APPEND_DF.NFZ_OUT_CTR).select("CREW_TKG_RPT","CREW_POST_TKG_RPT","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME").write.format("delta").mode('overwrite').save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP029_PPC_PPD_Merge_Delta_Data")

# COMMAND ----------



# COMMAND ----------

#create report file for gnereated o/p 
#NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").partitionBy("YEAR").save("abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRPO52_LDP_DELTA_REPORT")
#NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-prep-pii/CRPO52_LDP_DELTA_REPORT_SEP")
NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("IBAS","ISEQ","IMSG","IMON","ILIN","CONVERTED_IDATE","YEAR","MONTH","REC_NUM","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Report)

# COMMAND ----------

#NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").saveAsTable("LDP_NFZ_RPT_TEMP")

# COMMAND ----------

#NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").saveAsTable("LDP_NFZ_RPT_TEMP001")

# COMMAND ----------

#%sql
#select * from default.LDP_NFZ_RPT_TEMP


# COMMAND ----------

# create text file from DF 
#data_text_DF= NFZ_RPT_OUT_TMP_APPEND_DF.select("ILIN")
#display(data_text_DF)

# COMMAND ----------

#NFZ_RPT_OUT_TMP_APPEND_DF1= NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM).select("ILIN","IMON","IBAS","ISEQ","IMSG","REC_NUM","YEAR")
#display(NFZ_RPT_OUT_TMP_APPEND_DF1)

# COMMAND ----------

#import pyspark.sql.functions as F

#def myConcat(*cols):
#    concat_columns = []
 #   for c in cols[:-1]:
  #      concat_columns.append(F.coalesce(c, F.lit("*")))
   #     concat_columns.append(F.lit(" "))  
    #concat_columns.append(F.coalesce(cols[-1], F.lit("*")))
   # return F.concat(*concat_columns)

#PPD_report_text = PPD_NFZ_RPT_OUT_TMP_APPEND_DF.withColumn("combined", myConcat(*PPD_NFZ_RPT_OUT_TMP_APPEND_DF.columns)).select("combined")
  
#PPD_report_text.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPD_Report_txt")

#data_text = NFZ_RPT_OUT_TMP_APPEND_DF1.withColumn("combined", myConcat(*NFZ_RPT_OUT_TMP_APPEND_DF1.columns)).select("combined")
#data_text.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/struct-pii/CRP052_LDP_TXT_SEP")

# COMMAND ----------

  
#NFZ_RPT_OUT_TMP_APPEND_DF= NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.ISEQ,NFZ_RPT_OUT_TMP_APPEND_DF.IMSG,NFZ_RPT_OUT_TMP_APPEND_DF.REC_NUM)

# COMMAND ----------

#display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").saveAsTable("LDP_NFZ_RPT_TEMP")

# COMMAND ----------

#%sql
#select * from default.LDP_NFZ_RPT_TEMP 

# COMMAND ----------

