# Databricks notebook source
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP029_PPC_PPD_DELTA_REPORT")
Input_File = dbutils.widgets.get("Input_File")

dbutils.widgets.text("Output_File_Report", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP30_PPC_PPD_DELTA_REPORT")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

dbutils.widgets.text("Output_File_Data", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP30_PPC_PPD_DELTA_DATA")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = "true";
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = "true";
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;

# COMMAND ----------

#Read Input Data Files
cp_df = spark.read.parquet(Input_File)

# COMMAND ----------

#cp_df = spark.read.parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-struct-pii/CRP029_PPC_PPD_DATA_DELTA/")

# COMMAND ----------

##data is processed for Sharp  System 
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring

# defined Schema for Reprort output and processing output of program 29 data based on desinged program 30  

DataSchema = StructType([StructField("CC_1", StringType()),StructField("PRE_CREW_TKG_RPT_DATA", StringType()), StructField("POST_CREW_TKG_RPT_DATA", StringType()),StructField("EMPLOYEE_NO", StringType()),StructField("MONTH_START", StringType()),StructField("MONTH_END", StringType()),StructField("REC_NUMBER", StringType()),StructField("LOAD_TIME", StringType()),StructField("YEAR", StringType()),StructField("MONTH", StringType()),StructField("PRE_INPUT_FILENAME", StringType()),StructField("POST_INPUT_FILENAME", StringType())])

def fs(str,len,val):
  return str.rjust(len,val)[:len]

CREW_TKG_RPT_DATA_FINAL_LIST=[]

LINE_CTR = 1
PAGE_TYPE = 2
ODD_PAGE = 1
EVEN_PAGE = 2
HOLD_NBR = '      '
HEAD_STA = '   '
HEAD_NBR = '      '
PR_POST_HD = '                                         '
#HEAD_DATE = datetime.datetime.now().strftime("%m/%d/%y")
HEAD_DATE = datetime.datetime.now()
PROCESS_DATE = datetime.datetime.now().strftime("%m/%d/%y")
CC_1 = ''
REC_CTR = 0
FIRST_CHAR = 0

cp_df_rep1 = cp_df.orderBy("NFZ_OUT_NBR")

for row in cp_df_rep1.rdd.collect():  
  PR_POST_HD = row.CREW_POST_TKG_RPT.strip()
  YEAR = row.YEAR
  MONTH = row.MONTH
  #NFZ_OUT_CTR = row.NFZ_OUT_CTR
  PRE_INPUT_FILENAME = row.PRE_INPUT_FILENAME
  POST_INPUT_FILENAME = row.POST_INPUT_FILENAME
  #PR_POST_HD = ' '
  NFZ_TKG_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT

  if row.NFZ_OUT_NBR == '069531':
    quit()
  if (HOLD_NBR != row.NFZ_OUT_NBR ) : #or LINE_CTR > 58) :
    if (row.NFZ_OUT_STA != '   ') :
      if (HOLD_NBR != row.NFZ_OUT_NBR) :
        #CREW_TKG_RPT_DATA = ''
        CREW_TKG_RPT_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT
        #CC_1 = 1
        CC_1 = ' '
        #CREW_TKG_RPT_DATA_TMP1 = spark.sql("SELECT lpad('''{0}''',1,' ') as CC_1, lpad('''{1}''',132,' ') as CREW_TKG_RPT_DATA".format(CC_1, CREW_TKG_RPT_DATA))
        #CREW_TKG_RPT_DATA_APPEND_DF.append(CREW_TKG_RPT_DATA_TMP1)
      
    REC_CTR = REC_CTR + 1
    HOLD_NBR = row.NFZ_OUT_NBR
    HEAD_NBR = row.NFZ_OUT_NBR
    HEAD_STA = row.NFZ_OUT_STA
    LINE_CTR = LINE_CTR + 1 
    
    if REC_CTR == 1 :
      START_LINE = row.CREW_POST_TKG_RPT.strip()
      SL_DF_T = spark.createDataFrame([(START_LINE,)], ['s',])
      SL_DF = SL_DF_T.select(substring(SL_DF_T.s, 16, 7).alias('MS'),substring(SL_DF_T.s, 35, 7).alias('ME')).collect()
      MONTH_START = SL_DF[0][0]
      MONTH_END = SL_DF[0][1]
      
      
    PRE_PR_HEAD = '1' + 'PP004'+' ' +  str(HEAD_STA)+' ' + str(HEAD_NBR) + ' ' + 'CREWMEMBER PRE/POST' + ' ACTIVITY REPORT' +' ' 
    POST_PR_HEAD = str(START_LINE) # + ' ' + 'PROCESS DATE' + ' ' + str(HEAD_DATE)
    
    PRE_CREW_TKG_RPT_DATA = PRE_PR_HEAD
    POST_CREW_TKG_RPT_DATA = POST_PR_HEAD + '  PROCESS DATE' + '   '+'   '+PROCESS_DATE 
    
    if REC_CTR > 2 :
      FIRST_CHAR = 1
      #CREW_TKG_RPT_DATA_TMP2 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA.ljust(63,' '), POST_CREW_TKG_RPT_DATA.ljust(69,' '),fs(HEAD_NBR,6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(REC_CTR,7,0),HEAD_DATE,YEAR,MONTH)
      pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
      CREW_TKG_RPT_DATA_TMP2 = "{0},{1}{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,fs(POST_CREW_TKG_RPT_DATA,69,' '),fs(str(HEAD_NBR),6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
      #print('REC_CTR: ',REC_CTR)
      
      CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP2.split(','))
    
  #CREW_TKG_RPT_DATA = row.CREW_TKG_RPT + row.CREW_POST_TKG_RPT
  PRE_CREW_TKG_RPT_DATA = row.CREW_TKG_RPT
  POST_CREW_TKG_RPT_DATA = row.CREW_POST_TKG_RPT
  
  CREW_TKG_DATA = NFZ_TKG_DATA
  
  if (LINE_CTR/2 != 0):
    CC_1 = 0
    LINE_CTR = LINE_CTR + 1
  LINE_CTR = LINE_CTR + 1
  REC_CTR = REC_CTR + 1
  FIRST_CHAR = FIRST_CHAR + 1
  if (FIRST_CHAR > 6 or (FIRST_CHAR >1 and FIRST_CHAR < 4)) :
    CC_1=''
  if REC_CTR > 2 :
   #CREW_TKG_RPT_DATA_TMP3 = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}".format(fs(str(CC_1),1,' '),fs(PRE_CREW_TKG_RPT_DATA,63,' '),fs(POST_CREW_TKG_RPT_DATA,69,' '),fs(HEAD_NBR,6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(REC_CTR,7,0),HEAD_DATE,YEAR,MONTH)
     
      pad = ' ' * (63-len(PRE_CREW_TKG_RPT_DATA))
      CREW_TKG_RPT_DATA_TMP3 = "{0},{1}{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}".format(fs(str(CC_1),1,' '),PRE_CREW_TKG_RPT_DATA,pad,fs(POST_CREW_TKG_RPT_DATA,69,' '),fs(str(HEAD_NBR),6,' '),fs(MONTH_START,7, ' '),fs(MONTH_END,7, ' '),fs(str(REC_CTR-2),7,'0'),HEAD_DATE,YEAR,MONTH,PRE_INPUT_FILENAME,POST_INPUT_FILENAME)
    #print('REC_CTR: ',REC_CTR)
    
      CREW_TKG_RPT_DATA_FINAL_LIST.append(CREW_TKG_RPT_DATA_TMP3.split(','))
    



# COMMAND ----------

# Create Structure report as per defiend schema which to be used further to create o/p file 
CREW_TKG_RPT_APPEND_DF = spark.createDataFrame(CREW_TKG_RPT_DATA_FINAL_LIST,schema=DataSchema)


# COMMAND ----------

#display(CREW_TKG_RPT_APPEND_DF)

# COMMAND ----------



# COMMAND ----------

#Report files are made available in Delta format 

#CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA","EMPLOYEE_NO","MONTH_START","MONTH_END","REC_NUMBER","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.mode('append').parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/prep-pii/CRP030_PPA_PPA_REPORT_DELTA/")

 
CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA","EMPLOYEE_NO","MONTH_START","MONTH_END","REC_NUMBER","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.mode('append').parquet(Output_File_Report)

CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA").write.mode('append').parquet(Output_File_Data)

# COMMAND ----------

#CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA","EMPLOYEE_NO","MONTH_START","MONTH_END","REC_NUMBER","LOAD_TIME","YEAR","MONTH","PRE_INPUT_FILENAME","POST_INPUT_FILENAME").write.mode('append').parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/prep-pii/CRP030_PPC_PPD_REPORT_DELTA/")

#CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA").write.mode('append').parquet("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-struct-pii/CRP030_PPC_PPD_DATA_DELTA/")


# COMMAND ----------

#CREW_TKG_RPT_APPEND_DF_sharp= CREW_TKG_RPT_APPEND_DF.select("CC_1","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA")


# COMMAND ----------

#display(CREW_TKG_RPT_APPEND_DF_sharp)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

#display(CREW_TKG_RPT_APPEND_ePays)

# COMMAND ----------



# COMMAND ----------

#display(CREW_TK_DFG_RPT_APPEND_ePays)

# COMMAND ----------



# COMMAND ----------

#CREW_TKG_RPT_APPEND_ePays_DF= CREW_TK_DFG_RPT_APPEND_ePays_Final.select("EMPLOYEE_NO","SEQ_NUM","CURRENT_DATE_TIME","PRE_CREW_TKG_RPT_DATA","POST_CREW_TKG_RPT_DATA")

# COMMAND ----------

