# Databricks notebook source
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPA.json")
Input_File = dbutils.widgets.get("Input_File")


dbutils.widgets.text("Output_File_Report", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP028_PPD_DELTA_REPORT")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC SET spark.databricks.delta.formatCheck.enabled=false

# COMMAND ----------

#Read Input Data Files for LDA and get Source_File name and LOAD time appended into DF
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
#cr098_pli = spark.read.json("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/raw-pii/LDA.DAT/")
cr098_pli = spark.read.json(Input_File)
cr098_pli = cr098_pli.withColumn("sourcefile",input_file_name())
regex_str = "[\/]([^\/]+)$"
cr098_pli = cr098_pli.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))

# COMMAND ----------

#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0

#Checks Files Emptiness and both has equal records
count_check=0
cnt1=cr052_pli.count()

if(cnt1!=0):
  count_check=1# RESULT OF COUNT CHECK

#Checks has all required columns
columns_checkv1=1
expected_cols=['REC_NUMBER','IMON','IBAS','REC_NUMBER','IDAT','ISEQ','INBR','ISLT','IMSG','ILIN','IFILL','sourcefile','SOURCE_FILE','LOADTIME']
#expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
for cols in cr052_pli.columns:
  if(cols not in expected_cols):
    columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1
if(count_check==1 & columns_checkv1==1):
  print("Success")
else:
  print("Failure")

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cr098_pl=cr098_pli.sort(cr098_pli.REC_NUMBER.asc())


# COMMAND ----------

# defined Schema for output Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

RepSchema = StructType([StructField("IBAS", StringType()),StructField("IDAT", StringType()),StructField("IEMP", StringType()),StructField("ILIN", StringType()),StructField("IMON", StringType()),StructField("IRPTHDR", StringType()),StructField("ISEQ", StringType()),StructField("ISEA", StringType()),StructField("ISLOT", StringType()),StructField("INBR", StringType()),StructField("IAB", StringType()),StructField("FIXED_DATE", StringType()),StructField("REC_NUM", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])


# COMMAND ----------

#data processing for LDA files
import re
from pyspark.sql.functions import date_add,to_date
from pyspark.sql.functions import year
from pyspark.sql.functions import current_date
import datetime

def fs(str,len,val):
   return str.rjust(len,val)[:len]

NFZ_RPT_OUT_TMP_APPEND_LIST = []
NFZ_RPT_OUT_TMP_APPEND_LIST_AB = []
NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB = []
REC_NUM_AB = 0
REC_NUM_NAB = 0
FIXED_DATE = "1966-01-02" 

for row in cr098_pl.rdd.collect():
  OCCU_NUMBER_PER_RECORD = row.IBCK 
  AB = row.IAB
  EMP_NBR = row.IEMP
  IBAS = row.IBAS
  IMON = row.IMON
  DATE_NUMBER = row.IDAT
  ISEA = row.ISEA
  SEQ_NUMBER= row.ISEQ
  I_NUMBER = row.INBR
  m_RPTHDR = re.search(r'(.\/.*?(?P<DM>.*))', row.IRPTHDR)
  RPTHDR = m_RPTHDR['DM'] if m_RPTHDR else ''
  #Getting Current date and time
  #now = datetime.datetime.now()
  #YEAR= now.strftime("%Y")
  SLOT = row.ISLOT
  #LINE_BREAK_FLAG ='Y'
  LOAD_TIME= row.LOADTIME
  SOURCE_FILENAME = row.SOURCE_FILE
  for A in range(0,OCCU_NUMBER_PER_RECORD):
       if(AB=='AB'):
                
                ILIN = row.ILIN[A]
                pad = ' ' * (64-len(ILIN))
                REC_NUM_AB = REC_NUM_AB+1
                REC_NUM_ZERO = fs(str(REC_NUM_AB),7,'0')
                        #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                if(ILIN==''):
                  FLAG =1 
                else:
                  NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}".format(IBAS,DATE_NUMBER,EMP_NBR,ILIN,pad,IMON,RPTHDR,SEQ_NUMBER,ISEA,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                  #NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5}{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}".format(IBAS,DATE_NUMBER,EMP_NBR,ABSOLUTE_BASE_DATA,pad,ACTUAL_BASE_DATA,pad,IMON,RPTHDR,SEQ_NUMBER,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                  NFZ_RPT_OUT_TMP_APPEND_LIST_AB.append(NFZ_RPT_OUT_TMP.split(','))
                
       else:
              #print("ILIN" + ILIN)
               
                ILIN = row.ILIN[A]
                pad = ' ' * (64-len(ILIN))
                REC_NUM_NAB = REC_NUM_NAB + 1
                REC_NUM_ZERO = fs(str(REC_NUM_NAB),7,'0')
                #IDATE = date_add(to_date(JULIAN_DATE),DATE_NUMBER)
                if(ILIN==''):
                      FLAG =1 
                else:
                  NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}".format(IBAS,DATE_NUMBER,EMP_NBR,ILIN,pad,IMON,RPTHDR,SEQ_NUMBER,ISEA,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                  #NFZ_RPT_OUT_TMP =  "{0},{1},{2},{3}{4},{5}{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}".format(IBAS,DATE_NUMBER,EMP_NBR,ABSOLUTE_BASE_DATA,pad,ACTUAL_BASE_DATA,pad,IMON,RPTHDR,SEQ_NUMBER,SLOT,I_NUMBER,AB,FIXED_DATE,REC_NUM_ZERO,LOAD_TIME,SOURCE_FILENAME)
                  NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB.append(NFZ_RPT_OUT_TMP.split(','))

            

# COMMAND ----------

#create unique ID to intact Absolute and Actual Base data based upon EMP_NBR , DATE and SLOT
from pyspark.sql import functions as F
from pyspark.sql.window import *
from pyspark.sql.functions import row_number

NFZ_RPT_OUT_TMP_APPEND_DF_AB = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST_AB,schema=RepSchema)
NFZ_RPT_OUT_TMP_APPEND_DF_AB = NFZ_RPT_OUT_TMP_APPEND_DF_AB.withColumn("id", F.rank().over(Window.partitionBy("IEMP","IDAT","ISLOT").orderBy("REC_NUM")))

NFZ_RPT_OUT_TMP_APPEND_DF_NONAB = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST_NONAB,schema=RepSchema)
NFZ_RPT_OUT_TMP_APPEND_DF_NONAB = NFZ_RPT_OUT_TMP_APPEND_DF_NONAB.withColumn("id", F.rank().over(Window.partitionBy("IEMP","IDAT","ISLOT").orderBy("REC_NUM")))  


# COMMAND ----------

#Merge two data based upon business criteria so that Absoulte and Actual data can be kept togehter as needed 
NFZ_RPT_OUT_TMP_APPEND_DF_AB.createOrReplaceTempView("ABS_TABLE")
NFZ_RPT_OUT_TMP_APPEND_DF_NONAB.createOrReplaceTempView("ACT_TABLE")
#LDA_MERGE_DF = spark.sql("select abs.IBAS as ABS_IBAS,abs.IDAT as abs_IDAT,abs.ILIN as abs_data,abs.IRPTHDR as abs_DATE,abs.ISEQ as abs_ISEQ,abs.ISEA as abs_ISEA,abs.ISLOT as abs_slot,abs.INBR as abs_INBR,abs.REC_NUM as abs_REC_NUM, act.IBAS as act_IBAS,act.IDAT as act_IDAT,act.ILIN as act_data,act.IRPTHDR as act_DATE,act.ISEQ as act_ISEQ,act.ISEA as act_ISEA,act.ISLOT as act_slot,act.INBR as act_INBR,act.REC_NUM as act_REC_NUM from ABS_TABLE abs FULL OUTER JOIN ACT_TABLE act ON abs.IEMP=act.IEMP and abs.IDAT=act.IDAT and abs.ISEQ=act.ISEQ and abs.ISEA=act.ISEA and abs.ISLOT=act.ISLOT and abs.INBR=act.INBR and abs.id=act.id order by  coalesce(abs_REC_NUM,act_REC_NUM)")
LDA_MERGE_DF = spark.sql("select abs.IBAS as ABS_IBAS,abs.IDAT as ABS_IDAT,abs.IEMP as ABS_IEMP,abs.ILIN as ABS_DATA,abs.IMON as ABS_MON,abs.IRPTHDR as ABS_DATE,abs.ISEQ as ABS_ISEQ,abs.ISEA as ABS_ISEA,abs.ISLOT as ABS_SLOT,abs.INBR as ABS_INBR,abs.REC_NUM as ABS_REC_NUM,coalesce(abs.id,act.id)as ABS_ID, act.IBAS as ACT_IBAS,act.IDAT as ACT_IDAT,act.IEMP as ACT_IEMP,act.ILIN as ACT_DATA,act.IMON as ACT_MON,act.IRPTHDR as ACT_DATE,act.ISEQ as ACT_ISEQ,act.ISEA as ACT_ISEA,act.ISLOT as ACT_SLOT,act.INBR as ACT_INBR,act.REC_NUM as ACT_REC_NUM,coalesce(abs.FIXED_DATE,act.FIXED_DATE)as FIXED_DATE,coalesce(abs.LOAD_TIME,act.LOAD_TIME)as LOAD_TIME,coalesce(abs.SOURCE_FILENAME,act.SOURCE_FILENAME)as SOURCE_FILENAME,coalesce(act.id,abs.id)as ACT_ID from ABS_TABLE abs FULL OUTER JOIN ACT_TABLE act ON abs.IEMP=act.IEMP and abs.IDAT=act.IDAT and abs.ISEQ=act.ISEQ and abs.ISEA=act.ISEA and abs.ISLOT=act.ISLOT and abs.INBR=act.INBR and abs.id=act.id order by  coalesce(ABS_IDAT,ACT_IDAT),coalesce(ABS_REC_NUM,ACT_REC_NUM)")


# COMMAND ----------

#display(LDA_MERGE_DF)

# COMMAND ----------

#Select required column for further processing.
LDA_MERGE_DF.createOrReplaceTempView("LDAVIEW")

#LDAP_DATA_DF = spark.sql("SELECT coalesce(ABS_IBAS,ACT_IBAS) as ABS_IBAS,coalesce(ABS_IDAT,ACT_IDAT) as ABS_IDAT, coalesce(ABS_IEMP,ACT_IEMP) as ABS_IEMP, coalesce(ABS_DATA,' ') as ABSOLUTE_BASE_DATA, coalesce(ABS_DATE,ACT_DATE) as ABS_DATE, coalesce(ABS_ISEQ, ACT_ISEQ) as ABS_SEQ_NUM,coalesce(ABS_ISEA, ACT_ISEA) as ABS_ISEA,coalesce(ABS_SLOT, ACT_SLOT) as ABS_SLOT,coalesce(ABS_INBR, ACT_INBR) as ABS_INBR,coalesce(ABS_REC_NUM,ACT_REC_NUM) as ABS_REC_NUM, coalesce(ACT_IBAS,ABS_IBAS) as ACT_IBAS,coalesce(ACT_IDAT,ABS_IDAT) as ACT_IDAT, coalesce(ACT_IEMP,ABS_IEMP) as ACT_IEMP, coalesce(ACT_DATA,' ') as ACTUAL_BASE_DATA, coalesce(ACT_DATE,ABS_DATE) as ACT_DATE, coalesce(ACT_ISEQ,ABS_ISEQ) as ACT_SEQ_NUM ,coalesce(ACT_ISEA,ABS_ISEA) as ACT_ISEA,coalesce(ACT_SLOT,ABS_SLOT) as ACT_SLOT,coalesce(ACT_INBR, ABS_INBR) as ACT_INBR,coalesce(ACT_REC_NUM,ABS_REC_NUM) as ACT_REC_NUM,FIXED_DATE,LOAD_TIME,SOURCE_FILENAME,coalesce(ABS_ID,ACT_ID) as ID FROM LDAVIEW  order by coalesce(coalesce(ABS_IEMP,999999),coalesce(ACT_IEMP,999999)),coalesce(ACT_REC_NUM,ABS_REC_NUM) ")

LDAP_DATA_DF = spark.sql("SELECT coalesce(ABS_IBAS,ACT_IBAS) as IBAS,coalesce(ABS_IDAT,ACT_IDAT) as IDAT, coalesce(ABS_IEMP,ACT_IEMP) as IEMP, coalesce(ABS_DATA,' ') as ABSOLUTE_BASE_DATA, coalesce(ACT_DATA,' ') as ACTUAL_BASE_DATA,coalesce(ABS_MON,ACT_MON) as MONTH,coalesce(ABS_DATE,ACT_DATE) as DATE_MONTH, coalesce(ABS_ISEQ, ACT_ISEQ) as SEQ_NUM,coalesce(ABS_ISEA, ACT_ISEA) as ISEA,coalesce(ABS_SLOT, ACT_SLOT) as SLOT,coalesce(ABS_INBR, ACT_INBR) as INBR,coalesce(ABS_REC_NUM,ACT_REC_NUM) as ABS_REC_NUM,coalesce(ACT_REC_NUM,ABS_REC_NUM) as ACT_REC_NUM,FIXED_DATE,LOAD_TIME,SOURCE_FILENAME,coalesce(ABS_ID,ACT_ID) as ID FROM LDAVIEW  order by coalesce(ACT_REC_NUM,ABS_REC_NUM) ")

# COMMAND ----------

#display(LDAP_DATA_DF)

# COMMAND ----------



# COMMAND ----------

# process LDA data to form in Report format
from functools import reduce
from pyspark.sql import DataFrame
import datetime
from pyspark.sql import functions

DataSchema = StructType([StructField("BASE", StringType()),StructField("IDAT", StringType()),StructField("EMP_NBR", StringType()),StructField("ABSOLUTE_BASE_DATA", StringType()),StructField("PARTITION", StringType()),StructField("ACTUAL_BASE_DATA", StringType()),StructField("MONTH", StringType()),StructField("DATE_MONTH", StringType()),StructField("SEQ_NUM", StringType()),StructField("ISEA", StringType()),StructField("ISLOT", StringType()),StructField("INBR", StringType()),StructField("REC_NUM", StringType()),StructField("FIXED_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType()),StructField("END_PARTITION", StringType())])

def fs(str,len,val):
   return str.rjust(len,val)[:len]

CRPAY_LDA_LIST=[]
REC_NUM =0
for row in LDAP_DATA_DF.rdd.collect(): 
      BASE = row.IBAS
      DATE = row.IDAT
      EMP_NBR = row.IEMP
      ABSOLUTE_BASE_DATA = row.ABSOLUTE_BASE_DATA
      ACTUAL_BASE_DATA = row.ACTUAL_BASE_DATA
      MONTH = row.MONTH
      DATE_MONTH = row.DATE_MONTH
      SEQ_NUM = row.SEQ_NUM
      SEA = row.ISEA
      SLOT = row.SLOT
      NBR = row.INBR
      FIXED_DATE = row.FIXED_DATE
      LOAD_TIME = row.LOAD_TIME
      INPUT_FILENAME = row.SOURCE_FILENAME
      if(row.ID==1):
        REC_NUM = REC_NUM+1
        REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
        Partition = '*'
        pad1 = ' ' * (64-len(ABSOLUTE_BASE_DATA))
        pad2 = ' ' * (64-len(ACTUAL_BASE_DATA))
        NFZ_TMP3 =  "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}".format('***','*****','*******',fs(' ',64,'*'),Partition,fs(' ',64,'*'),'***','*****','***','**','**','*',REC_NUM_ZERO,'**********',fs(' ',23,'*'),fs(' ',20,'*'),Partition)
        CRPAY_LDA_LIST.append(NFZ_TMP3.split(','))
        REC_NUM = REC_NUM+1
        REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
        NFZ_TMP4 =  "{0},{1},{2},{3}{4},{5},{6}{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18}".format(BASE,DATE,EMP_NBR,ABSOLUTE_BASE_DATA,pad1,Partition,ACTUAL_BASE_DATA,pad2,MONTH,DATE_MONTH,SEQ_NUM,SEA,SLOT,NBR,REC_NUM_ZERO,FIXED_DATE,LOAD_TIME,INPUT_FILENAME,Partition)
        CRPAY_LDA_LIST.append(NFZ_TMP4.split(','))
        #print(CREW_TKG_RPT_DATA_APPEND_LIST)       
      else:
        REC_NUM = REC_NUM+1
        REC_NUM_ZERO = fs(str(REC_NUM),7,'0')
        Partition = '*'
        pad1 = ' ' * (64-len(ABSOLUTE_BASE_DATA))
        pad2 = ' ' * (64-len(ACTUAL_BASE_DATA))
        NFZ_TMP5 =  "{0},{1},{2},{3}{4},{5},{6}{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18}".format(BASE,DATE,EMP_NBR,ABSOLUTE_BASE_DATA,pad1,Partition,ACTUAL_BASE_DATA,pad2,MONTH,DATE_MONTH,SEQ_NUM,SEA,SLOT,NBR,REC_NUM_ZERO,FIXED_DATE,LOAD_TIME,INPUT_FILENAME,Partition)
        CRPAY_LDA_LIST.append(NFZ_TMP5.split(','))
        #print(CREW_TKG_RPT_DATA_APPEND_LIST)
      


# COMMAND ----------

# defined Schema for output Report 
CRPAY_LDA_DF = spark.createDataFrame(CRPAY_LDA_LIST,schema=DataSchema)

# COMMAND ----------

#display(CRPAY_LDA_DF)

# COMMAND ----------

#CRPAY_LDA_DF.orderBy("REC_NUM").select("BASE","IDAT","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION").write.format("delta").mode('append').save("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/delta-prep-pii/CRP098_LDA_DELTA_REPORT")

CRPAY_LDA_DF.orderBy("REC_NUM").select("BASE","IDAT","EMP_NBR","ABSOLUTE_BASE_DATA","PARTITION","ACTUAL_BASE_DATA","MONTH","DATE_MONTH","SEQ_NUM","ISEA","ISLOT","INBR","REC_NUM","LOAD_TIME","SOURCE_FILENAME","END_PARTITION").write.format("delta").mode('append').save(Output_File_Report)

# COMMAND ----------



# COMMAND ----------

