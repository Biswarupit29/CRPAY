# Databricks notebook source
dbutils.widgets.text("Input_File", "abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPA.json")
Input_File = dbutils.widgets.get("Input_File")


dbutils.widgets.text("Output_File_Report", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP028_PPD_DELTA_REPORT")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

  
dbutils.widgets.text("Output_File_Data", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP28_PPD_DELTA_DATA/")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;
# MAGIC set spark.databricks.delta.formatCheck.enabled=false;

# COMMAND ----------

spark.conf.set("fs.azure.account.key.banzeauscrpaystg004.blob.core.windows.net", "aSGs2pgDloWpiZDAPBBACu4rpKUyhMV+A/hipVliwQdb6IFrNbf0GOMWqSPsiVjGi/K/m16ycn92MamPj2srUA==")

# COMMAND ----------

#Read Input Data Files for PPA,PPB,PPC & PPD
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
cp_df = spark.read.json(Input_File)
#cp_df = spark.read.json("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/raw-pii/PPB.DAT/")
cp_df = cp_df.withColumn("sourcefile",input_file_name())
regex_str = "[\/]([^\/]+)$"
cp_df = cp_df.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))

# COMMAND ----------

#display(cp_df)

# COMMAND ----------

#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0


#Checks Files Emptiness and both has equal records
count_check=0
cnt1=cp_df.count()

if(cnt1!=0):
  count_check=1# RESULT OF COUNT CHECK

#Checks has all required columns
columns_checkv1=1
expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER','sourcefile','SOURCE_FILE','LOADTIME']
for cols in cp_df.columns:
  #print(cols)
  if(cols not in expected_cols):
    columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1
#print(columns_checkv1)

    
#Checks "Month Starting" is present in PPABCD_RECORD[0].DATA columns
val_check=0  
cp_df.createOrReplaceTempView("ppaTempView")
#spark.sql("SELECT COUNT(*) FROM ppaTempView WHERE array_contains(PPABCD_RECORD['DATA'],'MONTH STARTING%')").show()

ppa_val=spark.sql("SELECT COUNT(*) as cnt  FROM ppaTempView WHERE PPABCD_RECORD[0].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[1].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[2].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[3].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[4].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[5].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[6].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[7].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[8].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[9].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[10].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[11].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[12].DATA like '%MONTH STARTING%'").collect()

#print(ppa_val[0].cnt)
if(ppa_val[0].cnt>0):
  val_check=1

if(count_check==1 & columns_checkv1==1  & val_check==1):
  print("Success")
else:
  print("Failure")
  dbutils.notebook.exit("Failure")

# COMMAND ----------

#display(cp_df)

# COMMAND ----------

#Read Input Data Files for PPA,PPB,PPC & PPD
#cp_df_samp_ppa = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/PPC_FULL.DAT/")
#cp_df_samp_ppb = spark.read.json("abfss://aabaoriondlsnp.dfs.core.windows.net/fosdrain/tmp/PPD_FULL.DAT/")

# COMMAND ----------

#Read Input Data Files for PPC and PPD
#cp_df_samp_ppc = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/PPC_FULL.DAT/")
#cp_df_samp_ppd = spark.read.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/PPD_FULL.DAT/")

# COMMAND ----------

cp_df_sorted = cp_df.orderBy(cp_df.REC_NUMBER)

# COMMAND ----------

#cp_df.count()

# COMMAND ----------

#display(cp_df_sorted)

# COMMAND ----------

from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

DataSchema = StructType([StructField("NFZ_OUT_DATA", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

RepSchema = StructType([StructField("RPT_DATA", StringType()),StructField("RPT_PART", StringType()),StructField("RPT_IND", StringType()),StructField("RPT_STA", StringType()),StructField("RPT_NBR", StringType()),StructField("RPT_CTR", StringType()),StructField("RPT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

# COMMAND ----------

  #data processing for PPA,PPB,PPC and PPD files
def fs(str,len,val):
   return str.rjust(len,val)[:len]

NFZ_FILE_OUT_TMP_APPEND_LIST = []
NFZ_RPT_OUT_TMP_APPEND_LIST = []

CNTL_PARTITION_ID = 'AA'
LINE_NUMBER = 1
MONTH_STARTING = 'N'
EMP_IND = 'N'
space = ''

for row in cp_df_sorted.rdd.collect():
   LOAD_TIME = row.LOADTIME
   SOURCE_FILENAME = row.SOURCE_FILE
                     
   for A in range(1,14):
    HDR_REC_CHK = row.PPABCD_RECORD[A-1].DATA
    START_DATE =  row.PPABCD_RECORD[A-1].StartDate
    #START_DATE = datetime.strftime()
    
    #print(HDR_REC_CHK,'                                        ',CNTL_PARTITION_ID)
    #print(len(HDR_REC_CHK))
    #if(len(HDR_REC_CHK) != 80):
    pad = ' ' * (80-len(HDR_REC_CHK))
    if (("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'N')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
        #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','')
        NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','',START_DATE,LOAD_TIME,SOURCE_FILENAME)
        NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
        NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
    elif(("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'Y')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
    else:
        EMPLOYEE_STATION = row.PPABCD_RECORD[A-1].EmployeeStation
        EMPLOYEE_NUMBER = row.PPABCD_RECORD[A-1].EmployeeNumber
        EMPLOYEE_NAME_RAW  = row.PPABCD_RECORD[A-1].EmployeeName
        EMPLOYEE_NAME = EMPLOYEE_NAME_RAW[0:17]
        Domestic_International = row.PPABCD_RECORD[A-1].DomesticInternational
        INDICATOR = Domestic_International[0:1]
        LINE_NUMBER = LINE_NUMBER + 1
        #if(len(str(LINE_NUMBER)) != 7):
        LINE_NUMBER_ZERO = fs(str(LINE_NUMBER),7, '0')
        if(EMP_IND == 'Y'):
          #INDICATOR = HDR_REC_CHK[64:65]
         
          #print(INDICATOR)
          #print(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME)
          NFZ_RPT_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
          NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))
          EMP_IND = 'N'
        NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
        NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))

# COMMAND ----------

#display(PPC_NFZ_FILE_OUT_TMP_APPEND_LIST)
#PPC_NFZ_FILE_OUT_TMP_APPEND_LIST.count()

# COMMAND ----------

NFZ_FILE_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_FILE_OUT_TMP_APPEND_LIST,schema=DataSchema)

# COMMAND ----------


#NFZ_FILE_OUT_TMP_APPEND_DF1 = NFZ_FILE_OUT_TMP_APPEND_DF.filter(NFZ_FILE_OUT_TMP_APPEND_DF.NFZ_OUT_NBR=="040418")
#display(NFZ_FILE_OUT_TMP_APPEND_DF1)

# COMMAND ----------

#extract YEAR and MONTH separately from column START_DATE
from pyspark.sql.functions import year, month,to_date,regexp_extract
from pyspark.sql.functions import *

NFZ_FILE_OUT_TMP_APPEND_DF=NFZ_FILE_OUT_TMP_APPEND_DF.selectExpr("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","START_DATE","substring(START_DATE,7,11) as YEAR","substring(START_DATE,1,2) as MONTH","LOAD_TIME","SOURCE_FILENAME")
display(NFZ_FILE_OUT_TMP_APPEND_DF)

# COMMAND ----------

#NFZ_FILE_OUT_TMP_APPEND_DF.write.mode('overwrite').json("abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPC_Data_json")

# COMMAND ----------

NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

# COMMAND ----------

#save Data file into Partitioned Delta format and partition should be made on column YEAR and MONTH
#display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#Extract YEAR and MONTH from START_DATE column for Report as well
from pyspark.sql.functions import year, month,to_date,regexp_extract
from pyspark.sql.functions import *

NFZ_RPT_OUT_TMP_APPEND_DF = NFZ_RPT_OUT_TMP_APPEND_DF.selectExpr("RPT_DATA","RPT_PART","RPT_IND","RPT_STA","RPT_NBR","RPT_CTR","RPT_NAME","START_DATE","substring(START_DATE,7,11) as YEAR","substring(START_DATE,1,2) as MONTH","LOAD_TIME","SOURCE_FILENAME")
display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#create data and report delta file 
NFZ_FILE_OUT_TMP_APPEND_DF.orderBy(NFZ_FILE_OUT_TMP_APPEND_DF.NFZ_OUT_NBR).select("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","YEAR","MONTH","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Data)


NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.RPT_NBR).select("RPT_DATA","RPT_PART","RPT_IND","RPT_STA","RPT_NBR","RPT_CTR","RPT_NAME","START_DATE","YEAR","MONTH","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Report)


# COMMAND ----------

#NFZ_RPT_OUT_TMP_APPEND_DF.write.json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPC_Report_json")

# COMMAND ----------

#set spark.rpc.message.maxSize = 1024

# COMMAND ----------

#convert JSON to txt
#"spark.rpc.message.maxSize=512"
'''
import pyspark.sql.functions as F

def myConcat(*cols):
    concat_columns = []
    for c in cols[:-1]:
        concat_columns.append(F.coalesce(c, F.lit("*")))
        concat_columns.append(F.lit(" "))  
    concat_columns.append(F.coalesce(cols[-1], F.lit("*")))
    return F.concat(*concat_columns)

#report_text = NFZ_RPT_OUT_TMP_APPEND_DF.withColumn("combined", myConcat(*NFZ_RPT_OUT_TMP_APPEND_DF.columns)).select("combined")
  
#report_text.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save("abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/struct/CRP028_PPD_REPORT_TXT")

data_text = NFZ_FILE_OUT_TMP_APPEND_DF.withColumn("combined", myConcat(*NFZ_FILE_OUT_TMP_APPEND_DF.columns)).select("combined")
  
data_text.coalesce(2).write.format("text").option("header", "false").mode("overwrite").save("abfss://crpay-pii@aabaoriondlsnp.dfs.core.windows.net/struct-pii/CRP028_PPD_DATA_TXT")
'''

# COMMAND ----------

#PPD_NFZ_FILE_OUT_TMP_APPEND_DF.write.mode('overwrite').json("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPD_Data_json")

# COMMAND ----------

'''
from pyspark import SparkContext
partitionNum = 2 #Increase this number if necessary
ppd_rdd = sc.parallelize(PPD_data_text, partitionNum)
PPD_data_text_partitioned = ppd_rdd.toDF()  
PPD_data_text_partitioned.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save("abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CRP028_PPD_Data_txt")
'''

# COMMAND ----------

##create tables for program28 o/p reports of PPC & PPD 
#PPC_NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").save("mnt/default/PPC_NFZ_RPT_TEMP")
#spark.sql("CREATE TABLE PPC_NFZ_RPT_TEMP USING DELTA LOCATION '/mnt/delta/events/'")
#PPC_NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").saveAsTable("PPC_NFZ_RPT_TEMP")
#PPD_NFZ_RPT_OUT_TMP_APPEND_DF.write.format("delta").saveAsTable("PPD_NFZ_RPT_TEMP")

# COMMAND ----------

#dbutils.notebook.exit("Success")