# Databricks notebook source
# Create widgets for input which receive concrete path from ADF and output files 
dbutils.widgets.text("Input_File", "abfss://fosdrain@aabaoriondlsnp.dfs.core.windows.net/tmp/newDotNetJsonFiles/CREWPAY.PPABCD_0_PPA.json")
Input_File = dbutils.widgets.get("Input_File")


dbutils.widgets.text("Output_File_Report", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP028_PPD_DELTA_REPORT")
Output_File_Report = dbutils.widgets.get("Output_File_Report")

  
dbutils.widgets.text("Output_File_Data", "abfss://crpay@aabaoriondlsnp.dfs.core.windows.net/delta-struct/CRP28_PPD_DELTA_DATA/")
Output_File_Data = dbutils.widgets.get("Output_File_Data")

# COMMAND ----------

# Setting up blob storage in order to access its containers.
spark.conf.set("fs.azure.account.key.banzeauscrpaystg004.blob.core.windows.net","aSGs2pgDloWpiZDAPBBACu4rpKUyhMV+A/hipVliwQdb6IFrNbf0GOMWqSPsiVjGi/K/m16ycn92MamPj2srUA==")


# COMMAND ----------

# MAGIC 
# MAGIC %sql
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite = true;
# MAGIC set spark.databricks.delta.properties.defaults.autoOptimize.autoCompact = true;

# COMMAND ----------

#Read Input Data Files for PPA,PPB,PPC & PPD
from pyspark.sql.functions import input_file_name,regexp_extract
from pyspark.sql.functions import current_timestamp
cp_df = spark.read.json(Input_File)



# COMMAND ----------

#PRE-VALIDATION CHECKS before transformation of Data
#Any check variable will result into 1 if validation is succefull else it will be 0


#Checks Files Emptiness and both has equal records
count_check=0
cnt1=cp_df_samp_ppa.count()

if(cnt1!=0):
  count_check=1# RESULT OF COUNT CHECK

#Checks has all required columns
columns_checkv1=1
expected_cols=['FILL','FILL_1','PPABCD_RECORD','REC_NUMBER']
for cols in cp_df.columns:
  if(cols not in expected_cols):
    columns_checkv1=0 #RESULT OF COLUMNS VALIDATION for DF1


    
#Checks "Month Starting" is present in PPABCD_RECORD[0].DATA columns
val_check=0  
cp_df_samp_ppa.createOrReplaceTempView("ppaTempView")
#spark.sql("SELECT COUNT(*) FROM ppaTempView WHERE array_contains(PPABCD_RECORD['DATA'],'MONTH STARTING%')").show()

ppa_val=spark.sql("SELECT COUNT(*) as cnt  FROM ppaTempView WHERE PPABCD_RECORD[0].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[1].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[2].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[3].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[4].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[5].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[6].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[7].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[8].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[9].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[10].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[11].DATA like '%MONTH STARTING%' OR PPABCD_RECORD[12].DATA like '%MONTH STARTING%'").collect()


if(ppa_val[0].cnt>0):
  val_check=1
print(val_check)
if(count_check==1 & columns_checkv1==1  & val_check==1):
  print("Success")
else:
  print("Failure")
  dbutils.notebook.exit("Failure")

# COMMAND ----------

# adding audit columns as an input file name and LOAD TIME in Data frame
cp_df = cp_df.withColumn("sourcefile",input_file_name())
regex_str = "[\/]([^\/]+)$"
cp_df = cp_df.withColumn("SOURCE_FILE", regexp_extract("sourcefile",regex_str,1)).withColumn("LOADTIME",current_timestamp().cast("string"))

# COMMAND ----------

#Sorting data within DF by REC_NUMBER so that order of data can be intact
cp_df_sorted = cp_df.orderBy(cp_df.REC_NUMBER)

# COMMAND ----------

# defined Schema for output data and Report 
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.types import *
import time

DataSchema = StructType([StructField("NFZ_OUT_DATA", StringType()),StructField("NFZ_OUT_PART", StringType()),StructField("NFZ_OUT_IND", StringType()),StructField("NFZ_OUT_STA", StringType()),StructField("NFZ_OUT_NBR", StringType()),StructField("NFZ_OUT_CTR", StringType()),StructField("NFZ_OUT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

RepSchema = StructType([StructField("RPT_DATA", StringType()),StructField("RPT_PART", StringType()),StructField("RPT_IND", StringType()),StructField("RPT_STA", StringType()),StructField("RPT_NBR", StringType()),StructField("RPT_CTR", StringType()),StructField("RPT_NAME", StringType()),StructField("START_DATE", StringType()),StructField("LOAD_TIME", StringType()),StructField("SOURCE_FILENAME", StringType())])

# COMMAND ----------

#Data processing for PPA,PPB,PPC and PPD files as per CRP028 program
def fs(str,len,val):
   return str.rjust(len,val)[:len]

NFZ_FILE_OUT_TMP_APPEND_LIST = []
NFZ_RPT_OUT_TMP_APPEND_LIST = []

CNTL_PARTITION_ID = 'AA'
LINE_NUMBER = 1
MONTH_STARTING = 'N'
EMP_IND = 'N'
space = ''

for row in cp_df_sorted.rdd.collect():
   LOAD_TIME = row.LOADTIME
   SOURCE_FILENAME = row.SOURCE_FILE
                     
   for A in range(1,14):
    HDR_REC_CHK = row.PPABCD_RECORD[A-1].DATA
    START_DATE =  row.PPABCD_RECORD[A-1].StartDate
    pad = ' ' * (80-len(HDR_REC_CHK))
    if (("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'N')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
        NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,' ','   ','000000','0000001','',START_DATE,LOAD_TIME,SOURCE_FILENAME)
        NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
        NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))
    elif(("MONTH STARTING" in HDR_REC_CHK) & (MONTH_STARTING == 'Y')):
        MONTH_STARTING = 'Y'
        EMP_IND = 'Y'
    else:
        EMPLOYEE_STATION = row.PPABCD_RECORD[A-1].EmployeeStation
        EMPLOYEE_NUMBER = row.PPABCD_RECORD[A-1].EmployeeNumber
        EMPLOYEE_NAME_RAW  = row.PPABCD_RECORD[A-1].EmployeeName
        EMPLOYEE_NAME = EMPLOYEE_NAME_RAW[0:17]
        Domestic_International = row.PPABCD_RECORD[A-1].DomesticInternational
        INDICATOR = Domestic_International[0:1]
        LINE_NUMBER = LINE_NUMBER + 1
        LINE_NUMBER_ZERO = fs(str(LINE_NUMBER),7, '0')
        if(EMP_IND == 'Y'):
        
          NFZ_RPT_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
          NFZ_RPT_OUT_TMP_APPEND_LIST.append(NFZ_RPT_OUT_TMP.split(','))
          EMP_IND = 'N'
        NFZ_FILE_OUT_TMP =  "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}".format(HDR_REC_CHK,pad,CNTL_PARTITION_ID,INDICATOR,EMPLOYEE_STATION,EMPLOYEE_NUMBER,LINE_NUMBER_ZERO,EMPLOYEE_NAME,START_DATE,LOAD_TIME,SOURCE_FILENAME)
        NFZ_FILE_OUT_TMP_APPEND_LIST.append(NFZ_FILE_OUT_TMP.split(','))

# COMMAND ----------

# Create Structure output data Frame as per defiend schema which to be used further to create o/p file 
NFZ_FILE_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_FILE_OUT_TMP_APPEND_LIST,schema=DataSchema)


# COMMAND ----------

#extract YEAR and MONTH separately from column START_DATE
from pyspark.sql.functions import year, month,to_date,regexp_extract
from pyspark.sql.functions import *

NFZ_FILE_OUT_TMP_APPEND_DF = NFZ_FILE_OUT_TMP_APPEND_DF.selectExpr("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","START_DATE","substring(START_DATE,7,11) as YEAR","substring(START_DATE,1,2) as MONTH","LOAD_TIME","SOURCE_FILENAME")


# COMMAND ----------

# Create Structure output Report Frame as per defiend schema which to be used further to create Report file 
NFZ_RPT_OUT_TMP_APPEND_DF = spark.createDataFrame(NFZ_RPT_OUT_TMP_APPEND_LIST,schema=RepSchema)

# COMMAND ----------

#Extract YEAR and MONTH from START_DATE column for Report as well
from pyspark.sql.functions import year, month,to_date,regexp_extract
from pyspark.sql.functions import *

NFZ_RPT_OUT_TMP_APPEND_DF = NFZ_RPT_OUT_TMP_APPEND_DF.selectExpr("RPT_DATA","RPT_PART","RPT_IND","RPT_STA","RPT_NBR","RPT_CTR","RPT_NAME","START_DATE","substring(START_DATE,7,11) as YEAR","substring(START_DATE,1,2) as MONTH","LOAD_TIME","SOURCE_FILENAME")
#display(NFZ_RPT_OUT_TMP_APPEND_DF)

# COMMAND ----------

#create data and report delta file 
NFZ_FILE_OUT_TMP_APPEND_DF.orderBy(NFZ_FILE_OUT_TMP_APPEND_DF.NFZ_OUT_NBR).select("NFZ_OUT_DATA","NFZ_OUT_PART","NFZ_OUT_IND","NFZ_OUT_STA","NFZ_OUT_NBR","NFZ_OUT_CTR","NFZ_OUT_NAME","YEAR","MONTH","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Data)

NFZ_RPT_OUT_TMP_APPEND_DF = NFZ_RPT_OUT_TMP_APPEND_DF.orderBy(NFZ_RPT_OUT_TMP_APPEND_DF.RPT_NBR).select("RPT_DATA","RPT_PART","RPT_IND","RPT_STA","RPT_NBR","RPT_CTR","RPT_NAME","START_DATE","YEAR","MONTH","LOAD_TIME","SOURCE_FILENAME").write.format("delta").mode('append').option("overwriteSchema","true").save(Output_File_Report)
